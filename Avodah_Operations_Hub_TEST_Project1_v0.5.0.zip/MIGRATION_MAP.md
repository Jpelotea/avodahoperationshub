# Transitional Source and Naming Map

This map prevents setup from creating competing sources of truth.

| README logical source | Current physical source | Foundation behavior |
|---|---|---|
| `Targets and Settings` | `Targets & Settings` | Resolve alias; append row-based table in unused columns |
| `Booking Database` | `Booking Registry` | Resolve alias; append only missing canonical fields |
| `Management Dashboard` | `Dashboard` | Resolve alias; preserve formulas/layout; never operational writes |
| `Applicant Tracking` | Separate `Applicant Tracker` workbook | Create canonical destination only; do not migrate records yet |
| `Project 1 Activity Database` | Separate `2_Master_Log` workbook | Create canonical destination only; point crosswalk required |
| Audit `Activity Log` | Name occupied by performance activity data | Preserve current sheet; write audits to transitional `Activity Audit Log` |
| `Automation Log` | None confirmed | Create new append-only table |

## Existing columns protected by schema normalization

The `appendMissingHeaders_()` function compares normalized header names, so
`Booking ID` and `Booking_ID` are treated as the same field. Existing columns
are never sorted, inserted between populated columns, or deleted. Missing fields
are appended at the right edge.

Custom-layout sheets (`Dashboard`, `Daily Report`, `Weekly Report`, and the
existing operational `Activity Log`) are preserve-only during Foundation.

## Required manual decision before Phase 2 closes

Choose and document the final physical names for Booking, Settings, Dashboard,
and audit logging. Renames are not performed by Foundation because formulas,
Apps Script literals, web integrations, and user bookmarks may depend on the
current names.

