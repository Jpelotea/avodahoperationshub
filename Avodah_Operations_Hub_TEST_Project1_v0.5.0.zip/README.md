# Avodah Operations Hub - TEST Project 1 0.5.0

This is the verified TEST package for the compatibility-first Avodah Operations
Hub foundation and the stabilized intake, lead, booking, Calendar, booking
reconciliation, and Project 1 workflows.

## Current status

- Phase 1 foundation: verified.
- Phase 2 structure comparison: complete.
- Phase 3.1 Intake to Lead: complete and verified.
- Phase 3.2 Booking, Calendar, and reconciliation: complete and verified.
- Phase 3.3 Project 1 activity submission and points: complete and verified.
- Production spreadsheet: untouched.
- All operational write gates: disabled after testing.
- Automation triggers: disabled; none installed.
- Public/internal web-app deployment: not created.

## Project 1 source-of-truth decision

- `Targets & Settings` is the only runtime source for Project 1 point and
  required-field mappings.
- `Project 1 Activity Database` is the operational source database.
- `Project 1 Performance Analytics`, reports, and Dashboard remain derived.
- The older standalone Daily Entry script is preserved as an external legacy
  snapshot. It contains a different activity/points model and was not installed
  into the Hub or treated as authoritative.

No existing sheet or column was renamed, deleted, or reordered. The Project 1
database already had the required 19-column schema, so no headers were added.

## Implemented Project 1 behavior

- Reads all 18 active mappings from controlled JSON settings rows.
- Enforces Activity Type to Sub-Activity relationships at runtime.
- Validates every mapping-specific required field.
- Requires a valid HTTPS proof URL for proof-required activities.
- Assigns `P1-` IDs and controlled points.
- Uses `LockService` for concurrent submissions.
- Generates stable duplicate fingerprints.
- Blocks an exact repeat until the user explicitly confirms the duplicate.
- Calculates `Week 1` through `Week 4` and `YYYY-MM` reporting buckets.
- Stores source data in header-driven rows without formula dependencies.
- Records successful submissions in `Activity Audit Log`.
- Provides monthly totals grouped by Activity Type, Sub-Activity, and Team
  Member.
- Provides the four documented internal UI states: no type, type selected,
  sub-activity selected with dynamic fields, and successful submission.
- Uses an independent `ENABLE_PROJECT1_WRITES` Script Property gate.

## Verified point matrix

| Activity Type | Sub-Activity | Points |
|---|---|---:|
| Recruitment | Listing of Prospect Recruit Name | 1 |
| Recruitment | Call Out for Initial Interview | 1 |
| Recruitment | Initial Interview Update | 2 |
| Recruitment | Interview Result Update | 2 |
| Recruitment | Orientation Attendance | 2 |
| Recruitment | Contract Signing | 2 |
| Recruitment | Coding | 3 |
| Recruitment | Licensing Exam | 3 |
| Recruitment | Licensing | 5 |
| Sales | Prospect Listing | 1 |
| Sales | Initial Contact / Call Out | 1 |
| Sales | FNA Conducted | 2 |
| Sales | Proposal Presented | 2 |
| Sales | Application Submitted | 3 |
| Sales | Issued Policy | 5 |
| Joint Field Coaching | Shadowing / Observation | 1 |
| Joint Field Coaching | Co-Presentation | 2 |
| Joint Field Coaching | Assisted Closing | 3 |

Total for one complete matrix: 41 points.

## Files changed for 0.5.0

- `Config.gs`
- `Project1.gs`
- `Validation.gs`
- `Index.html`
- `Client.html`
- `Styles.html`
- `LegacyV3.gs` (installed in Apps Script as the existing `Code.gs` file)
- `SCRIPT_PROPERTIES.md`
- `README.md`
- `PROJECT1_VERIFICATION.md`

## Verification summary

- 21 Apps Script files parsed successfully with the V8 parser.
- 276 declared global functions; 0 duplicate names.
- Client-side JavaScript parsed successfully.
- 0 production spreadsheet ID occurrences.
- 0 implementation-placeholder occurrences.
- 31 local mapping, validation, bucketing, and summary checks passed.
- 4 local transaction-boundary scenarios passed.
- 13 live foundation checks passed.
- 31 live Project 1 validation checks passed.
- Final live lifecycle: 24/24 checks passed.
- Two complete TEST batches contain 18 rows and 41 points each.
- 36 successful Project 1 audit entries were verified.
- `masterSetup()` preserved every sheet and installed no trigger.
- Spreadsheet read-back, native validation checks, and visual QA passed.

The first lifecycle run proved all 18 point assignments but exposed that Google
Sheets can return the displayed month bucket as a Date object. The summary read
path was normalized for both Date and text cells, then the full lifecycle was
repeated and passed all 24 checks.

## Final safety state

- `ENVIRONMENT=TEST`
- `ENABLE_PROJECT1_WRITES=FALSE`
- `ENABLE_CALENDAR_WRITES=FALSE`
- `ENABLE_BOOKING_WORKFLOW=FALSE`
- `ENABLE_AUTOMATION_TRIGGERS=FALSE`
- `PUBLIC_PORTAL_ENABLED=FALSE`
- No trigger or deployment was created.
- Sensitive Script Properties are excluded from source and reports.

## Remaining configuration gate

No active `TEAM_MEMBER` settings exist. The TEST-only interface can accept a
typed team-member name, but real `TEAM_MEMBER` rows must be populated before a
future production promotion. The internal Project 1 interface is installed in
the source package but remains inaccessible to end users until a reviewed,
restricted internal deployment is intentionally created.

## Next blueprint stage

The next priority is Recruitment stage/status and interview workflows. Preserve
`Applicant Tracking` as the current applicant source and keep stage, status,
timeline, interview, requirements, and onboarding responsibilities separate.

See `PROJECT1_VERIFICATION.md` and the dated Phase 3.3 report for detailed test
evidence.
