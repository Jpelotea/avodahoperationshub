/** Audit and automation logging. Existing operational Activity Log is untouched. */

function logAuditEvent_(event) {
  var actorEmail = '';
  try { actorEmail = normalizeEmail_(Session.getActiveUser().getEmail()); } catch (ignored) {}
  var record = {
    'Log ID': generateUniqueId_('ACTIVITY_LOG'),
    'Occurred At': new Date(),
    'Actor Email': event.actorEmail || actorEmail,
    'Actor Role': event.actorRole || '',
    'Action': event.action || '',
    'Entity Type': event.entityType || '',
    'Entity ID': event.entityId || '',
    'Result': event.result || 'SUCCESS',
    'Details JSON': safeJsonStringify_(event.details || {}),
    'Request ID': event.requestId || ''
  };
  return appendObjectRow_(AVODAH_CONFIG.TRANSITIONAL_AUDIT_SHEET, record);
}

function logAutomation_(event) {
  var record = {
    'Automation Log ID': generateUniqueId_('AUTOMATION_LOG'),
    'Started At': event.startedAt || new Date(),
    'Finished At': event.finishedAt || new Date(),
    'Handler': event.handler || '',
    'Trigger UID': event.triggerUid || '',
    'Environment': getEnvironment_(),
    'Status': event.status || 'SUCCESS',
    'Records Read': Number(event.recordsRead || 0),
    'Records Written': Number(event.recordsWritten || 0),
    'Error Code': event.errorCode || '',
    'Error Message': event.errorMessage || '',
    'Details JSON': safeJsonStringify_(event.details || {})
  };
  return appendObjectRow_('Automation Log', record);
}

function logAutomationSafe_(event) {
  try {
    return logAutomation_(event);
  } catch (error) {
    console.error('Automation log write failed: ' + String(error));
    return null;
  }
}

