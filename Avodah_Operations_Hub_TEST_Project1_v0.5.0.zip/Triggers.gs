/** Safe, de-duplicated trigger installation and stable trigger entry points. */

function installRequiredTriggers_() {
  var existing = ScriptApp.getProjectTriggers();
  var handlers = {};
  existing.forEach(function(trigger) { handlers[trigger.getHandlerFunction()] = true; });
  var created = [];
  AVODAH_CONFIG.TRIGGER_DEFINITIONS.forEach(function(definition) {
    if (handlers[definition.handler]) return;
    var builder = ScriptApp.newTrigger(definition.handler).timeBased();
    if (definition.type === 'HOURLY') builder.everyHours(1).create();
    if (definition.type === 'EVERY_6_HOURS') builder.everyHours(6).create();
    if (definition.type === 'WEEKLY_MONDAY_7') {
      builder.onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).create();
    }
    if (definition.type === 'MONTHLY_DAY_1_7') {
      builder.onMonthDay(1).atHour(7).create();
    }
    created.push(definition.handler);
    handlers[definition.handler] = true;
  });
  return {status: 'INSTALLED', created: created};
}

function listInstalledAvodahTriggers() {
  var managed = AVODAH_CONFIG.TRIGGER_DEFINITIONS.map(function(item) {
    return item.handler;
  }).concat(['handleSpreadsheetFormSubmit']);
  return ScriptApp.getProjectTriggers().filter(function(trigger) {
    return managed.indexOf(trigger.getHandlerFunction()) !== -1;
  }).map(function(trigger) {
    return {
      handler: trigger.getHandlerFunction(),
      eventType: String(trigger.getEventType()),
      source: String(trigger.getTriggerSource()),
      uniqueId: trigger.getUniqueId()
    };
  });
}

function installSpreadsheetFormSubmitTrigger() {
  var existing = ScriptApp.getProjectTriggers().some(function(trigger) {
    return trigger.getHandlerFunction() === 'handleSpreadsheetFormSubmit';
  });
  if (existing) return {status: 'ALREADY_INSTALLED'};
  ScriptApp.newTrigger('handleSpreadsheetFormSubmit')
    .forSpreadsheet(getHubSpreadsheet_())
    .onFormSubmit()
    .create();
  return {status: 'INSTALLED'};
}

function removeAvodahTriggers() {
  requireUserRole_(['ADMIN']);
  var managed = AVODAH_CONFIG.TRIGGER_DEFINITIONS.map(function(item) {
    return item.handler;
  }).concat(['handleSpreadsheetFormSubmit']);
  var removed = [];
  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (managed.indexOf(trigger.getHandlerFunction()) === -1) return;
    ScriptApp.deleteTrigger(trigger);
    removed.push(trigger.getHandlerFunction());
  });
  return {removed: removed};
}

function runHourlyFollowUpChecks(event) {
  return runScheduledTask_('runHourlyFollowUpChecks', event, function() {
    if (typeof processDueFollowUps_ !== 'function') return phaseInactive_('INTAKE_LEADS');
    return processDueFollowUps_();
  });
}

function reconcileBookingRecords(event) {
  return runScheduledTask_('reconcileBookingRecords', event, function() {
    if (typeof reconcileBookingRecords_ !== 'function') return phaseInactive_('BOOKINGS');
    return reconcileBookingRecords_();
  });
}

function scheduledDashboardRefresh(event) {
  return runScheduledTask_('scheduledDashboardRefresh', event, function() {
    if (typeof refreshAllAnalytics_ !== 'function') return phaseInactive_('ANALYTICS');
    return refreshAllAnalytics_();
  });
}

function scheduledWeeklyReport(event) {
  return runScheduledTask_('scheduledWeeklyReport', event, function() {
    if (typeof generateWeeklyReport_ !== 'function') return phaseInactive_('ANALYTICS');
    return generateWeeklyReport_();
  });
}

function scheduledMonthlyReport(event) {
  return runScheduledTask_('scheduledMonthlyReport', event, function() {
    if (typeof generateMonthlyReport_ !== 'function') return phaseInactive_('ANALYTICS');
    return generateMonthlyReport_();
  });
}

function runScheduledTask_(handler, event, callback) {
  var startedAt = new Date();
  try {
    var output = callback();
    logAutomationSafe_({
      handler: handler,
      triggerUid: event && event.triggerUid || '',
      startedAt: startedAt,
      finishedAt: new Date(),
      status: output && output.status === 'PHASE_NOT_ACTIVE' ? 'SKIPPED' : 'SUCCESS',
      details: output
    });
    return output;
  } catch (error) {
    logAutomationSafe_({
      handler: handler,
      triggerUid: event && event.triggerUid || '',
      startedAt: startedAt,
      finishedAt: new Date(),
      status: 'FAILED',
      errorCode: error.code || error.name,
      errorMessage: error.message
    });
    throw error;
  }
}

function phaseInactive_(moduleName) {
  return {status: 'PHASE_NOT_ACTIVE', module: moduleName};
}

