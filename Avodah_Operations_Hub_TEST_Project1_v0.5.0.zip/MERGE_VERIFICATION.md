# TEST Merge 0.2.0 Verification

Verified locally on 2026-07-22. These checks do not replace Apps Script runtime
authorization or tests against the copied Google Sheet.

## Static checks

- Apps Script files parsed: 21
- Declared functions inventoried: 180
- Duplicate declared function names: 0
- JavaScript syntax failures: 0
- Combined manifest JSON parse: passed
- Advanced Calendar service entry: present (`calendar`, `v3`)
- Production spreadsheet ID, former calendar email, and former management URL
  in executable package defaults: not found

## Foundation regression checks

All 24 local checks passed, including:

- normalization and unique ID helpers;
- Project 1 mapping inventory and point total;
- preservation of existing Calendar Log header order;
- append-only missing-column behavior;
- reuse of transitional Booking Registry and Dashboard aliases;
- preservation of existing Activity Log and settings layout;
- idempotent sheet/settings setup across two runs; and
- triggers remaining disabled.

## New TEST safety checks

All six checks passed:

1. Missing environment fails closed.
2. A spreadsheet whose name does not begin with `TEST` fails closed.
3. A configured TEST spreadsheet loads.
4. Calendar writes default to blocked.
5. Explicit calendar-write enablement is recognized.
6. Missing booking-management URL fails closed.

## Runtime checks still required in Google Apps Script

- Scope authorization under the intended TEST owner.
- `masterSetup()` against the copied spreadsheet.
- `productionHealthCheck()` result review.
- Initial real `USER_ROLE` bootstrap.
- Read access to the confirmed calendar.
- Temporary write/delete test against a safe TEST calendar.
- Existing trigger and deployment inventory.
- Full README workflow and integration checklist.
