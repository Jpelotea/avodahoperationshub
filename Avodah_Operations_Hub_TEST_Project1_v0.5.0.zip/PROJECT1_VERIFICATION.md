# Project 1 Verification

Date: 2026-07-22  
Environment: isolated TEST only  
Package: `0.5.0-test-project1`

## Verified architecture

`Targets & Settings -> Project 1 validation and submission -> Project 1 Activity Database -> Activity Audit Log -> derived summaries`

The operational database remains authoritative. The Dashboard and analytics
tabs were not used as editable sources.

## Legacy comparison

The workspace contains an older standalone Daily Entry script with `1_Entry`,
`2_Master_Log`, and a materially different activity/points matrix. Those sheets
do not exist in the Hub TEST spreadsheet, and that script is not present in the
live Hub Apps Script project. It was preserved as historical input and not
merged because doing so would introduce a second authoritative points table.

## Controlled mapping and validation

- 18 unique active `PROJECT1_ACTIVITY` settings rows.
- One runtime mapping for each Activity Type and Sub-Activity pair.
- Points are read from settings; they are not duplicated in submission logic.
- Required field keys are also read from each settings JSON row.
- Unknown field keys, malformed JSON, duplicate mappings, and mismatched
  Activity Type/Sub-Activity pairs fail closed.
- Proof-required mappings require an HTTPS URL.
- The source sheet has native validation for Activity Date, Activity Type,
  Sub-Activity, and Record Status.
- The HTML interface renders the mapping-specific required fields dynamically.

## Reliability controls

- TEST environment and TEST spreadsheet-name assertions.
- `ENABLE_PROJECT1_WRITES` gate.
- `USER_ROLE` authorization for internal APIs.
- `LockService` around each submission.
- Stable duplicate fingerprint derived from agent, date, controlled mapping,
  and required non-proof data.
- Unconfirmed exact repeats do not create a row.
- Confirmed duplicates are explicitly labeled.
- `P1-` IDs, record status, creator, and timestamps.
- Header-driven writes and formula-injection-safe values.
- Activity audit logging with a non-blocking automation warning path.

## Local test results

### Validation suite: 31 passed

- All 18 point mappings
- Mapping count and 41-point total
- Unique mapping keys
- Week 1–4 boundaries
- Proof-required rejection
- Type/Sub-Activity relationship enforcement
- Monthly record and point totals
- Three-category analytics grouping
- `P1-` ID prefix

### Transaction suite: 4 scenarios passed

- Successful submission
- Unconfirmed duplicate blocked
- Confirmed duplicate labeled and written
- Disabled write gate fails closed

## Live TEST results

| Check | Result |
|---|---|
| `testBasicRuntime()` | Passed; v0.5.0 loaded |
| `runFoundationTests()` | 13 passed |
| `runProject1ValidationTests()` | 31 passed |
| First `masterSetup()` | Added only missing Project 1 validations; no sheets, headers, settings, or triggers created |
| Repeated `masterSetup()` | No structural changes; validations preserved |
| Final `runProject1LifecycleIntegrationTest()` | 24 passed |
| Final health check | Passed with Project 1 writes disabled |
| Connector read-back | Passed |
| Native Google Sheets visual review | Passed |

The final lifecycle verified every Recruitment, Sales, and Joint Field Coaching
sub-activity; correct points; proof rejection; exact-duplicate warning;
one-row-per-mapping behavior; Week 4 bucketing; a 41-point monthly total; and
grouping into all three Activity Types.

## TEST evidence retained

Two complete automated batches remain in `Project 1 Activity Database`:

- 18 records and 41 points in the first batch.
- 18 records and 41 points in the repeated final batch.
- All 36 rows are marked with TEST agent/team identifiers.
- All 36 successful submissions have corresponding Activity Audit records.

The first run's two summary assertions exposed a cell-type mismatch: Google
Sheets displayed `Reporting Month` as `YYYY-MM` but returned a Date object to
Apps Script. The read path now normalizes both representations. The repeated
full lifecycle passed all 24 checks.

## Final activation state

| Control | Final value |
|---|---|
| `ENABLE_PROJECT1_WRITES` | `FALSE` |
| `ENABLE_CALENDAR_WRITES` | `FALSE` |
| `ENABLE_BOOKING_WORKFLOW` | `FALSE` |
| `ENABLE_AUTOMATION_TRIGGERS` | `FALSE` |
| `PUBLIC_PORTAL_ENABLED` | `FALSE` |
| Added triggers | None |
| Deployment | None |

## Remaining before production promotion

1. Populate real active `TEAM_MEMBER` settings and decide the approved Agent
   Code policy.
2. Review proof-storage retention and access; current implementation stores an
   HTTPS link only.
3. Create and test a restricted internal deployment before exposing the UI.
4. Repeat the full mapping test with approved production-role assignments in a
   new staging copy.
