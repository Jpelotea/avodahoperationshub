# Booking and Calendar Verification

Date: 2026-07-22  
Environment: isolated TEST only  
Package: `0.4.0-test-bookings`

## Scope

The verified path is:

`Availability -> Booking -> TEST Google Calendar -> Booking Registry -> Calendar Log -> reconciliation`

Intake and Lead records are resolved before booking and updated only after the
canonical booking record exists. Dashboard and analytics tabs are not used as
editable sources.

## Compatibility and migration decisions

1. The copied `Booking Registry` is reused as the physical Booking Database.
2. Existing UUID booking rows are preserved as unbound legacy history because
   they belong to a different calendar than the isolated TEST calendar.
3. New bookings use `BOOK-` IDs; Calendar Log records use `CAL-` IDs.
4. New booking rows store `Environment` and a non-secret hashed Calendar
   Binding.
5. Reconciliation skips unbound legacy rows and processes only records bound to
   the current environment/calendar combination.
6. `Calendar Log` and `Targets & Settings` were expanded in place. Nothing was
   renamed, deleted, or reordered.

## Reliability and security controls

- Separate `ENABLE_CALENDAR_WRITES` and `ENABLE_BOOKING_WORKFLOW` gates.
- TEST spreadsheet-name and environment assertions.
- `LockService` around booking transactions.
- Idempotency lookup before creation.
- One-active-booking-per-lead enforcement.
- Email/phone normalization and canonical source resolution.
- Notice, horizon, day, hour, and slot-interval validation.
- Busy-slot, blackout, and buffer enforcement.
- Calendar-event-first transaction with compensating Calendar deletion if the
  Booking Registry write fails.
- Event ID and Meet-link tracking.
- Structured booking and activity audits.
- Calendar binding prevents cross-calendar reconciliation.
- Sensitive configuration remains in Script Properties.

## Local tests

### Rule suite: 12 passed

- Valid slot acceptance
- 24-hour minimum notice
- 30-day maximum horizon
- Opening and closing-hour limits
- Slot interval
- Working-day limits
- Blackout overlap
- Stable binding
- Environment-separated binding
- `BOOK-` and `CAL-` ID generation

### Transaction suite: 6 scenarios passed

- Successful create
- Idempotent replay
- Existing-active-booking prevention
- Busy/buffer conflict rejection
- Calendar creation failure boundary
- Calendar rollback after Booking Registry failure

## Live TEST results

| Check | Result |
|---|---|
| `testBasicRuntime()` | Passed |
| `runFoundationTests()` | 13 passed |
| First `masterSetup()` | Appended 4 missing booking headers and 8 booking settings; no sheets or triggers created |
| Second `masterSetup()` | No changes; idempotency confirmed |
| Advanced Calendar free/busy availability | Passed |
| `runBookingValidationTests()` | 12 passed |
| `runBookingLifecycleIntegrationTest()` | 16 passed |
| Final TEST health check | Passed |
| Spreadsheet value read-back | Passed |
| Native Google Sheets visual review | Passed |

The lifecycle test verified creation, prefixed IDs, Calendar Event ID storage,
unique Meet creation, idempotent replay, busy/buffer rejection, registry and
Calendar Log writes, intake/lead linking, reconciliation repair, legacy-row
skipping, rescheduling, cancellation, Calendar removal, and retained cancelled
registry history.

Google Calendar may return a deleted event as a resource with
`status=cancelled` instead of returning no resource. The first test run exposed
this documented API behavior; the assertion was corrected to accept either
representation. The repeated lifecycle run passed all 16 checks.

## TEST evidence left in the spreadsheet

- Two cancelled `BOOK-` booking rows in `Booking Registry`.
- Two cancelled `CAL-` rows in `Calendar Log`.
- Four synthetic intake fixtures and four matching lead fixtures.
- Successful create/reschedule/cancel entries in `Booking Audit` and
  `Activity Audit Log`.

The isolated TEST Calendar events were removed/cancelled. Evidence rows remain
so the test can be audited and are clearly marked as automated TEST fixtures.

## Final activation state

| Control | Final value |
|---|---|
| `ENABLE_CALENDAR_WRITES` | `FALSE` |
| `ENABLE_BOOKING_WORKFLOW` | `FALSE` |
| `ENABLE_AUTOMATION_TRIGGERS` | `FALSE` |
| `PUBLIC_PORTAL_ENABLED` | `FALSE` |
| Guest invitations | `FALSE` |
| Installed triggers | None added |
| Deployment | None created |

## Remaining gate

A reviewed TEST web-app deployment must exist before enabling public booking or
self-service management. At that point, set the deployment/management URL in
Script Properties, verify the intended executing account and access policy,
then repeat the full lifecycle tests before changing either booking write gate.
