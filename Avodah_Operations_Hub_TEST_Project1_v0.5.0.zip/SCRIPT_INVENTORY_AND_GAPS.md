# Supplied TEST Apps Script — Inventory and Gap Analysis

## Inventory result

- Supplied source: 2,865 lines and 106 declared functions.
- Source identity: matches the previously inventoried V3 resilience package,
  plus `authorizeV3ProductionScopes()`.
- Existing entry points: `doGet`, `doPost`, `onOpen`, and `onEdit`.
- Existing property references: `WEBHOOK_SECRET`, `WEBHOOK_SECRET_NEXT`,
  `BOOKING_MANAGEMENT_BASE_URL`, and `BOOKING_ADMIN_ALERT_EMAIL`.
- Existing operational controls: Script Lock, idempotency keys, duplicate lead
  IDs, booking fingerprints, audit records, reconciliation, event IDs, Meet
  creation, safe cell values, and a duplicate-aware maintenance trigger.
- Merged package: 21 `.gs` files, 180 declared functions, and zero duplicate
  function names by static inventory.

## Critical discrepancy corrected in this package

The supplied copied-project source still embedded the live production
spreadsheet ID. A function run from the copied TEST Apps Script project would
therefore have written to production. `LegacyV3.gs` now obtains the ID from
`AVODAH_SPREADSHEET_ID`, requires `ENVIRONMENT=TEST`, and rejects any target
whose spreadsheet name does not begin with `TEST`.

The source also contained fallback production values for Calendar, management
URL, and notification email. These fallbacks were removed. Script Properties
are now authoritative.

## Existing implementation compared with README architecture

| Area | Current status | Required next work |
|---|---|---|
| Intake submission | Implemented in V3, 24-field legacy payload, UUIDv4 idempotency | Map into the canonical Intake → Lead workflow and prefixed IDs without breaking deployed clients. |
| Booking | Substantially implemented: availability, buffers, locks, Meet, event ID, registry, audit, reschedule/cancel, reconciliation | Test every boundary and migrate transitional sheet names only through an approved compatibility plan. |
| Calendar Log | Existing and preserved | Verify fixed-column mappings against the copied sheet before end-to-end writes. |
| Schedule Import | Preview/commit workflow implemented | Execute the README fixture matrix for merged cells, time formats, links, untimed items, and duplicates. |
| Lead Database | Foundation schema exists | Intake → Lead promotion logic remains a Phase 3 deliverable. |
| Project 1 | Foundation schema and module seam only | Implement all documented activity mappings and point tests. |
| Recruitment | Foundation schemas/module seam; existing Applicant Tracking preserved | Implement single-stage rules, timeline, interviews, requirements, and onboarding workflows. |
| Analytics/Dashboard | Schemas/module seams only | Build after operational sources and workflows are stable; keep views derived and read-only. |
| Roles | Foundation `USER_ROLE` authorization implemented | Confirm and bootstrap real administrator; do not expose internal UI anonymously. |
| Logs | V3 Booking Audit plus Foundation Activity/Automation logs | Normalize cross-module logging during workflow phases; retain transitional logs meanwhile. |
| Triggers | V3 reconciliation installer plus gated Foundation installer | Inventory TEST project triggers in the Apps Script UI before installing anything. |

## Manifest assessment

- Time zone is correctly `Asia/Manila`.
- Advanced Calendar v3 is enabled as required by the README.
- V3 currently calls Calendar REST through `UrlFetchApp`, so
  `script.external_request` remains required even though the Advanced service is
  enabled.
- `userinfo.email` is included for future authenticated `USER_ROLE` checks.
- `ANYONE_ANONYMOUS` is compatible only with the secret-protected public V3
  endpoint. It is not acceptable for the future internal Management Dashboard.
- No deployment was created or changed during this analysis.

## Current phase status

- Phase 1 source merge: prepared locally.
- Phase 1 Google configuration: blocked on real calendar ID, secrets,
  notification/routing values, and administrator confirmation.
- Phase 1 execution: not yet run in Apps Script.
- Phase 2 environment inventory: spreadsheet structures are inventoried; TEST
  Apps Script triggers and deployments still require UI verification.
- Phase 3 workflow changes: not started in this package.
