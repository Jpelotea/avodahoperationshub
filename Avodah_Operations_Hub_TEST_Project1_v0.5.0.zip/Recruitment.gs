/**
 * Recruitment status: Applicant Tracker remains the verified source. Foundation
 * adds canonical destination/history schemas without moving any applicant record.
 */

