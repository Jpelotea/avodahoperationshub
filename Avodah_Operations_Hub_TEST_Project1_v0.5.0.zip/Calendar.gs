/** Calendar availability and Advanced Calendar operations for booking. */

function bookingLegacySettingsMap_() {
  var sheet = getHubSpreadsheet_().getSheetByName('Targets & Settings');
  if (!sheet) throw avodahError_('MISSING_SETTINGS', 'Targets & Settings is missing.');
  var values = sheet.getRange('U3:V20').getDisplayValues();
  var result = {};
  values.forEach(function(row) {
    var key = String(row[0] || '').trim();
    if (key) result[key] = row[1];
  });
  return result;
}

function bookingControlledSettingsMap_() {
  var result = {};
  getActiveSettingsByGroup_('BOOKING').forEach(function(row) {
    result[String(row.key || '').trim().toUpperCase()] = row.value;
  });
  return result;
}

function bookingNumberSetting_(controlled, key, fallback) {
  var value = Number(controlled[key]);
  return Number.isFinite(value) ? value : Number(fallback);
}

function bookingBooleanSetting_(controlled, key, fallback) {
  if (!Object.prototype.hasOwnProperty.call(controlled, key)) return Boolean(fallback);
  return truthy_(controlled[key]);
}

function getBookingRuntimeConfig_() {
  var properties = PropertiesService.getScriptProperties();
  var calendarId = String(properties.getProperty('CHRISTINE_CALENDAR_ID') || '').trim();
  if (!calendarId) {
    throw avodahError_('CALENDAR_NOT_CONFIGURED',
      'CHRISTINE_CALENDAR_ID is required in Script Properties.');
  }

  var legacy = bookingLegacySettingsMap_();
  var controlled = bookingControlledSettingsMap_();
  var legacyBuffer = Number(legacy['Buffer Minutes'] || 30);
  var duration = bookingNumberSetting_(controlled, 'APPOINTMENT_MINUTES',
    legacy['Appointment Minutes'] || 30);
  var buffer = bookingNumberSetting_(controlled, 'BUFFER_MINUTES', legacyBuffer);
  var daysText = String(controlled.DAYS_AVAILABLE || legacy['Days Available'] ||
    'Mon,Tue,Wed,Thu,Fri,Sat,Sun');
  var environment = getEnvironment_();
  var timezone = String(legacy['Time Zone'] || AVODAH_CONFIG.TIME_ZONE).trim();

  var config = {
    calendarId: calendarId,
    owner: String(legacy.Owner || "Ma'am Christine").trim(),
    timezone: timezone,
    environment: environment,
    days: daysText.split(',').map(function(day) { return day.trim(); }).filter(Boolean),
    startHour: bookingNumberSetting_(controlled, 'START_HOUR', legacy['Start Hour'] || 9),
    endHour: bookingNumberSetting_(controlled, 'END_HOUR', legacy['End Hour'] || 17),
    durationMinutes: duration,
    slotIntervalMinutes: bookingNumberSetting_(controlled, 'SLOT_INTERVAL_MINUTES',
      duration + buffer),
    bufferBeforeMinutes: bookingNumberSetting_(controlled, 'BUFFER_BEFORE_MINUTES', buffer),
    bufferAfterMinutes: bookingNumberSetting_(controlled, 'BUFFER_AFTER_MINUTES', buffer),
    minimumNoticeHours: bookingNumberSetting_(controlled, 'MINIMUM_NOTICE_HOURS',
      legacy['Minimum Notice Hours'] || 24),
    horizonDays: bookingNumberSetting_(controlled, 'BOOKING_HORIZON_DAYS',
      legacy['Booking Horizon Days'] || 30),
    emailReminderMinutes: bookingNumberSetting_(controlled, 'EMAIL_REMINDER_MINUTES',
      legacy['Email Reminder Minutes'] || 1440),
    popupReminderMinutes: bookingNumberSetting_(controlled, 'POPUP_REMINDER_MINUTES',
      legacy['Popup Reminder Minutes'] || 60),
    createGoogleMeet: bookingBooleanSetting_(controlled, 'CREATE_GOOGLE_MEET', true),
    sendGuestInvites: bookingBooleanSetting_(controlled, 'SEND_GUEST_INVITES', false)
  };
  config.calendarBinding = bookingCalendarBinding_(config.calendarId, environment);
  return config;
}

function bookingCalendarBinding_(calendarId, environment) {
  var source = String(environment || '').trim().toUpperCase() + '|' +
    String(calendarId || '').trim();
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    source, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '').substring(0, 32);
}

function assertBookingWritesEnabled_() {
  if (getEnvironment_() !== 'TEST') {
    throw avodahError_('TEST_ONLY', 'This booking package is restricted to TEST.');
  }
  var enabled = String(PropertiesService.getScriptProperties()
    .getProperty('ENABLE_BOOKING_WORKFLOW') || '').trim().toUpperCase();
  if (enabled !== 'TRUE') {
    throw avodahError_('BOOKING_WRITES_DISABLED',
      'Set ENABLE_BOOKING_WORKFLOW=TRUE only for an approved TEST booking run.');
  }
  assertCalendarWritesEnabled_();
}

function validateBookingSlotRules_(startValue, config, nowValue) {
  var start = startValue instanceof Date ? new Date(startValue.getTime()) : new Date(startValue);
  var now = nowValue instanceof Date ? new Date(nowValue.getTime()) : new Date();
  if (isNaN(start.getTime())) {
    return {ok: false, code: 'INVALID_SLOT', message: 'The selected time is invalid.'};
  }
  var earliest = new Date(now.getTime() + config.minimumNoticeHours * 60 * 60 * 1000);
  var latest = new Date(now.getTime() + config.horizonDays * 24 * 60 * 60 * 1000);
  if (start.getTime() < earliest.getTime()) {
    return {ok: false, code: 'MINIMUM_NOTICE_REQUIRED',
      message: 'The selected time does not meet the minimum booking notice.'};
  }
  if (start.getTime() > latest.getTime()) {
    return {ok: false, code: 'BOOKING_HORIZON_EXCEEDED',
      message: 'The selected time is outside the booking window.'};
  }

  var dayName = Utilities.formatDate(start, config.timezone, 'EEE');
  if (config.days.indexOf(dayName) === -1) {
    return {ok: false, code: 'WORKING_DAY_RESTRICTED',
      message: 'The selected day is not available for consultations.'};
  }
  var hour = Number(Utilities.formatDate(start, config.timezone, 'H'));
  var minute = Number(Utilities.formatDate(start, config.timezone, 'm'));
  var second = Number(Utilities.formatDate(start, config.timezone, 's'));
  var minutesFromOpen = (hour - config.startHour) * 60 + minute;
  var endMinutes = hour * 60 + minute + config.durationMinutes;
  if (hour < config.startHour || endMinutes > config.endHour * 60 ||
      minutesFromOpen < 0) {
    return {ok: false, code: 'WORKING_HOURS_RESTRICTED',
      message: 'The selected time is outside consultation working hours.'};
  }
  if (second !== 0 || minutesFromOpen % Math.max(1, config.slotIntervalMinutes) !== 0) {
    return {ok: false, code: 'INVALID_SLOT_INTERVAL',
      message: 'The selected time is not an offered consultation slot.'};
  }
  return {ok: true, code: 'VALID_SLOT'};
}

function getBookingBusyIntervals_(config, windowStart, windowEnd) {
  var response = Calendar.Freebusy.query({
    timeMin: windowStart.toISOString(),
    timeMax: windowEnd.toISOString(),
    timeZone: config.timezone,
    items: [{id: config.calendarId}]
  });
  var calendarResult = response.calendars && response.calendars[config.calendarId];
  if (!calendarResult) {
    throw avodahError_('CALENDAR_FREEBUSY_FAILED',
      'The configured calendar did not return free/busy data.');
  }
  if (calendarResult.errors && calendarResult.errors.length) {
    throw avodahError_('CALENDAR_FREEBUSY_FAILED',
      'The configured calendar returned a free/busy error.', calendarResult.errors);
  }
  return (calendarResult.busy || []).map(function(item) {
    return {start: new Date(item.start).getTime(), end: new Date(item.end).getTime()};
  });
}

function bookingCalendarConflictExists_(config, start, end, excludeEventId) {
  var pageToken;
  do {
    var response = Calendar.Events.list(config.calendarId, {
      timeMin: start.toISOString(),
      timeMax: end.toISOString(),
      singleEvents: true,
      showDeleted: false,
      maxResults: 100,
      pageToken: pageToken
    });
    var conflict = (response.items || []).some(function(event) {
      return event.status !== 'cancelled' &&
        String(event.id || '') !== String(excludeEventId || '') &&
        event.transparency !== 'transparent';
    });
    if (conflict) return true;
    pageToken = response.nextPageToken;
  } while (pageToken);
  return false;
}

function getBookingAvailability_() {
  var config = getBookingRuntimeConfig_();
  var now = new Date();
  var earliest = new Date(now.getTime() + config.minimumNoticeHours * 60 * 60 * 1000);
  var latest = new Date(now.getTime() + config.horizonDays * 24 * 60 * 60 * 1000);
  var earliestParts = getDatePartsInTimezone_(earliest, config.timezone);
  var latestParts = getDatePartsInTimezone_(latest, config.timezone);
  var windowStart = makeDateInTimezone_(earliestParts.year, earliestParts.month - 1,
    earliestParts.day, 0, 0, config.timezone);
  var windowEnd = makeDateInTimezone_(latestParts.year, latestParts.month - 1,
    latestParts.day, 23, 59, config.timezone);
  var busy = getBookingBusyIntervals_(config, windowStart, windowEnd);
  var blackouts = getBookingBlackouts_(config, windowStart, windowEnd);
  var days = [];

  for (var offset = 0; offset <= config.horizonDays; offset += 1) {
    var parts = addDaysToDateParts_(earliestParts, offset);
    var localDay = makeDateInTimezone_(parts.year, parts.month - 1, parts.day,
      0, 0, config.timezone);
    if (config.days.indexOf(Utilities.formatDate(localDay, config.timezone, 'EEE')) === -1) {
      continue;
    }
    var slots = [];
    for (var minuteOfDay = config.startHour * 60;
         minuteOfDay + config.durationMinutes <= config.endHour * 60;
         minuteOfDay += Math.max(1, config.slotIntervalMinutes)) {
      var start = makeDateInTimezone_(parts.year, parts.month - 1, parts.day,
        Math.floor(minuteOfDay / 60), minuteOfDay % 60, config.timezone);
      var end = new Date(start.getTime() + config.durationMinutes * 60 * 1000);
      if (!validateBookingSlotRules_(start, config, now).ok) continue;
      var bufferedStart = start.getTime() - config.bufferBeforeMinutes * 60 * 1000;
      var bufferedEnd = end.getTime() + config.bufferAfterMinutes * 60 * 1000;
      var conflict = busy.some(function(item) {
        return bufferedStart < item.end && bufferedEnd > item.start;
      });
      if (conflict || isBlockedByBlackout_(start, end, blackouts)) continue;
      slots.push({start: start.toISOString(), end: end.toISOString(),
        label: Utilities.formatDate(start, config.timezone, 'h:mm a')});
    }
    if (slots.length) {
      days.push({
        date: Utilities.formatDate(localDay, config.timezone, 'yyyy-MM-dd'),
        label: Utilities.formatDate(localDay, config.timezone, 'EEE, MMM d'),
        slots: slots
      });
    }
  }

  return {
    ok: true,
    code: 'AVAILABILITY_OK',
    timezone: config.timezone,
    owner: config.owner,
    duration_minutes: config.durationMinutes,
    slot_interval_minutes: config.slotIntervalMinutes,
    buffer_before_minutes: config.bufferBeforeMinutes,
    buffer_after_minutes: config.bufferAfterMinutes,
    days: days
  };
}

function createBookingCalendarEvent_(config, details) {
  assertBookingWritesEnabled_();
  var attendees = [];
  if (config.sendGuestInvites && isValidEmail_(details.clientEmail)) {
    attendees.push({email: normalizeEmail_(details.clientEmail)});
  }
  var event = {
    summary: (config.environment === 'TEST' ? '[TEST] ' : '') +
      'Avodah Consultation - ' + String(details.clientName || 'Client'),
    description: [
      'Avodah Operations Hub consultation.',
      'Booking ID: ' + details.bookingId,
      'Lead ID: ' + details.leadId,
      'Intake ID: ' + details.intakeId,
      details.managementUrl ? 'Manage appointment: ' + details.managementUrl : ''
    ].filter(Boolean).join('\n'),
    location: config.createGoogleMeet ? 'Google Meet' : '',
    visibility: 'private',
    transparency: 'opaque',
    guestsCanModify: false,
    guestsCanInviteOthers: false,
    guestsCanSeeOtherGuests: false,
    start: {dateTime: details.start.toISOString(), timeZone: config.timezone},
    end: {dateTime: details.end.toISOString(), timeZone: config.timezone},
    attendees: attendees,
    extendedProperties: {private: {
      source: 'avodah-operations-hub',
      sourceVersion: AVODAH_CONFIG.VERSION,
      environment: config.environment,
      calendarBinding: config.calendarBinding,
      bookingId: details.bookingId,
      leadId: details.leadId,
      intakeId: details.intakeId,
      idempotencyKey: details.idempotencyKey,
      bookingFingerprint: details.fingerprint,
      managementTokenHash: details.managementTokenHash || ''
    }},
    reminders: {useDefault: false, overrides: [
      {method: 'email', minutes: config.emailReminderMinutes},
      {method: 'popup', minutes: config.popupReminderMinutes}
    ]}
  };
  if (config.createGoogleMeet) {
    event.conferenceData = {createRequest: {
      requestId: ('avodah' + details.bookingId + Utilities.getUuid())
        .toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 120),
      conferenceSolutionKey: {type: 'hangoutsMeet'}
    }};
  }
  var options = {
    conferenceDataVersion: config.createGoogleMeet ? 1 : 0,
    sendUpdates: attendees.length ? 'all' : 'none'
  };
  var created = Calendar.Events.insert(event, config.calendarId, options);
  for (var attempt = 0; attempt < 4 && config.createGoogleMeet &&
      !bookingEventMeetLink_(created); attempt += 1) {
    Utilities.sleep(400 + attempt * 200);
    created = Calendar.Events.get(config.calendarId, created.id);
  }
  return created;
}

function readBookingCalendarEvent_(config, eventId) {
  if (!eventId) return null;
  try {
    return Calendar.Events.get(config.calendarId, eventId);
  } catch (error) {
    var message = String(error && error.message ? error.message : error);
    if (/\b(404|410)\b|not found|gone/i.test(message)) return null;
    throw error;
  }
}

function updateBookingCalendarEventTime_(config, eventId, start, end) {
  assertBookingWritesEnabled_();
  return Calendar.Events.patch({
    start: {dateTime: start.toISOString(), timeZone: config.timezone},
    end: {dateTime: end.toISOString(), timeZone: config.timezone}
  }, config.calendarId, eventId, {
    conferenceDataVersion: 1,
    sendUpdates: config.sendGuestInvites ? 'all' : 'none'
  });
}

function deleteBookingCalendarEvent_(config, eventId) {
  if (!eventId) return {ok: true, deleted: false};
  assertBookingWritesEnabled_();
  try {
    Calendar.Events.remove(config.calendarId, eventId, {
      sendUpdates: config.sendGuestInvites ? 'all' : 'none'
    });
    return {ok: true, deleted: true};
  } catch (error) {
    var message = String(error && error.message ? error.message : error);
    if (/\b(404|410)\b|not found|gone/i.test(message)) {
      return {ok: true, deleted: false, alreadyMissing: true};
    }
    return {ok: false, deleted: false, error: message};
  }
}

function bookingEventMeetLink_(event) {
  if (!event) return '';
  if (event.hangoutLink) return event.hangoutLink;
  var points = event.conferenceData && event.conferenceData.entryPoints || [];
  for (var i = 0; i < points.length; i += 1) {
    if (points[i].entryPointType === 'video') return String(points[i].uri || '');
  }
  return '';
}

function bookingEventDate_(eventPart) {
  var value = eventPart && (eventPart.dateTime || eventPart.date);
  if (!value) return null;
  var date = new Date(value);
  return isNaN(date.getTime()) ? null : date;
}

