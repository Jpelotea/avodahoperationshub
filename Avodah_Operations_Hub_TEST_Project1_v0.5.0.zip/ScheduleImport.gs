/**
 * Schedule Import status: the existing preview/commit workflow is preserved.
 * Parser migration is deferred until the Phase 3 booking and reporting gates pass.
 */

