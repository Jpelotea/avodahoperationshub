/** Canonical consultation booking, lifecycle, and reconciliation workflow. */

var AVODAH_ACTIVE_BOOKING_STATUSES = Object.freeze({
  Scheduled: true,
  Confirmed: true,
  Rescheduled: true
});

function bookingActorEmail_() {
  try { return normalizeEmail_(Session.getActiveUser().getEmail()); } catch (ignored) {}
  return '';
}

function firstObjectByHeaderValue_(logicalSheet, header, value) {
  var rows = findRowsByHeaderValue_(logicalSheet, header, value);
  return rows.length ? getObjectRow_(logicalSheet, rows[0]) : null;
}

function resolveBookingIdentity_(payload) {
  var input = payload || {};
  var leadReference = String(input.lead_id || input.leadId || '').trim();
  var intakeReference = String(input.intake_id || input.intakeId || '').trim();
  var submissionReference = String(input.submission_id || input.submissionId || '').trim();
  var intake = null;
  var lead = null;

  if (/^LEAD-/i.test(leadReference)) {
    lead = firstObjectByHeaderValue_('Lead Database', 'Lead ID', leadReference);
  } else if (/^INT-/i.test(leadReference) && !intakeReference) {
    intakeReference = leadReference;
  } else if (leadReference && !submissionReference) {
    submissionReference = leadReference;
  }

  if (intakeReference) {
    intake = firstObjectByHeaderValue_('Intake Submissions', 'Intake ID', intakeReference);
  }
  if (!intake && submissionReference) {
    intake = firstObjectByHeaderValue_('Intake Submissions', 'Submission ID', submissionReference);
  }

  if (intake && !String(intake.record['Lead ID'] || '').trim() &&
      typeof processIntakeSubmissionByRow_ === 'function') {
    processIntakeSubmissionByRow_(intake.rowNumber, 'BOOKING_IDENTITY_RESOLUTION');
    intake = getObjectRow_('Intake Submissions', intake.rowNumber);
  }

  if (!lead && intake) {
    var linkedLeadId = String(intake.record['Lead ID'] || '').trim();
    if (linkedLeadId) lead = firstObjectByHeaderValue_('Lead Database', 'Lead ID', linkedLeadId);
  }
  if (!lead && leadReference) {
    lead = firstObjectByHeaderValue_('Lead Database', 'Lead ID', leadReference);
  }
  if (!lead) {
    return {ok: false, code: 'LEAD_NOT_FOUND', message: 'The linked lead was not found.'};
  }
  if (!intake) {
    var primaryIntakeId = String(lead.record['Primary Intake ID'] || '').trim();
    if (primaryIntakeId) {
      intake = firstObjectByHeaderValue_('Intake Submissions', 'Intake ID', primaryIntakeId);
    }
  }
  if (String(lead.record['Record Status'] || 'ACTIVE').toUpperCase() !== 'ACTIVE') {
    return {ok: false, code: 'LEAD_NOT_ACTIVE', message: 'The lead is not active.'};
  }
  return {ok: true, lead: lead, intake: intake};
}

function bookingFingerprintV4_(leadId, start) {
  var source = String(leadId || '') + '|' + new Date(start).toISOString();
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    source, Utilities.Charset.UTF_8);
  return digest.map(function(byte) {
    var value = byte < 0 ? byte + 256 : byte;
    return ('0' + value.toString(16)).slice(-2);
  }).join('');
}

function findCurrentBookingByField_(header, value, config) {
  if (!value) return null;
  var rows = findRowsByHeaderValue_('Booking Database', header, value);
  for (var i = rows.length - 1; i >= 0; i -= 1) {
    var item = getObjectRow_('Booking Database', rows[i]);
    if (String(item.record['Calendar Binding'] || '') === config.calendarBinding &&
        String(item.record.Environment || '').toUpperCase() === config.environment) {
      return item;
    }
  }
  return null;
}

function findActiveBookingForLead_(leadId, config) {
  var rows = findRowsByHeaderValue_('Booking Database', 'Lead ID', leadId);
  for (var i = rows.length - 1; i >= 0; i -= 1) {
    var item = getObjectRow_('Booking Database', rows[i]);
    var status = String(item.record.Status || '');
    if (String(item.record['Calendar Binding'] || '') === config.calendarBinding &&
        String(item.record.Environment || '').toUpperCase() === config.environment &&
        AVODAH_ACTIVE_BOOKING_STATUSES[status]) return item;
  }
  return null;
}

function bookingResultFromObject_(item, code) {
  var record = item.record;
  return {
    ok: true,
    code: code || 'BOOKING_FOUND',
    http_status: 200,
    retryable: false,
    booking_id: String(record['Booking ID'] || ''),
    lead_id: String(record['Lead ID'] || ''),
    intake_id: String(record['Intake ID'] || ''),
    status: String(record.Status || ''),
    start: record.Start instanceof Date ? record.Start.toISOString() : '',
    end: record.End instanceof Date ? record.End.toISOString() : '',
    meet_link: String(record['Meet Link'] || ''),
    event_id: String(record['Google Event ID'] || '')
  };
}

function bookingManagementParts_() {
  var token = typeof generateManagementToken_ === 'function'
    ? generateManagementToken_() : Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  var hash = typeof hashManagementToken_ === 'function'
    ? hashManagementToken_(token) : token;
  var url = typeof buildManagementUrl_ === 'function' ? buildManagementUrl_(token) : '';
  return {token: token, hash: hash, url: url};
}

function appendBookingDatabaseRecord_(details, config) {
  return appendObjectRow_('Booking Database', {
    'Booking ID': details.bookingId,
    'Lead ID': details.leadId,
    'Intake ID': details.intakeId,
    'Management Token Hash': details.managementTokenHash,
    'Google Event ID': details.eventId,
    'Status': details.status || 'Scheduled',
    'Start': details.start,
    'End': details.end,
    'Meet Link': details.meetLink,
    'Idempotency Key': details.idempotencyKey,
    'Fingerprint': details.fingerprint,
    'Client Name': details.clientName,
    'Client Email': details.clientEmail,
    'Normalized Email': normalizeEmail_(details.clientEmail),
    'Client Phone': details.clientPhone,
    'Normalized Phone': normalizePhone_(details.clientPhone),
    'Cancellation Reason': '',
    'Created At': new Date(),
    'Updated At': new Date(),
    'Last Reconciled': '',
    'Reconciliation Status': 'PENDING_CALENDAR_LOG',
    'Last Error': '',
    'Calendar Binding': config.calendarBinding,
    'Environment': config.environment,
    'Record Status': 'ACTIVE',
    'Source Version': AVODAH_CONFIG.VERSION
  });
}

function calendarLogRecordForBooking_(details, config, status) {
  var parts = getDatePartsInTimezone_(details.start, config.timezone);
  return {
    'Owner': config.owner,
    'Date': makeDateInTimezone_(parts.year, parts.month - 1, parts.day, 0, 0, config.timezone),
    'Start Time': timeFractionInTimezone_(details.start, config.timezone),
    'End Time': timeFractionInTimezone_(details.end, config.timezone),
    'Activity Type': 'Appointment',
    'Location / Link': details.meetLink,
    'Status': status || 'Scheduled',
    'Notes': [
      'Client: ' + String(details.clientName || 'Client'),
      'Lead ID: ' + details.leadId,
      'Intake ID: ' + String(details.intakeId || ''),
      'Booking ID: ' + details.bookingId,
      'Idempotency Key: ' + details.idempotencyKey,
      'Booking Fingerprint: ' + details.fingerprint
    ].join('\n'),
    'Reminder': '1 hour',
    'Category': 'Avodah',
    'Start DateTime': details.start,
    'End DateTime': details.end,
    'Google Event ID': details.eventId,
    'Sync Status': 'Synced',
    'Last Synced': new Date(),
    'Sync Error': '',
    'Record Status': 'Active',
    'Calendar Log ID': details.calendarLogId || generateUniqueId_('CALENDAR'),
    'Source Record Type': 'BOOKING',
    'Source Record ID': details.bookingId,
    'Booking ID': details.bookingId,
    'Idempotency Key': details.idempotencyKey,
    'Created At': details.createdAt || new Date(),
    'Updated At': new Date()
  };
}

function formatCalendarLogBookingRow_(context, row) {
  var map = context.headerMap;
  ['Date'].forEach(function(header) {
    if (map[normalizeHeader_(header)]) context.sheet.getRange(row, map[normalizeHeader_(header)]).setNumberFormat('yyyy-mm-dd');
  });
  ['Start Time', 'End Time'].forEach(function(header) {
    if (map[normalizeHeader_(header)]) context.sheet.getRange(row, map[normalizeHeader_(header)]).setNumberFormat('h:mm AM/PM');
  });
  ['Start DateTime', 'End DateTime', 'Last Synced', 'Created At', 'Updated At'].forEach(function(header) {
    if (map[normalizeHeader_(header)]) context.sheet.getRange(row, map[normalizeHeader_(header)]).setNumberFormat('yyyy-mm-dd h:mm:ss AM/PM');
  });
}

function appendCalendarLogBooking_(details, config, status) {
  var context = getTableContext_('Calendar Log');
  var row = getNextCalendarLogRow_(context.sheet);
  updateObjectRow_('Calendar Log', row, calendarLogRecordForBooking_(details, config, status));
  formatCalendarLogBookingRow_(context, row);
  return row;
}

function findCalendarLogBooking_(bookingId) {
  var rows = findRowsByHeaderValue_('Calendar Log', 'Booking ID', bookingId);
  return rows.length ? getObjectRow_('Calendar Log', rows[rows.length - 1]) : null;
}

function updateCalendarLogBooking_(item, details, config, status) {
  var existingId = String(item.record['Calendar Log ID'] || '') || generateUniqueId_('CALENDAR');
  var record = calendarLogRecordForBooking_(Object.assign({}, details, {
    calendarLogId: existingId,
    createdAt: item.record['Created At'] || new Date()
  }), config, status);
  updateObjectRow_('Calendar Log', item.rowNumber, record);
  formatCalendarLogBookingRow_(item.context, item.rowNumber);
  return item.rowNumber;
}

function updateBookingSourceLinks_(identity, details, config) {
  var actor = bookingActorEmail_();
  if (identity.intake) {
    updateObjectRow_('Intake Submissions', identity.intake.rowNumber, {
      'Follow-up Status': 'Appointment Set',
      'Assigned To': config.owner,
      'Appointment Date': details.start,
      'Booking ID': details.bookingId,
      'Calendar Event ID': details.eventId,
      'Last Processed At': new Date()
    });
  }
  updateObjectRow_('Lead Database', identity.lead.rowNumber, {
    'Assigned To': config.owner,
    'Follow-up Status': 'Appointment Set',
    'Appointment Date': details.start,
    'Booking ID': details.bookingId,
    'Calendar Event ID': details.eventId,
    'Updated At': new Date(),
    'Updated By': actor
  });
}

function clearBookingSourceAppointment_(record) {
  var leadId = String(record['Lead ID'] || '');
  var intakeId = String(record['Intake ID'] || '');
  var lead = leadId ? firstObjectByHeaderValue_('Lead Database', 'Lead ID', leadId) : null;
  var intake = intakeId ? firstObjectByHeaderValue_('Intake Submissions', 'Intake ID', intakeId) : null;
  if (intake) {
    updateObjectRow_('Intake Submissions', intake.rowNumber, {
      'Follow-up Status': 'New',
      'Appointment Date': '',
      'Last Processed At': new Date()
    });
  }
  if (lead) {
    updateObjectRow_('Lead Database', lead.rowNumber, {
      'Follow-up Status': 'New',
      'Appointment Date': '',
      'Updated At': new Date(),
      'Updated By': bookingActorEmail_()
    });
  }
}

function auditBookingAction_(entry) {
  if (typeof logBookingAudit_ === 'function') {
    logBookingAudit_({
      requestId: entry.requestId,
      bookingId: entry.bookingId,
      leadId: entry.leadId,
      action: entry.action,
      previousValue: entry.previousValue || '',
      newValue: entry.newValue || '',
      result: entry.result || 'SUCCESS'
    });
  }
  try {
    logAuditEvent_({
      action: entry.action,
      entityType: 'BOOKING',
      entityId: entry.bookingId,
      result: entry.result || 'SUCCESS',
      requestId: entry.requestId,
      details: entry.details || {}
    });
  } catch (error) {
    console.error('Booking activity audit failed: ' + String(error));
  }
}

function recordBookingIssue_(entry) {
  if (typeof recordReconciliationIssue_ === 'function') {
    recordReconciliationIssue_(entry);
  }
}

function createConsultationBooking(payload) {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
  return createConsultationBooking_(payload || {}, {source: 'INTERNAL'});
}

function createConsultationBooking_(payload, options) {
  var context = options || {};
  if (context.lockHeld) return createConsultationBookingCore_(payload || {}, context);
  return withScriptLock_('create consultation booking', function() {
    return createConsultationBookingCore_(payload || {}, context);
  }, 30000);
}

function createConsultationBookingCore_(payload, options) {
  assertBookingWritesEnabled_();
  var requestId = String(options.requestId || Utilities.getUuid());
  var config = getBookingRuntimeConfig_();
  var identity = resolveBookingIdentity_(payload);
  if (!identity.ok) return Object.assign(identity, {http_status: 404, retryable: false});
  var start = new Date(payload.start);
  var validation = validateBookingSlotRules_(start, config, new Date());
  if (!validation.ok) return Object.assign(validation, {http_status: 400, retryable: false});
  var end = new Date(start.getTime() + config.durationMinutes * 60 * 1000);
  var leadId = String(identity.lead.record['Lead ID'] || '');
  var intakeId = identity.intake ? String(identity.intake.record['Intake ID'] || '') : '';
  var fingerprint = bookingFingerprintV4_(leadId, start);
  var explicitKey = String(payload.idempotency_key || payload.idempotencyKey || '').trim().substring(0, 200);
  var idempotencyKey = explicitKey || ('booking:' + fingerprint);
  var replay = findCurrentBookingByField_('Idempotency Key', idempotencyKey, config);
  if (replay) return bookingResultFromObject_(replay, 'IDEMPOTENT_REPLAY');
  var active = findActiveBookingForLead_(leadId, config);
  if (active) return bookingResultFromObject_(active, 'ALREADY_BOOKED');

  var conflictStart = new Date(start.getTime() - config.bufferBeforeMinutes * 60 * 1000);
  var conflictEnd = new Date(end.getTime() + config.bufferAfterMinutes * 60 * 1000);
  if (bookingCalendarConflictExists_(config, conflictStart, conflictEnd, '')) {
    return {ok: false, code: 'SLOT_UNAVAILABLE', message: 'The selected slot is no longer available.', http_status: 409, retryable: false};
  }
  if (isBlockedByBlackout_(start, end, getBookingBlackouts_(config, conflictStart, conflictEnd))) {
    return {ok: false, code: 'SLOT_UNAVAILABLE', message: 'The selected slot is unavailable.', http_status: 409, retryable: false};
  }

  var bookingId = generateUniqueId_('BOOKING');
  var management = bookingManagementParts_();
  var details = {
    bookingId: bookingId,
    leadId: leadId,
    intakeId: intakeId,
    clientName: String(identity.lead.record['Full Name'] || 'Client'),
    clientEmail: String(identity.lead.record['Email Address'] || ''),
    clientPhone: String(identity.lead.record['Mobile Number'] || ''),
    start: start,
    end: end,
    idempotencyKey: idempotencyKey,
    fingerprint: fingerprint,
    managementTokenHash: management.hash,
    managementUrl: management.url
  };
  var event;
  try {
    event = createBookingCalendarEvent_(config, details);
    details.eventId = String(event.id || '');
    details.meetLink = bookingEventMeetLink_(event);
  } catch (error) {
    auditBookingAction_({requestId: requestId, bookingId: bookingId, leadId: leadId,
      action: 'BOOKING_CALENDAR_CREATE', result: 'FAILED', details: {error: String(error)}});
    return {ok: false, code: 'CALENDAR_CREATE_FAILED', message: 'The calendar event could not be created.', http_status: 502, retryable: true};
  }

  var registryRow;
  try {
    registryRow = appendBookingDatabaseRecord_(details, config);
  } catch (registryError) {
    var registryRollback = deleteBookingCalendarEvent_(config, details.eventId);
    recordBookingIssue_({bookingId: bookingId, leadId: leadId,
      code: 'BOOKING_DATABASE_WRITE_FAILED', details: String(registryError),
      repairAction: registryRollback.ok ? 'Calendar event rolled back' : 'Manual Calendar cleanup required',
      result: registryRollback.ok ? 'ROLLED_BACK' : 'PENDING'});
    return {ok: false, code: registryRollback.ok ? 'BOOKING_DATABASE_WRITE_FAILED' : 'CALENDAR_ROLLBACK_FAILED',
      message: 'The booking could not be saved.', http_status: 500, retryable: registryRollback.ok};
  }

  try {
    appendCalendarLogBooking_(details, config, 'Scheduled');
  } catch (logError) {
    var logRollback = deleteBookingCalendarEvent_(config, details.eventId);
    updateObjectRow_('Booking Database', registryRow, {
      'Status': 'Failed', 'Record Status': 'ERROR', 'Updated At': new Date(),
      'Reconciliation Status': logRollback.ok ? 'ROLLED_BACK' : 'PENDING',
      'Last Error': String(logError)
    });
    recordBookingIssue_({bookingId: bookingId, leadId: leadId,
      code: 'CALENDAR_LOG_WRITE_FAILED', details: String(logError),
      repairAction: logRollback.ok ? 'Calendar event rolled back' : 'Manual reconciliation required',
      result: logRollback.ok ? 'ROLLED_BACK' : 'PENDING'});
    return {ok: false, code: logRollback.ok ? 'CALENDAR_LOG_WRITE_FAILED' : 'CALENDAR_ROLLBACK_FAILED',
      message: 'The booking could not be logged.', http_status: 500, retryable: logRollback.ok};
  }

  var reconciliationPending = false;
  try {
    updateBookingSourceLinks_(identity, details, config);
  } catch (linkError) {
    reconciliationPending = true;
    recordBookingIssue_({bookingId: bookingId, leadId: leadId,
      code: 'SOURCE_LINK_UPDATE_FAILED', details: String(linkError),
      repairAction: 'Run canonical booking reconciliation', result: 'PENDING'});
  }
  updateObjectRow_('Booking Database', registryRow, {
    'Updated At': new Date(),
    'Reconciliation Status': reconciliationPending ? 'PENDING' : 'OK',
    'Last Error': reconciliationPending ? 'Intake or Lead link update is pending.' : ''
  });
  auditBookingAction_({requestId: requestId, bookingId: bookingId, leadId: leadId,
    action: 'BOOKING_CREATED', result: reconciliationPending ? 'RECONCILIATION_PENDING' : 'SUCCESS',
    details: {intakeId: intakeId, eventId: details.eventId}});

  return {
    ok: true,
    code: reconciliationPending ? 'BOOKING_CREATED_RECONCILIATION_PENDING' : 'BOOKING_CREATED',
    http_status: 200,
    retryable: false,
    booking_id: bookingId,
    lead_id: leadId,
    intake_id: intakeId,
    idempotency_key: idempotencyKey,
    start: start.toISOString(),
    end: end.toISOString(),
    meet_link: details.meetLink,
    event_id: details.eventId,
    management_url: management.url,
    reconciliation_required: reconciliationPending
  };
}

function resolveManagedBookingV4_(payload, config) {
  var bookingId = String(payload.booking_id || payload.bookingId || '').trim();
  if (bookingId) return findCurrentBookingByField_('Booking ID', bookingId, config);
  var token = String(payload.management_token || payload.managementToken || '').trim();
  if (!token || typeof hashManagementToken_ !== 'function') return null;
  return findCurrentBookingByField_('Management Token Hash', hashManagementToken_(token), config);
}

function rescheduleConsultationBooking_(payload, options) {
  var context = options || {};
  if (!context.lockHeld) {
    return withScriptLock_('reschedule consultation booking', function() {
      return rescheduleConsultationBooking_(payload, Object.assign({}, context, {lockHeld: true}));
    }, 30000);
  }
  assertBookingWritesEnabled_();
  var requestId = String(context.requestId || Utilities.getUuid());
  var config = getBookingRuntimeConfig_();
  var item = resolveManagedBookingV4_(payload || {}, config);
  if (!item) return {ok: false, code: 'BOOKING_NOT_FOUND', message: 'The booking was not found in the active TEST calendar binding.', http_status: 404, retryable: false};
  if (!AVODAH_ACTIVE_BOOKING_STATUSES[String(item.record.Status || '')]) {
    return {ok: false, code: 'BOOKING_NOT_ACTIVE', message: 'The booking is not active.', http_status: 409, retryable: false};
  }
  var start = new Date(payload.start);
  var validation = validateBookingSlotRules_(start, config, new Date());
  if (!validation.ok) return Object.assign(validation, {http_status: 400, retryable: false});
  var end = new Date(start.getTime() + config.durationMinutes * 60 * 1000);
  var eventId = String(item.record['Google Event ID'] || '');
  var conflictStart = new Date(start.getTime() - config.bufferBeforeMinutes * 60 * 1000);
  var conflictEnd = new Date(end.getTime() + config.bufferAfterMinutes * 60 * 1000);
  if (bookingCalendarConflictExists_(config, conflictStart, conflictEnd, eventId) ||
      isBlockedByBlackout_(start, end, getBookingBlackouts_(config, conflictStart, conflictEnd))) {
    return {ok: false, code: 'SLOT_UNAVAILABLE', message: 'The selected slot is unavailable.', http_status: 409, retryable: false};
  }
  if (!readBookingCalendarEvent_(config, eventId)) {
    updateObjectRow_('Booking Database', item.rowNumber, {
      'Last Reconciled': new Date(), 'Reconciliation Status': 'EVENT_MISSING',
      'Last Error': 'Calendar event not found.'
    });
    return {ok: false, code: 'RECONCILIATION_REQUIRED', message: 'The calendar event is missing.', http_status: 409, retryable: false};
  }
  var previous = item.record.Start instanceof Date ? item.record.Start.toISOString() : '';
  var event = updateBookingCalendarEventTime_(config, eventId, start, end);
  var meetLink = bookingEventMeetLink_(event) || String(item.record['Meet Link'] || '');
  updateObjectRow_('Booking Database', item.rowNumber, {
    'Status': 'Rescheduled', 'Start': start, 'End': end, 'Meet Link': meetLink,
    'Updated At': new Date(), 'Last Reconciled': new Date(),
    'Reconciliation Status': 'OK', 'Last Error': ''
  });
  var details = {
    bookingId: String(item.record['Booking ID'] || ''),
    leadId: String(item.record['Lead ID'] || ''),
    intakeId: String(item.record['Intake ID'] || ''),
    clientName: String(item.record['Client Name'] || 'Client'),
    start: start, end: end, meetLink: meetLink, eventId: eventId,
    idempotencyKey: String(item.record['Idempotency Key'] || ''),
    fingerprint: String(item.record.Fingerprint || '')
  };
  var log = findCalendarLogBooking_(details.bookingId);
  if (log) updateCalendarLogBooking_(log, details, config, 'Rescheduled');
  else appendCalendarLogBooking_(details, config, 'Rescheduled');
  var identity = resolveBookingIdentity_({lead_id: details.leadId, intake_id: details.intakeId});
  if (identity.ok) updateBookingSourceLinks_(identity, details, config);
  auditBookingAction_({requestId: requestId, bookingId: details.bookingId, leadId: details.leadId,
    action: 'BOOKING_RESCHEDULED', previousValue: previous, newValue: start.toISOString(), result: 'SUCCESS'});
  return {ok: true, code: 'BOOKING_RESCHEDULED', http_status: 200, retryable: false,
    booking_id: details.bookingId, start: start.toISOString(), end: end.toISOString(), meet_link: meetLink};
}

function cancelConsultationBooking_(payload, options) {
  var context = options || {};
  if (!context.lockHeld) {
    return withScriptLock_('cancel consultation booking', function() {
      return cancelConsultationBooking_(payload, Object.assign({}, context, {lockHeld: true}));
    }, 30000);
  }
  assertBookingWritesEnabled_();
  var requestId = String(context.requestId || Utilities.getUuid());
  var config = getBookingRuntimeConfig_();
  var item = resolveManagedBookingV4_(payload || {}, config);
  if (!item) return {ok: false, code: 'BOOKING_NOT_FOUND', message: 'The booking was not found in the active TEST calendar binding.', http_status: 404, retryable: false};
  var bookingId = String(item.record['Booking ID'] || '');
  var leadId = String(item.record['Lead ID'] || '');
  if (!AVODAH_ACTIVE_BOOKING_STATUSES[String(item.record.Status || '')]) {
    return {ok: true, code: 'BOOKING_ALREADY_INACTIVE', booking_id: bookingId,
      status: String(item.record.Status || ''), http_status: 200, retryable: false};
  }
  var deletion = deleteBookingCalendarEvent_(config, String(item.record['Google Event ID'] || ''));
  if (!deletion.ok) {
    return {ok: false, code: 'CALENDAR_CANCEL_FAILED', message: 'The calendar event could not be cancelled.', http_status: 502, retryable: true};
  }
  var reason = String(payload.reason || payload.cancellation_reason || '').trim().substring(0, 500);
  updateObjectRow_('Booking Database', item.rowNumber, {
    'Status': 'Cancelled', 'Cancellation Reason': reason, 'Updated At': new Date(),
    'Last Reconciled': new Date(), 'Reconciliation Status': 'OK', 'Last Error': '',
    'Record Status': 'INACTIVE'
  });
  var log = findCalendarLogBooking_(bookingId);
  if (log) {
    updateObjectRow_('Calendar Log', log.rowNumber, {
      'Status': 'Cancelled', 'Sync Status': 'Synced', 'Last Synced': new Date(),
      'Sync Error': '', 'Record Status': 'Archived', 'Updated At': new Date()
    });
  }
  clearBookingSourceAppointment_(item.record);
  auditBookingAction_({requestId: requestId, bookingId: bookingId, leadId: leadId,
    action: 'BOOKING_CANCELLED', result: 'SUCCESS', details: {reason: reason}});
  return {ok: true, code: 'BOOKING_CANCELLED', booking_id: bookingId,
    status: 'Cancelled', http_status: 200, retryable: false};
}

function reconcileBookingRecords_(options) {
  var context = options || {};
  if (!context.lockHeld) {
    return withScriptLock_('reconcile canonical bookings', function() {
      return reconcileBookingRecords_(Object.assign({}, context, {lockHeld: true}));
    }, 30000);
  }
  var enabled = String(PropertiesService.getScriptProperties()
    .getProperty('ENABLE_BOOKING_WORKFLOW') || '').trim().toUpperCase();
  if (enabled !== 'TRUE') {
    return {status: 'BOOKING_WORKFLOW_DISABLED', recordsRead: 0, recordsWritten: 0};
  }
  var requestId = String(context.requestId || ('reconcile-' + Utilities.getUuid()));
  var config = getBookingRuntimeConfig_();
  var rows = getObjectRows_('Booking Database');
  var scoped = rows.filter(function(item) {
    return String(item.record['Calendar Binding'] || '') === config.calendarBinding &&
      String(item.record.Environment || '').toUpperCase() === config.environment;
  });
  var skippedLegacy = rows.length - scoped.length;
  var synchronized = 0;
  var repairedLog = 0;
  var repairedLinks = 0;
  var issues = 0;

  scoped.forEach(function(item) {
    var record = item.record;
    var bookingId = String(record['Booking ID'] || '');
    var leadId = String(record['Lead ID'] || '');
    var event;
    try {
      event = readBookingCalendarEvent_(config, String(record['Google Event ID'] || ''));
    } catch (error) {
      issues += 1;
      updateObjectRow_('Booking Database', item.rowNumber, {
        'Last Reconciled': new Date(), 'Reconciliation Status': 'ERROR',
        'Last Error': String(error)
      });
      recordBookingIssue_({bookingId: bookingId, leadId: leadId,
        code: 'CALENDAR_READ_FAILED', details: String(error),
        repairAction: 'Review Calendar access and rerun reconciliation', result: 'PENDING'});
      return;
    }
    var active = Boolean(AVODAH_ACTIVE_BOOKING_STATUSES[String(record.Status || '')]);
    if (!event) {
      if (active) {
        issues += 1;
        updateObjectRow_('Booking Database', item.rowNumber, {
          'Last Reconciled': new Date(), 'Reconciliation Status': 'EVENT_MISSING',
          'Last Error': 'Calendar event not found.'
        });
        recordBookingIssue_({bookingId: bookingId, leadId: leadId,
          code: 'EVENT_MISSING', details: 'Active bound booking has no Calendar event.',
          repairAction: 'Administrative review required', result: 'PENDING'});
      } else {
        updateObjectRow_('Booking Database', item.rowNumber, {
          'Last Reconciled': new Date(), 'Reconciliation Status': 'OK', 'Last Error': ''
        });
      }
      return;
    }
    var eventStart = bookingEventDate_(event.start);
    var eventEnd = bookingEventDate_(event.end);
    var eventStatus = event.status === 'cancelled' ? 'Cancelled' : String(record.Status || 'Scheduled');
    var details = {
      bookingId: bookingId,
      leadId: leadId,
      intakeId: String(record['Intake ID'] || ''),
      clientName: String(record['Client Name'] || 'Client'),
      start: eventStart || record.Start,
      end: eventEnd || record.End,
      meetLink: bookingEventMeetLink_(event) || String(record['Meet Link'] || ''),
      eventId: String(event.id || record['Google Event ID'] || ''),
      idempotencyKey: String(record['Idempotency Key'] || ''),
      fingerprint: String(record.Fingerprint || '')
    };
    var log = findCalendarLogBooking_(bookingId);
    if (!log && eventStatus !== 'Cancelled' && details.start instanceof Date && details.end instanceof Date) {
      appendCalendarLogBooking_(details, config, eventStatus);
      repairedLog += 1;
    } else if (log) {
      if (eventStatus === 'Cancelled') {
        updateObjectRow_('Calendar Log', log.rowNumber, {
          'Status': 'Cancelled', 'Sync Status': 'Synced', 'Last Synced': new Date(),
          'Record Status': 'Archived', 'Updated At': new Date()
        });
      } else {
        updateCalendarLogBooking_(log, details, config, eventStatus);
      }
    }
    if (eventStatus === 'Cancelled') {
      clearBookingSourceAppointment_(record);
    } else {
      var identity = resolveBookingIdentity_({lead_id: leadId, intake_id: details.intakeId});
      if (identity.ok) {
        updateBookingSourceLinks_(identity, details, config);
        repairedLinks += 1;
      }
    }
    updateObjectRow_('Booking Database', item.rowNumber, {
      'Google Event ID': details.eventId,
      'Status': eventStatus,
      'Start': details.start,
      'End': details.end,
      'Meet Link': details.meetLink,
      'Updated At': new Date(),
      'Last Reconciled': new Date(),
      'Reconciliation Status': 'OK',
      'Last Error': '',
      'Record Status': eventStatus === 'Cancelled' ? 'INACTIVE' : 'ACTIVE'
    });
    synchronized += 1;
  });

  auditBookingAction_({requestId: requestId, bookingId: '', leadId: '',
    action: 'BOOKING_RECONCILIATION', result: issues ? 'ISSUES_FOUND' : 'SUCCESS',
    details: {synchronized: synchronized, repairedLog: repairedLog,
      repairedLinks: repairedLinks, skippedLegacy: skippedLegacy, issues: issues}});
  return {
    ok: true,
    code: issues ? 'RECONCILIATION_COMPLETED_WITH_ISSUES' : 'RECONCILIATION_COMPLETED',
    status: issues ? 'ISSUES_FOUND' : 'SUCCESS',
    recordsRead: scoped.length,
    recordsWritten: synchronized + repairedLog,
    synchronized: synchronized,
    repaired_calendar_log: repairedLog,
    repaired_source_links: repairedLinks,
    skipped_unbound_legacy: skippedLegacy,
    issues_found: issues
  };
}

function reconcileBookingRecordsNow() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  return reconcileBookingRecords_({source: 'INTERNAL_MANUAL'});
}

