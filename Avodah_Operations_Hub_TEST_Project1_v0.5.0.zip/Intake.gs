/** Phase 3.1 canonical Intake -> Lead processing. */

function handleSpreadsheetFormSubmit(event) {
  return runScheduledTask_('handleSpreadsheetFormSubmit', event, function() {
    return processIntakeFormSubmit_(event);
  });
}

function processIntakeFormSubmit_(event) {
  if (!event || !event.range || typeof event.range.getRow !== 'function') {
    throw avodahError_('INVALID_FORM_EVENT',
      'A spreadsheet form-submit event with a source row is required.');
  }
  var sheet = event.range.getSheet();
  if (!sheet || sheet.getName() !== 'Intake Submissions') {
    throw avodahError_('INVALID_FORM_SHEET',
      'The form-submit trigger must point to Intake Submissions.');
  }
  var rowNumber = event.range.getRow();
  return withScriptLock_('Intake row ' + rowNumber, function() {
    return processIntakeSubmissionByRow_(rowNumber, 'FORM_SUBMIT');
  });
}

function processIntakeRow(rowNumber) {
  requireUserRole_(['ADMIN', 'MANAGER']);
  return withScriptLock_('Intake row ' + rowNumber, function() {
    return processIntakeSubmissionByRow_(rowNumber, 'MANUAL');
  });
}

function processPendingIntakes(limit) {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var maximum = Math.min(Math.max(Number(limit || 25), 1), 100);
  var output = withScriptLock_('Pending intake batch', function() {
    var rows = getObjectRows_('Intake Submissions').filter(function(item) {
      return String(item.record['Processing Status'] || '').toUpperCase() !==
        'PROCESSED' || !String(item.record['Lead ID'] || '').trim();
    }).slice(0, maximum);
    var results = [];
    rows.forEach(function(item) {
      try {
        results.push(processIntakeSubmissionByRow_(item.rowNumber, 'MANUAL_BATCH'));
      } catch (error) {
        results.push({
          rowNumber: item.rowNumber,
          status: 'FAILED',
          code: error.code || error.name || 'ERROR',
          message: error.message
        });
      }
    });
    return {
      status: 'COMPLETE',
      recordsRead: rows.length,
      recordsWritten: results.filter(function(item) {
        return item.status === 'PROCESSED';
      }).length,
      failed: results.filter(function(item) { return item.status === 'FAILED'; }).length,
      results: results
    };
  });
  try { console.log(JSON.stringify(output)); } catch (ignored) {}
  return output;
}

function processIntakeSubmissionByRow_(rowNumber, source) {
  var row = getObjectRow_('Intake Submissions', rowNumber);
  var record = row.record;
  var submissionId = String(record['Submission ID'] || '').trim();
  var intakeId = String(record['Intake ID'] || '').trim() ||
    generateUniqueId_('INTAKE');
  var normalizedEmail = normalizeEmail_(record['Email Address']);
  var normalizedPhone = normalizePhone_(record['Mobile Number']);
  var now = new Date();

  if (String(record['Processing Status'] || '').toUpperCase() === 'PROCESSED' &&
      String(record['Lead ID'] || '').trim()) {
    return {
      rowNumber: Number(rowNumber),
      status: 'PROCESSED',
      idempotent: true,
      intakeId: intakeId,
      leadId: String(record['Lead ID']).trim(),
      duplicateStatus: String(record['Duplicate Status'] || '')
    };
  }

  var canonical = {
    'Intake ID': intakeId,
    'Normalized Email': normalizedEmail,
    'Normalized Phone': normalizedPhone,
    'Last Processed At': now
  };
  try {
    validateIntakeRecord_(record, normalizedEmail, normalizedPhone);
    canonical['Processing Status'] = 'PROCESSING';
    updateObjectRow_('Intake Submissions', rowNumber, canonical);
    record['Intake ID'] = intakeId;
    record['Normalized Email'] = normalizedEmail;
    record['Normalized Phone'] = normalizedPhone;
    var actorEmail = '';
    try { actorEmail = getCurrentUserEmail_(); } catch (ignored) {}
    var lead = upsertLeadFromIntake_(record, {
      actorEmail: actorEmail || 'SYSTEM',
      source: source || 'UNKNOWN'
    });
    updateObjectRow_('Intake Submissions', rowNumber, {
      'Intake ID': intakeId,
      'Normalized Email': normalizedEmail,
      'Normalized Phone': normalizedPhone,
      'Lead ID': lead.leadId,
      'Duplicate Status': lead.duplicateStatus,
      'Processing Status': 'PROCESSED',
      'Last Processed At': new Date()
    });
    logAuditEvent_({
      action: lead.created ? 'LEAD_CREATED_FROM_INTAKE' : 'LEAD_UPDATED_FROM_INTAKE',
      entityType: 'LEAD',
      entityId: lead.leadId,
      result: 'SUCCESS',
      details: {
        intakeId: intakeId,
        submissionId: submissionId,
        source: source || 'UNKNOWN',
        duplicateStatus: lead.duplicateStatus,
        inquiryCount: lead.inquiryCount,
        possiblePhoneDuplicate: lead.possiblePhoneDuplicate
      }
    });
    return {
      rowNumber: Number(rowNumber),
      status: 'PROCESSED',
      idempotent: false,
      intakeId: intakeId,
      leadId: lead.leadId,
      leadCreated: lead.created,
      duplicateStatus: lead.duplicateStatus,
      inquiryCount: lead.inquiryCount
    };
  } catch (error) {
    try {
      canonical['Processing Status'] = 'FAILED';
      canonical['Last Processed At'] = new Date();
      updateObjectRow_('Intake Submissions', rowNumber, canonical);
    } catch (updateError) {
      console.error('Unable to mark failed intake row ' + rowNumber + ': ' + updateError);
    }
    try {
      logAuditEvent_({
        action: 'INTAKE_LEAD_PROCESS',
        entityType: 'INTAKE',
        entityId: intakeId,
        result: 'FAILED',
        details: {
          submissionId: submissionId,
          source: source || 'UNKNOWN',
          errorCode: error.code || error.name || 'ERROR',
          errorMessage: error.message
        }
      });
    } catch (logError) {
      console.error('Unable to audit failed intake row ' + rowNumber + ': ' + logError);
    }
    throw error;
  }
}

function validateIntakeRecord_(record, normalizedEmail, normalizedPhone) {
  if (!String(record['Submission ID'] || '').trim()) {
    throw avodahError_('SUBMISSION_ID_REQUIRED', 'Submission ID is required.');
  }
  parseRequiredDate_(record['Submitted At'], 'Submitted At');
  if (!String(record['Full Name'] || '').trim()) {
    throw avodahError_('FULL_NAME_REQUIRED', 'Full Name is required.');
  }
  if (!isConsentGranted_(record['Consent'])) {
    throw avodahError_('CONSENT_REQUIRED',
      'Consent must be explicitly granted before lead processing.');
  }
  if (!isValidEmail_(normalizedEmail)) {
    throw avodahError_('INVALID_EMAIL', 'A valid Email Address is required.');
  }
  if (record['Mobile Number'] && !isValidPhone_(normalizedPhone)) {
    throw avodahError_('INVALID_PHONE', 'Mobile Number is not valid.');
  }
  return true;
}
