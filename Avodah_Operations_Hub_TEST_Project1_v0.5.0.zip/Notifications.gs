/** Notification helper. No message is sent unless explicitly called. */

function sendAdminNotification_(subject, body) {
  var email = PropertiesService.getScriptProperties()
    .getProperty('ADMIN_NOTIFICATION_EMAIL');
  if (!email) return {status: 'SKIPPED_NOT_CONFIGURED'};
  MailApp.sendEmail({to: email, subject: subject, body: body});
  return {status: 'SENT'};
}

