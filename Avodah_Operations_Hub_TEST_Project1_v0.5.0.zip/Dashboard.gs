/**
 * Dashboard status: the existing Dashboard formulas are preserved. The logical
 * Management Dashboard resolves to the existing Dashboard and is never written
 * as an operational source table.
 */

