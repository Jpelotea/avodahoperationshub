/**
 * Analytics status: derived-layer schemas are created, but refresh functions are
 * not activated until operational source migrations and reconciliation pass.
 */

