/** Canonical Lead Database mutations for the Phase 3.1 Intake -> Lead flow. */

function upsertLeadFromIntake_(intakeRecord, options) {
  var normalizedEmail = normalizeEmail_(intakeRecord['Normalized Email'] ||
    intakeRecord['Email Address']);
  var normalizedPhone = normalizePhone_(intakeRecord['Normalized Phone'] ||
    intakeRecord['Mobile Number']);
  var intakeId = String(intakeRecord['Intake ID'] || '').trim();
  var submittedAt = parseRequiredDate_(intakeRecord['Submitted At'], 'Submitted At');
  var actorEmail = normalizeEmail_((options && options.actorEmail) || '') || 'SYSTEM';
  var leads = getObjectRows_('Lead Database');
  var identity = resolveLeadIdentity_(leads, normalizedEmail, normalizedPhone);
  var existing = identity.match;
  var inquiryStats = calculateInquiryStats_(normalizedEmail, normalizedPhone);
  var now = new Date();
  var existingRecord = existing ? existing.record : {};
  var leadId = existing ? String(existingRecord['Lead ID'] || '').trim() :
    generateUniqueId_('LEAD');
  if (!leadId) throw avodahError_('LEAD_ID_MISSING', 'Existing lead has no Lead ID.');

  var duplicateStatus = inquiryStats.count > 1 ? 'REPEAT_INQUIRY' :
    (identity.possiblePhoneDuplicate ? 'POSSIBLE_DUPLICATE_PHONE' : 'UNIQUE');
  var leadRecord = {
    'Lead ID': leadId,
    'Primary Intake ID': existingRecord['Primary Intake ID'] || intakeId,
    'First Inquiry At': inquiryStats.first || submittedAt,
    'Latest Inquiry At': inquiryStats.latest || submittedAt,
    'Full Name': intakeRecord['Full Name'] || existingRecord['Full Name'] || '',
    'Email Address': intakeRecord['Email Address'] || existingRecord['Email Address'] || '',
    'Normalized Email': normalizedEmail || existingRecord['Normalized Email'] || '',
    'Mobile Number': intakeRecord['Mobile Number'] || existingRecord['Mobile Number'] || '',
    'Normalized Phone': normalizedPhone || existingRecord['Normalized Phone'] || '',
    'Location': intakeRecord['Location'] || existingRecord['Location'] || '',
    'Primary Need': intakeRecord['Primary Need'] || existingRecord['Primary Need'] || '',
    'Recommended Service Path': intakeRecord['Recommended Service Path'] ||
      existingRecord['Recommended Service Path'] || '',
    'Lead Source': intakeLeadSource_(intakeRecord) || existingRecord['Lead Source'] || '',
    'Assigned To': intakeRecord['Assigned To'] || existingRecord['Assigned To'] || '',
    'Lead Status': existingRecord['Lead Status'] || 'NEW',
    'Follow-up Status': intakeRecord['Follow-up Status'] ||
      existingRecord['Follow-up Status'] || 'NEW',
    'Last Contacted': intakeRecord['Last Contacted'] || existingRecord['Last Contacted'] || '',
    'Next Follow-up': intakeRecord['Next Follow-up'] || existingRecord['Next Follow-up'] || '',
    'Appointment Date': intakeRecord['Appointment Date'] ||
      existingRecord['Appointment Date'] || '',
    'Booking ID': intakeRecord['Booking ID'] || existingRecord['Booking ID'] || '',
    'Calendar Event ID': intakeRecord['Calendar Event ID'] ||
      existingRecord['Calendar Event ID'] || '',
    'Duplicate Status': duplicateStatus,
    'Inquiry Count': Math.max(inquiryStats.count, 1),
    'Record Status': existingRecord['Record Status'] || 'ACTIVE',
    'Created At': existingRecord['Created At'] || now,
    'Updated At': now,
    'Created By': existingRecord['Created By'] || actorEmail,
    'Updated By': actorEmail
  };

  var rowNumber;
  if (existing) {
    rowNumber = existing.rowNumber;
    updateObjectRow_('Lead Database', rowNumber, leadRecord);
  } else {
    rowNumber = appendObjectRow_('Lead Database', leadRecord);
  }
  return {
    leadId: leadId,
    rowNumber: rowNumber,
    created: !existing,
    duplicateStatus: duplicateStatus,
    inquiryCount: Math.max(inquiryStats.count, 1),
    possiblePhoneDuplicate: identity.possiblePhoneDuplicate
  };
}

function resolveLeadIdentity_(leadRows, normalizedEmail, normalizedPhone) {
  var emailMatches = normalizedEmail ? leadRows.filter(function(item) {
    return normalizeEmail_(item.record['Normalized Email'] ||
      item.record['Email Address']) === normalizedEmail;
  }) : [];
  if (emailMatches.length > 1) {
    throw avodahError_('DUPLICATE_LEAD_IDENTITY',
      'More than one Lead Database row uses the same normalized email.');
  }
  if (emailMatches.length === 1) {
    return {match: emailMatches[0], possiblePhoneDuplicate: false};
  }

  var phoneMatches = normalizedPhone ? leadRows.filter(function(item) {
    return normalizePhone_(item.record['Normalized Phone'] ||
      item.record['Mobile Number']) === normalizedPhone;
  }) : [];
  var compatiblePhoneMatches = phoneMatches.filter(function(item) {
    var leadEmail = normalizeEmail_(item.record['Normalized Email'] ||
      item.record['Email Address']);
    return !leadEmail || !normalizedEmail || leadEmail === normalizedEmail;
  });
  if (compatiblePhoneMatches.length > 1) {
    throw avodahError_('DUPLICATE_LEAD_IDENTITY',
      'More than one compatible Lead Database row uses the same normalized phone.');
  }
  if (compatiblePhoneMatches.length === 1) {
    return {match: compatiblePhoneMatches[0], possiblePhoneDuplicate: false};
  }
  return {match: null, possiblePhoneDuplicate: phoneMatches.length > 0};
}

function calculateInquiryStats_(normalizedEmail, normalizedPhone) {
  var rows = getObjectRows_('Intake Submissions');
  var dates = [];
  rows.forEach(function(item) {
    var rowEmail = normalizeEmail_(item.record['Normalized Email'] ||
      item.record['Email Address']);
    var rowPhone = normalizePhone_(item.record['Normalized Phone'] ||
      item.record['Mobile Number']);
    var matches = normalizedEmail ? rowEmail === normalizedEmail :
      (normalizedPhone && rowPhone === normalizedPhone);
    if (!matches) return;
    var date = new Date(item.record['Submitted At']);
    if (!isNaN(date.getTime())) dates.push(date);
  });
  dates.sort(function(a, b) { return a.getTime() - b.getTime(); });
  return {
    count: dates.length,
    first: dates.length ? dates[0] : null,
    latest: dates.length ? dates[dates.length - 1] : null
  };
}

function intakeLeadSource_(record) {
  return String(record['Form Source'] || record['UTM Source'] ||
    record['Source Page'] || record['Landing Page'] || 'Intake Submissions').trim();
}
