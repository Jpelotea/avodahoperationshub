# System Readiness and Gap Analysis

Assessment date: 2026-07-22 (Asia/Manila)

## Confirmed existing system

The connected Drive contains three relevant native Google Sheets:

- `Calendar_Dashboard_Avodah` — the current central calendar/booking hub,
  timezone `Asia/Manila`, with 16 tabs.
- `Appointment Setter Applicants Tracker` — the current recruitment source,
  with applicant, interview, reference, and source-email structures.
- `Daily Entry_Avodah` — the current Project 1 source, with a 62-column master
  log and derived dashboards.

The central Hub already has working structures for intake, Calendar Log,
Booking Registry, booking reconciliation/audit, booking blackouts, Activity Log,
daily/weekly reports, settings, schedule-import preview/commit, and a formula-
derived dashboard. Live booking records already contain Google event IDs and
Meet links. These structures must be preserved.

The current `Targets & Settings` tab is a formatted multi-block worksheet rather
than the README's row-based settings database. It contains targets, operational
lists, and booking rules. The Foundation therefore appends a separate settings
table on the same sheet and does not replace the existing layout.

The current `Activity Log` is an operational performance log, not a pure audit
log. Writing security/audit events into it would contaminate current reports.
The Foundation uses `Activity Audit Log` as a transitional physical table until
that name collision has an approved migration.

## README-required comparison

| Area | Current evidence | Readiness classification |
|---|---|---|
| Intake | Existing 37-column `Intake Submissions` | Preserve; append processing/link fields |
| Leads | No `Lead Database` in central Hub | Missing; Phase 3.1 |
| Calendar | Existing 18-column `Calendar Log` and person views | Implemented; schema expansion required |
| Booking | Active `Booking Registry`, reconciliation, audit, blackouts | Implemented under legacy name; migration required |
| Recruitment | Separate `Applicant Tracker` and interview sheet | Implemented separately; mapping/history expansion required |
| Project 1 | Separate 62-column master log and dashboards | Implemented separately; point-map conflict requires review |
| Settings | Existing `Targets & Settings` layout | Preserve and expand in place |
| Audit | Operational `Activity Log`; no README `Automation Log` | Semantic collision plus missing automation log |
| Reports | Daily/weekly present | Monthly and unified analytics layers missing |
| Dashboard | Formula-derived `Dashboard` | Preserve as logical Management Dashboard |
| Schedule import | Preview/commit sheets and V3 code candidate exist | Implemented; later parser test required |
| RBAC | No `USER_ROLE` support in latest local code candidate | Missing |
| Apps Script layout | Latest candidate is one 105-function `Code.gs` | Requires safe modular merge |
| Advanced Calendar | Latest local code candidate does not call Advanced service | Not verified/enabled |
| Script Properties | Four properties detected in local candidate | Live property inventory unavailable |
| Triggers/deployments | Cannot be read through the available Drive connector | Requires Apps Script editor inspection |

## Important Project 1 conflict

The current `Daily Entry_Avodah` point model differs materially from the README
mapping. For example, the current implementation includes COP Report, Manu
Academy, tagging, and conditional scoring, while the README specifies a smaller
Recruitment/Sales/JFC matrix totaling 18 sub-activities. The Foundation records
the README matrix in test settings but does not overwrite the current source.
An approved crosswalk is required before migration.

## Foundation status

- Dated isolated copies of all three source Sheets were created and verified.
- Original Sheets were not edited.
- The local modular Foundation package has been created.
- Foundation 0.1.1 avoids the three global names known to collide with the local
  V3 snapshot; the live copied Apps Script project still requires inspection.
- Live Apps Script files, Script Properties, triggers, deployments, trigger
  owners, and authorizations remain unverified.
- No code has been uploaded, no trigger installed, and no web app deployed.

Phase 1 cannot be marked verified until the copied bound Apps Script project is
inspected, duplicate functions are resolved, real properties/roles are supplied,
the Advanced Calendar service is enabled, and the Foundation tests run inside
Apps Script.
