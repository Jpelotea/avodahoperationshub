/** USER_ROLE authorization. Anonymous callers never receive internal access. */

function getCurrentUserEmail_() {
  var email = '';
  try { email = Session.getActiveUser().getEmail(); } catch (ignored) {}
  return normalizeEmail_(email);
}

function getUserRoleRecord_(email) {
  var normalized = normalizeEmail_(email);
  if (!normalized) return null;
  var matches = getActiveSettingsByGroupSafe_('USER_ROLE').filter(function(row) {
    return normalizeEmail_(row.key) === normalized;
  });
  if (!matches.length) return null;
  return {
    email: normalized,
    role: String(matches[0].value || '').trim().toUpperCase(),
    displayName: matches[0].description || ''
  };
}

function requireUserRole_(allowedRoles) {
  var email = getCurrentUserEmail_();
  if (!email) throw avodahError_('AUTH_IDENTITY_UNAVAILABLE',
    'Authenticated Google identity is unavailable for this deployment.');
  var record = getUserRoleRecord_(email);
  if (!record) throw avodahError_('FORBIDDEN', 'No active USER_ROLE assignment exists.');
  var allowed = (allowedRoles || []).map(function(role) {
    return String(role).toUpperCase();
  });
  if (allowed.length && allowed.indexOf(record.role) === -1) {
    throw avodahError_('FORBIDDEN', 'The assigned role cannot perform this action.');
  }
  return record;
}

/**
 * Restricts bootstrap/setup entry points to a direct project-operator run.
 * In a web app that executes as the deployer, a visitor's active identity is
 * blank or differs from the effective project operator, so the call fails.
 */
function requireSetupOperator_() {
  var activeEmail = getCurrentUserEmail_();
  var effectiveEmail = '';
  try {
    effectiveEmail = normalizeEmail_(Session.getEffectiveUser().getEmail());
  } catch (ignored) {}
  if (!activeEmail || !effectiveEmail || activeEmail !== effectiveEmail) {
    throw avodahError_('SETUP_CONTEXT_REQUIRED',
      'Run setup directly from the Apps Script editor as the project operator.');
  }
  var roles = getActiveSettingsByGroupSafe_('USER_ROLE');
  if (roles.length) {
    var record = getUserRoleRecord_(activeEmail);
    if (!record || record.role !== 'ADMIN') {
      throw avodahError_('FORBIDDEN',
        'Only an active ADMIN may change setup after USER_ROLE is configured.');
    }
  }
  return {email: activeEmail, role: roles.length ? 'ADMIN' : 'BOOTSTRAP_OPERATOR'};
}

function bootstrapInitialUserRoles(entries) {
  requireSetupOperator_();
  var existing = getActiveSettingsByGroupSafe_('USER_ROLE');
  if (existing.length) {
    throw avodahError_('USER_ROLE_ALREADY_CONFIGURED',
      'Use setUserRole() after the initial role bootstrap.');
  }
  if (!Array.isArray(entries) || !entries.length) {
    throw avodahError_('USER_ROLE_REQUIRED', 'Provide at least one real user assignment.');
  }
  var activeEmail = getCurrentUserEmail_();
  var includesCallerAdmin = entries.some(function(entry) {
    return normalizeEmail_(entry.email) === activeEmail &&
      String(entry.role || '').toUpperCase() === 'ADMIN';
  });
  if (!activeEmail || !includesCallerAdmin) {
    throw avodahError_('BOOTSTRAP_ADMIN_MISMATCH',
      'The authenticated caller must be included as ADMIN in the initial assignments.');
  }
  return entries.map(function(entry, index) {
    return writeUserRole_(entry.email, entry.role, entry.displayName, true, index + 1);
  });
}

function setUserRole(email, role, displayName, active) {
  requireUserRole_(['ADMIN']);
  return writeUserRole_(email, role, displayName, active !== false, 100);
}

function writeUserRole_(email, role, displayName, active, sortOrder) {
  var normalizedEmail = normalizeEmail_(email);
  var normalizedRole = String(role || '').trim().toUpperCase();
  if (!isValidEmail_(normalizedEmail)) {
    throw avodahError_('INVALID_EMAIL', 'A valid user email is required.');
  }
  if (['ADMIN', 'MANAGER', 'STAFF', 'VIEWER'].indexOf(normalizedRole) === -1) {
    throw avodahError_('INVALID_ROLE', 'Role must be ADMIN, MANAGER, STAFF, or VIEWER.');
  }
  var result = upsertSettingRow_('USER_ROLE', normalizedEmail, normalizedRole,
    'text', active, sortOrder, String(displayName || ''));
  logAuditEvent_({
    action: 'USER_ROLE_UPSERT',
    entityType: 'USER_ROLE',
    entityId: normalizedEmail,
    details: {role: normalizedRole, active: active}
  });
  return result;
}
