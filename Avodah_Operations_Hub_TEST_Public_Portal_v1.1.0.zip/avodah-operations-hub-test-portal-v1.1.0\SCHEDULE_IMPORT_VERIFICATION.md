# Schedule Import Verification - TEST 0.9.0

Verified on 2026-07-22 in the copied TEST spreadsheet and copied Apps Script
project. The production spreadsheet, production Calendar, deployments, and
production triggers were not touched.

## Implemented contract

- `Schedule Import` remains the preserved pasted monthly matrix and is never
  changed by preview or commit.
- `Schedule Import Preview` is a replaceable derived review layer with the 19
  documented columns.
- `Calendar Log` remains the operational destination. Schedule Import does not
  create a Google Calendar event directly.
- Existing public menu entry points remain compatible:
  `previewMonthlyScheduleImport()` delegates to the hardened preview and
  `commitScheduleImportPreview()` delegates to the hardened commit.
- Actual merged ranges are expanded in memory for parsing; source cells are
  not unmerged or rewritten.
- Explicit ranges, single times, Google Meet links, untimed activities, and
  shared merged-cell context are parsed.
- Broad AM/PM phrases such as whole morning, whole afternoon, and whole day do
  not invent exact times. They remain unchecked with
  `Needs Review - Exact Time`.
- Duplicate detection checks both stable Import Keys and normalized
  owner/date/start/title signatures during preview and again under lock at
  commit.
- Preview requires `ENABLE_SCHEDULE_IMPORT_WRITES=TRUE`. Commit additionally
  requires `ENABLE_CALENDAR_WRITES=TRUE` and an ADMIN or MANAGER role.
- Calendar Log writes are header-driven and include a `CAL-` ID, source type,
  source record ID, idempotency key, synchronization state, and timestamps.
- A failed multi-row commit clears its newly written Calendar Log rows and
  restores changed preview status fields.

## Live verification results

| Check | Result |
|---|---|
| Parser and safety validation | 10/10 passed |
| Live preview transaction | 8/8 passed |
| Bounded commit transaction | 4/4 passed |
| Foundation regression checks | 13/13 passed |
| Source merged ranges observed | 5 |
| Preview rows | 194 |
| Needs Review - Exact Time | 26 |
| Duplicate - Calendar Log | 168 |
| Invalid | 0 |
| Ready | 0, because every exact-time July entry already exists |
| TEST fixture rows remaining | 0 |
| Installed triggers | 0 |

The commit transaction created exactly one bounded Calendar Log fixture, wrote
its Calendar Log ID and commit timestamp back to preview, reselected the same
Import Key, and proved that the final duplicate recheck prevented a second
write. The fixture was then removed from both Calendar Log and preview.

## Corrections made during verification

The first live preview run correctly marked all exact-time rows as existing
duplicates, so a test that expected a `Ready` row was too narrow. The assertion
was corrected to verify exact parsed time ranges independently of duplicate
status. The workflow itself did not need a data correction.

The first bounded commit test used a synthetic owner outside Calendar Log's
strict owner validation. The write failed and compensating rollback ran. The
test fixture was changed to use the owner already configured in
`Schedule Import!B3`; the complete transaction then passed 4/4. Validation was
not weakened.

Visual/data QA also exposed that an incomplete AM block could display duplicate
status before review status. Classification precedence was corrected so exact
time review comes first; duplicate checking still runs for timed rows and is
always repeated at commit.

## Setup and source verification

- `masterSetup()` reported version `0.9.0-test-schedule-import`.
- Created sheets: 0.
- Appended headers: 0.
- Seeded settings: 0.
- Existing validations were preserved.
- Trigger status: `SKIPPED_DISABLED`; created triggers: 0.
- 21 Apps Script `.gs` files parsed with a V8-compatible parser.
- 410 declared global functions; 0 duplicate names.
- 0 production spreadsheet ID occurrences.
- Live `Config.gs`, `ScheduleImport.gs`, and `Code.gs` match this package after
  line-ending normalization where applicable.

## Visual verification

Google-rendered QA confirmed frozen headers, checkboxes, date/time formats,
controlled dropdowns, wrapped raw text, visible review/duplicate states, and
blank commit metadata after fixture cleanup. The source matrix remained
unchanged and no TEST fixture string remained in Calendar Log or preview.

## Final safety state

- `ENVIRONMENT=TEST`.
- `ENABLE_SCHEDULE_IMPORT_WRITES=FALSE`.
- All other operational, Calendar, booking, recruitment, Project 1, analytics,
  automation, and public-portal gates are `FALSE`.
- Installed triggers: 0.
- No deployment was created or changed.

## Activation still blocked

Do not commit operator-selected preview rows until the month/year, owner,
review-required times, and duplicate statuses are manually reviewed. Calendar
event synchronization remains a separate later workflow; this phase writes
only Calendar Log. Production promotion still requires the full blueprint
regression checklist, role confirmation, deployment ownership, monitoring, and
rollback approval.
