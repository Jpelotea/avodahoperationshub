# Recruitment Verification — TEST 0.6.0

Verified on 2026-07-22 in the copied Avodah TEST spreadsheet and isolated TEST
Calendar. Production data, triggers, and deployments were not changed.

## Source-of-truth verification

| Responsibility | Verified source |
|---|---|
| Current applicant | `Applicant Tracking` |
| Stage/status history | `Applicant Timeline` |
| Interview transaction and Calendar/Meet binding | `Interview Records` |
| Requirement details | `Requirements Tracker` |
| Onboarding details | `Onboarding Tracker` |
| Controlled stages/statuses | `Targets & Settings` |
| Audit evidence | `Activity Audit Log` |

All five recruitment sheets matched their required schemas before the build.
No existing header was replaced or reordered.

## Tests passed

Validation suite: 7/7.

- Screening/New accepted.
- No Show rejected as a stage.
- Out-of-range interview score rejected.
- Six scores averaged correctly.
- `+63` phone values sanitized as text rather than formulas.
- Initial Interview can advance to Final Interview.
- Final Interview cannot regress to Screening.

Lifecycle suite: 10/10.

- Applicant starts in Screening/New.
- No Show remains a status while the stage stays Initial Interview.
- Initial Interview advances to Final Interview.
- Interview event receives a Google Meet link with no guest invitations.
- Final Interview advances to Requirements.
- Requirement detail rolls a Complete summary into Applicant Tracking.
- Onboarding detail rolls a Complete summary into Applicant Tracking.
- Pipeline closes as Closed/Hired.
- Every movement is retained in Applicant Timeline.
- Every TEST interview event is inactive after cleanup.

## Persisted TEST evidence

- 2 applicant records.
- 18 applicant timeline records.
- 6 interview records.
- 4 requirement records.
- 4 onboarding records.
- 6 Calendar events checked: 0 active, 6 cancelled, 0 inaccessible.
- Both Phone and Normalized Phone fields store their `+63` values as text.

The first lifecycle pass correctly completed the business workflow but exposed
an overly strict cleanup assertion: Google Calendar retains deleted events as
cancelled resources. The assertion was corrected to reject only active events,
then the full lifecycle passed. Visual QA also caught phone values being treated
as formulas; the shared sanitizer and existing TEST rows were repaired and
verified.

## Final safety state

- Environment remains TEST.
- Recruitment, Calendar, Booking, Project 1, automation, and public-portal
  write/activation gates are all disabled.
- No trigger was installed.
- No web deployment was created or updated.
- No guest notification was sent.

## Production gates still open

- Define the real requirement catalog.
- Define the real onboarding checklist and ownership.
- Confirm production interview routing, duration, reminders, and notification
  policy.
- Re-run the complete checklist in a fresh production-candidate copy.
- Review and create a restricted versioned deployment only after approval.

