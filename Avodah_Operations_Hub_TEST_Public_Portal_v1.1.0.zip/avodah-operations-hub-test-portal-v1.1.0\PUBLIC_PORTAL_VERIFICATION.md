# Public Portal Verification - TEST v1.1.0

Date: 2026-07-23 (Asia/Manila)

## Outcome

The public intake, consultation booking, and booking-management interface is
implemented in the copied TEST Apps Script project. It is deployed but remains
feature-gated and cannot write while the activation properties are false.

## Deployment inventory

- Before this phase: no active or archived deployments.
- Active deployment: Version 1.
- Description: `TEST v1.1.0 - public portal staged; all write gates disabled`.
- Deployment ID:
  `AKfycby53XUeA6NcCQt447OfYt1te6h-FOUSEIIFKM9XYoal4RYhwf0m5gRI1Ly7PnWYB9TS`.
- Base URL:
  `https://script.google.com/macros/s/AKfycby53XUeA6NcCQt447OfYt1te6h-FOUSEIIFKM9XYoal4RYhwf0m5gRI1Ly7PnWYB9TS/exec`.
- Execution identity: project owner/deployer.
- Access: Anyone.
- `DEPLOYMENT_ID` and `BOOKING_MANAGEMENT_BASE_URL` are recorded in Script
  Properties.

## Routes

- `/exec`: compatibility status JSON.
- `/exec?view=portal`: public intake and consultation portal.
- `/exec?view=hub`: role-aware internal route. A separate restricted internal
  deployment is still recommended before multi-user activation.

## Implemented controls

- TEST spreadsheet-name and environment binding checks.
- Independent public portal, booking workflow, and Calendar write gates.
- `LockService` around public intake and canonical booking transactions.
- UUID submission idempotency plus email match on retry.
- Script-cache rate limiting and a honeypot field.
- Server-side email, phone, consent, length, and control-character validation.
- Formula-injection-safe spreadsheet writes through the existing database layer.
- Signed one-hour public booking workflow tokens using the configured webhook
  secret.
- Tamper and expiration rejection for workflow tokens.
- Private management-token verification for status, reschedule, and cancel.
- DOM-safe client rendering with dynamic values assigned using `textContent`.
- Default status route retained for compatibility.

## Tests

The consolidated live Apps Script validation returned 127/127 passing
assertions:

- Foundation: 13/13
- Intake and Leads: 8/8
- Booking rules: 12/12
- Project 1: 31/31
- Recruitment: 7/7
- Analytics: 9/9
- Scheduled reporting: 12/12
- Schedule Import: 10/10
- Security gates: 10/10
- Public Portal: 15/15

The anonymous network checks returned:

- Default route: HTTP 200 JSON reporting
  `2026-07-23-test-portal-v1.1.0`.
- Portal route: HTTP 200 HTML with the disabled portal copy and no Google
  sign-in requirement.

## Final readiness audit

- Required logical sheets: 24/24 present.
- Advanced Calendar service: available.
- Active ADMIN roles: 1.
- Installed triggers: 0.
- Trigger definitions: valid.
- Deployment ID: configured.
- Deployed version: reachable and current.
- Booking-management URL: configured.
- Public portal implementation: implemented and feature-gated.
- Ready for controlled TEST: yes.
- Ready for production: no.

## Blocking configuration

The stored webhook secret is shorter than the required 24-character minimum for
signed public workflow tokens. Its value was not copied into source code or this
report. The administrator must supply a new random secret of at least 32
characters before any public or booking gate is enabled.

After secret rotation, the next controlled TEST must temporarily enable only the
portal, booking, and Calendar gates; run the full intake-to-booking-to-cancel
lifecycle; verify Calendar, Meet, Booking Database, Calendar Log, Intake, Lead,
Activity Log, and Automation Log; then disable the gates again.

Production, automation triggers, and the production spreadsheet were untouched.
