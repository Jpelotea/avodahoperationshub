/** Validation installation that preserves any existing validation rules. */

function applyFoundationValidations_() {
  var results = [];
  results.push(ensureListValidationForColumn_('Calendar Log', 'Owner',
    settingValues_('TEAM_MEMBER')));
  results.push(ensureListValidationForColumn_('Calendar Log', 'Status',
    settingValues_('CALENDAR_STATUS')));
  results.push(ensureListValidationForColumn_('Calendar Log', 'Category',
    settingValues_('CALENDAR_CATEGORY')));
  results.push(ensureListValidationForColumn_('Lead Database', 'Lead Status',
    settingValues_('LEAD_STATUS')));
  results.push(ensureListValidationForColumn_('Lead Database', 'Follow-up Status',
    settingValues_('FOLLOW_UP_STATUS')));
  results.push(ensureListValidationForColumn_('Applicant Tracking', 'Current Stage',
    settingValues_('RECRUITMENT_STAGE')));
  results.push(ensureListValidationForColumn_('Applicant Tracking', 'Current Status',
    settingValues_('RECRUITMENT_STATUS')));
  results.push(ensureListValidationForColumn_('Applicant Tracking', 'Record Status',
    ['ACTIVE', 'VOID']));
  results.push(ensureListValidationForColumn_('Interview Records', 'Interview Type',
    settingValues_('INTERVIEW_TYPE')));
  results.push(ensureListValidationForColumn_('Interview Records', 'Interview Status',
    settingValues_('INTERVIEW_STATUS')));
  results.push(ensureListValidationForColumn_('Interview Records', 'Interview Result',
    settingValues_('INTERVIEW_RESULT')));
  results.push(ensureListValidationForColumn_('Requirements Tracker', 'Status',
    settingValues_('REQUIREMENT_STATUS')));
  results.push(ensureListValidationForColumn_('Onboarding Tracker', 'Status',
    settingValues_('ONBOARDING_STATUS')));
  ['Communication Score', 'Customer Service Score', 'Selling Background Score',
    'Quota Experience Score', 'Handling Objections Score',
    'Appointment Strategy Score', 'Overall Score'].forEach(function(header) {
    results.push(ensureNumberRangeValidationForColumn_(
      'Interview Records', header, 1, 5));
  });
  ['Application Date', 'Initial Interview Date', 'Final Interview Date'].forEach(
    function(header) {
      results.push(ensureDateValidationForColumn_('Applicant Tracking', header));
    });
  ['Scheduled Start', 'Scheduled End'].forEach(function(header) {
    results.push(ensureDateTimeValidationForColumn_('Interview Records', header));
  });
  ['Submitted At', 'Verified At'].forEach(function(header) {
    results.push(ensureDateTimeValidationForColumn_('Requirements Tracker', header));
  });
  results.push(ensureDateValidationForColumn_('Onboarding Tracker', 'Due Date'));
  results.push(ensureDateTimeValidationForColumn_('Onboarding Tracker', 'Completed At'));
  results.push(ensureListValidationForColumn_('Project 1 Activity Database',
    'Activity Type', project1ActivityTypes_()));
  results.push(ensureListValidationForColumn_('Project 1 Activity Database',
    'Sub-Activity', project1SubActivities_()));
  results.push(ensureListValidationForColumn_('Project 1 Activity Database',
    'Team Member', project1TeamMemberOptions_()));
  results.push(ensureListValidationForColumn_('Project 1 Activity Database',
    'Record Status', ['ACTIVE', 'VOID']));
  results.push(ensureDateValidationForColumn_('Project 1 Activity Database',
    'Activity Date'));
  return results.filter(function(result) { return result != null; });
}

function ensureDateTimeValidationForColumn_(logicalSheetName, headerName) {
  var result = ensureDateValidationForColumn_(logicalSheetName, headerName);
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(getHubSpreadsheet_(), definition);
  if (sheet) {
    var column = getHeaderMap_(sheet, 1, sheet.getLastColumn())[
      normalizeHeader_(headerName)];
    if (column) sheet.getRange(2, column, Math.max(sheet.getMaxRows() - 1, 1), 1)
      .setNumberFormat('yyyy-mm-dd hh:mm');
  }
  return result;
}

function ensureNumberRangeValidationForColumn_(logicalSheetName, headerName, min, max) {
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(getHubSpreadsheet_(), definition);
  if (!sheet) return {sheet: logicalSheetName, header: headerName,
    status: 'SKIPPED_MISSING'};
  var column = getHeaderMap_(sheet, 1, sheet.getLastColumn())[
    normalizeHeader_(headerName)];
  if (!column) return {sheet: sheet.getName(), header: headerName,
    status: 'SKIPPED_HEADER'};
  var range = sheet.getRange(2, column, Math.max(sheet.getMaxRows() - 1, 1), 1);
  if (range.getDataValidations().some(function(row) { return Boolean(row[0]); })) {
    range.setNumberFormat('0.00');
    return {sheet: sheet.getName(), header: headerName, status: 'PRESERVED_EXISTING'};
  }
  var rule = SpreadsheetApp.newDataValidation().requireNumberBetween(min, max)
    .setAllowInvalid(false).build();
  range.setDataValidation(rule).setNumberFormat('0.00');
  return {sheet: sheet.getName(), header: headerName, status: 'APPLIED'};
}

function ensureDateValidationForColumn_(logicalSheetName, headerName) {
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) return {sheet: logicalSheetName, header: headerName, status: 'SKIPPED_MISSING'};
  var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
  var column = map[normalizeHeader_(headerName)];
  if (!column) return {sheet: sheet.getName(), header: headerName, status: 'SKIPPED_HEADER'};
  var rowCount = Math.max(sheet.getMaxRows() - 1, 1);
  var range = sheet.getRange(2, column, rowCount, 1);
  var existing = range.getDataValidations();
  if (existing.some(function(row) { return Boolean(row[0]); })) {
    range.setNumberFormat('yyyy-mm-dd');
    return {sheet: sheet.getName(), header: headerName, status: 'PRESERVED_EXISTING'};
  }
  var rule = SpreadsheetApp.newDataValidation()
    .requireDate()
    .setAllowInvalid(false)
    .build();
  range.setDataValidation(rule);
  range.setNumberFormat('yyyy-mm-dd');
  return {sheet: sheet.getName(), header: headerName, status: 'APPLIED'};
}

function settingValues_(groupName) {
  return getActiveSettingsByGroupSafe_(groupName).map(function(row) {
    return String(row.value == null ? row.key : row.value);
  }).filter(function(value, index, all) {
    return value && all.indexOf(value) === index;
  });
}

function ensureListValidationForColumn_(logicalSheetName, headerName, values) {
  if (!values || !values.length) {
    return {sheet: logicalSheetName, header: headerName, status: 'SKIPPED_NO_VALUES'};
  }
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) return {sheet: logicalSheetName, header: headerName, status: 'SKIPPED_MISSING'};
  var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
  var column = map[normalizeHeader_(headerName)];
  if (!column) return {sheet: sheet.getName(), header: headerName, status: 'SKIPPED_HEADER'};
  var rowCount = Math.max(sheet.getMaxRows() - 1, 1);
  var range = sheet.getRange(2, column, rowCount, 1);
  var existing = range.getDataValidations();
  var hasExisting = existing.some(function(row) { return Boolean(row[0]); });
  if (hasExisting) {
    return {sheet: sheet.getName(), header: headerName, status: 'PRESERVED_EXISTING'};
  }
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(values, true)
    .setAllowInvalid(false)
    .build();
  range.setDataValidation(rule);
  return {sheet: sheet.getName(), header: headerName, status: 'APPLIED'};
}
