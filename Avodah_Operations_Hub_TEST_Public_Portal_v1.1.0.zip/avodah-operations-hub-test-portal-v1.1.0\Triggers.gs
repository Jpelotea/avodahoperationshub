/** Safe, de-duplicated trigger installation and stable trigger entry points. */

function installRequiredTriggers_() {
  var validation = validateRequiredTriggerDefinitions_();
  if (!validation.valid) {
    throw avodahError_('INVALID_TRIGGER_DEFINITIONS',
      'Trigger definitions failed validation: ' + validation.errors.join('; '));
  }
  var removedLegacy = [];
  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (trigger.getHandlerFunction() !== 'scheduledBookingReconciliation') return;
    ScriptApp.deleteTrigger(trigger);
    removedLegacy.push('scheduledBookingReconciliation');
  });
  var existing = ScriptApp.getProjectTriggers();
  var handlers = {};
  existing.forEach(function(trigger) { handlers[trigger.getHandlerFunction()] = true; });
  var created = [];
  AVODAH_CONFIG.TRIGGER_DEFINITIONS.forEach(function(definition) {
    if (handlers[definition.handler]) return;
    var builder = ScriptApp.newTrigger(definition.handler).timeBased();
    if (definition.type === 'HOURLY') builder.everyHours(1).create();
    if (definition.type === 'EVERY_6_HOURS') builder.everyHours(6).create();
    if (definition.type === 'WEEKLY_MONDAY_7') {
      builder.onWeekDay(ScriptApp.WeekDay.MONDAY).atHour(7).create();
    }
    if (definition.type === 'MONTHLY_DAY_1_7') {
      builder.onMonthDay(1).atHour(7).create();
    }
    created.push(definition.handler);
    handlers[definition.handler] = true;
  });
  return {status: 'INSTALLED', created: created, removedLegacy: removedLegacy};
}

function listInstalledAvodahTriggers() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var managed = AVODAH_CONFIG.TRIGGER_DEFINITIONS.map(function(item) {
    return item.handler;
  }).concat(['handleSpreadsheetFormSubmit', 'scheduledBookingReconciliation']);
  return ScriptApp.getProjectTriggers().filter(function(trigger) {
    return managed.indexOf(trigger.getHandlerFunction()) !== -1;
  }).map(function(trigger) {
    return {
      handler: trigger.getHandlerFunction(),
      eventType: String(trigger.getEventType()),
      source: String(trigger.getTriggerSource()),
      uniqueId: trigger.getUniqueId()
    };
  });
}

function installSpreadsheetFormSubmitTrigger() {
  requireUserRole_(['ADMIN']);
  var enabled = PropertiesService.getScriptProperties()
    .getProperty('ENABLE_AUTOMATION_TRIGGERS');
  if (!truthy_(enabled)) {
    throw avodahError_('AUTOMATION_TRIGGERS_DISABLED',
      'Set ENABLE_AUTOMATION_TRIGGERS=TRUE only during reviewed activation.');
  }
  var existing = ScriptApp.getProjectTriggers().some(function(trigger) {
    return trigger.getHandlerFunction() === 'handleSpreadsheetFormSubmit';
  });
  if (existing) return {status: 'ALREADY_INSTALLED'};
  ScriptApp.newTrigger('handleSpreadsheetFormSubmit')
    .forSpreadsheet(getHubSpreadsheet_())
    .onFormSubmit()
    .create();
  return {status: 'INSTALLED'};
}

function removeAvodahTriggers() {
  requireUserRole_(['ADMIN']);
  var managed = AVODAH_CONFIG.TRIGGER_DEFINITIONS.map(function(item) {
    return item.handler;
  }).concat(['handleSpreadsheetFormSubmit', 'scheduledBookingReconciliation']);
  var removed = [];
  ScriptApp.getProjectTriggers().forEach(function(trigger) {
    if (managed.indexOf(trigger.getHandlerFunction()) === -1) return;
    ScriptApp.deleteTrigger(trigger);
    removed.push(trigger.getHandlerFunction());
  });
  return {removed: removed};
}

function runHourlyFollowUpChecks(event) {
  return runScheduledTask_('runHourlyFollowUpChecks', event, function() {
    if (typeof processDueFollowUps_ !== 'function') return phaseInactive_('INTAKE_LEADS');
    return processDueFollowUps_();
  });
}

function reconcileBookingRecords(event) {
  return runScheduledTask_('reconcileBookingRecords', event, function() {
    if (typeof reconcileBookingRecords_ !== 'function') return phaseInactive_('BOOKINGS');
    return reconcileBookingRecords_();
  });
}

function scheduledDashboardRefresh(event) {
  return runScheduledTask_('scheduledDashboardRefresh', event, function() {
    if (typeof generateDailyReport_ !== 'function') return phaseInactive_('ANALYTICS');
    return generateDailyReport_();
  });
}

function scheduledWeeklyReport(event) {
  return runScheduledTask_('scheduledWeeklyReport', event, function() {
    if (typeof generateWeeklyReport_ !== 'function') return phaseInactive_('ANALYTICS');
    return generateWeeklyReport_();
  });
}

function scheduledMonthlyReport(event) {
  return runScheduledTask_('scheduledMonthlyReport', event, function() {
    if (typeof generateMonthlyReport_ !== 'function') return phaseInactive_('ANALYTICS');
    return generateMonthlyReport_();
  });
}

function runScheduledTask_(handler, event, callback) {
  var startedAt = new Date();
  try {
    assertAuthorizedTriggerEvent_(handler, event);
    var output = callback();
    logAutomationSafe_({
      handler: handler,
      triggerUid: event && event.triggerUid || '',
      startedAt: startedAt,
      finishedAt: new Date(),
      status: output && output.status === 'PHASE_NOT_ACTIVE' ? 'SKIPPED' : 'SUCCESS',
      details: output
    });
    return output;
  } catch (error) {
    logAutomationSafe_({
      handler: handler,
      triggerUid: event && event.triggerUid || '',
      startedAt: startedAt,
      finishedAt: new Date(),
      status: 'FAILED',
      errorCode: error.code || error.name,
      errorMessage: error.message
    });
    throw error;
  }
}

function assertAuthorizedTriggerEvent_(handler, event) {
  if (!truthy_(PropertiesService.getScriptProperties()
      .getProperty('ENABLE_AUTOMATION_TRIGGERS'))) {
    throw avodahError_('AUTOMATION_TRIGGERS_DISABLED',
      'Scheduled automation is disabled until reviewed activation.');
  }
  var triggerUid = String(event && event.triggerUid || '');
  if (!triggerUid) {
    throw avodahError_('TRIGGER_EVENT_REQUIRED',
      'This callback may run only from an installed project trigger.');
  }
  var matched = ScriptApp.getProjectTriggers().some(function(trigger) {
    return String(trigger.getUniqueId()) === triggerUid &&
      trigger.getHandlerFunction() === handler;
  });
  if (!matched) {
    throw avodahError_('UNRECOGNIZED_TRIGGER_EVENT',
      'The trigger event is not registered for this handler.');
  }
  return true;
}

function phaseInactive_(moduleName) {
  return {status: 'PHASE_NOT_ACTIVE', module: moduleName};
}

function validateRequiredTriggerDefinitions_() {
  var expected = {
    runHourlyFollowUpChecks: 'HOURLY',
    reconcileBookingRecords: 'HOURLY',
    scheduledDashboardRefresh: 'EVERY_6_HOURS',
    scheduledWeeklyReport: 'WEEKLY_MONDAY_7',
    scheduledMonthlyReport: 'MONTHLY_DAY_1_7'
  };
  var available = {
    runHourlyFollowUpChecks: typeof runHourlyFollowUpChecks === 'function',
    reconcileBookingRecords: typeof reconcileBookingRecords === 'function',
    scheduledDashboardRefresh: typeof scheduledDashboardRefresh === 'function',
    scheduledWeeklyReport: typeof scheduledWeeklyReport === 'function',
    scheduledMonthlyReport: typeof scheduledMonthlyReport === 'function'
  };
  var seen = {};
  var errors = [];
  var definitions = AVODAH_CONFIG.TRIGGER_DEFINITIONS || [];

  definitions.forEach(function(definition) {
    var handler = String(definition && definition.handler || '');
    var type = String(definition && definition.type || '');
    if (!handler || !Object.prototype.hasOwnProperty.call(expected, handler)) {
      errors.push('Unknown handler: ' + (handler || '(blank)'));
      return;
    }
    if (seen[handler]) errors.push('Duplicate handler: ' + handler);
    seen[handler] = true;
    if (type !== expected[handler]) {
      errors.push('Invalid schedule for ' + handler + ': ' + type);
    }
    if (!available[handler]) errors.push('Missing callback: ' + handler);
  });

  Object.keys(expected).forEach(function(handler) {
    if (!seen[handler]) errors.push('Missing definition: ' + handler);
  });
  return {
    valid: errors.length === 0 && definitions.length === Object.keys(expected).length,
    definitionCount: definitions.length,
    errors: errors
  };
}
