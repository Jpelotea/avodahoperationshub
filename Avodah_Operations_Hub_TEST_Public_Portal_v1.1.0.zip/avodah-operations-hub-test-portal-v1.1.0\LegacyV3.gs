function getConfiguredTestSpreadsheetId_() {
  const properties = PropertiesService.getScriptProperties();
  const environment = String(properties.getProperty("ENVIRONMENT") || "").trim().toUpperCase();
  const spreadsheetId = String(properties.getProperty("AVODAH_SPREADSHEET_ID") || "").trim();

  if (environment !== "TEST") {
    throw new Error("This package is TEST-only. Set ENVIRONMENT=TEST before running any function.");
  }
  if (!spreadsheetId) {
    throw new Error("AVODAH_SPREADSHEET_ID is required in Script Properties.");
  }

  const spreadsheet = SpreadsheetApp.openById(spreadsheetId);
  if (!/^TEST(?:\s|-)/i.test(spreadsheet.getName())) {
    throw new Error("TEST safety check failed: the configured spreadsheet name must begin with TEST.");
  }
  return spreadsheetId;
}

// Fail closed before any legacy V3 entry point can open a spreadsheet.
const SPREADSHEET_ID = getConfiguredTestSpreadsheetId_();
const LEADS_SHEET_NAME = "Intake Submissions";
const CALENDAR_LOG_SHEET_NAME = "Calendar Log";
const SETTINGS_SHEET_NAME = "Targets & Settings";
const BOOKING_SETTINGS_RANGE = "U3:V14";
const SCHEDULE_IMPORT_SHEET_NAME = "Schedule Import";
const SCHEDULE_PREVIEW_SHEET_NAME = "Schedule Import Preview";
const CHRISTINE_CALENDAR_SHEET_NAME = "Ma'am Christine Calendar";
const PRODUCTION_VERSION = "2026-07-23-test-portal-v1.1.0";
const DEFAULT_TIMEZONE = "Asia/Manila";
const BOOKING_AUDIT_SHEET_NAME = "Booking Audit";
const BOOKING_BLACKOUTS_SHEET_NAME = "Booking Blackouts";
const BOOKING_REGISTRY_SHEET_NAME = "Booking Registry";
const BOOKING_RECONCILIATION_SHEET_NAME = "Booking Reconciliation";
const BOOKING_MANAGEMENT_DEFAULT_URL = "";
const BOOKING_ADMIN_DEFAULT_EMAIL = "";
const ACTIVE_BOOKING_STATUSES = new Set(["Scheduled", "Confirmed", "Rescheduled"]);
const BOOKING_SETTINGS_RANGE_V2 = "U3:V20";

function doPost(e) {
  const requestId = Utilities.getUuid();
  let lock = null;

  try {
    const contentType = String((e && e.postData && e.postData.type) || "").toLowerCase();
    if (contentType && !contentType.includes("application/json")) {
      return apiJsonResponse_({
        ok: false,
        code: "UNSUPPORTED_CONTENT_TYPE",
        message: "Content-Type must be application/json.",
        http_status: 415,
        retryable: false
      }, requestId);
    }

    let payload;
    try {
      payload = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    } catch (parseError) {
      return apiJsonResponse_({
        ok: false,
        code: "INVALID_JSON",
        message: "The request body is not valid JSON.",
        http_status: 400,
        retryable: false
      }, requestId);
    }

    if (!isAuthorizedWebhookSecret_(payload.secret)) {
      return apiJsonResponse_({
        ok: false,
        code: "UNAUTHORIZED",
        message: "Unauthorized request.",
        http_status: 401,
        retryable: false
      }, requestId);
    }

    if (payload.action === "availability") {
      return apiJsonResponse_(typeof getBookingAvailability_ === "function"
        ? getBookingAvailability_() : getAvailability_(), requestId);
    }

    if (payload.action === "booking_status") {
      return apiJsonResponse_(getManagedBookingStatus_(payload, requestId), requestId);
    }

    const lockActions = new Set(["book", "submit", "reschedule", "cancel", "reconcile"]);
    if (lockActions.has(payload.action) || Array.isArray(payload.row)) {
      lock = acquireScriptLock_();
      if (!lock) {
        return apiJsonResponse_({
          ok: false,
          code: "SYSTEM_BUSY",
          message: "The booking service is busy. Please retry shortly.",
          http_status: 503,
          retryable: true
        }, requestId);
      }
    }

    if (payload.action === "book") {
      return apiJsonResponse_(typeof createConsultationBooking_ === "function"
        ? createConsultationBooking_(payload, {requestId: requestId, lockHeld: true, source: "PUBLIC_WEBHOOK"})
        : bookConsultation_(payload, requestId), requestId);
    }

    if (payload.action === "reschedule") {
      return apiJsonResponse_(typeof rescheduleConsultationBooking_ === "function"
        ? rescheduleConsultationBooking_(payload, {requestId: requestId, lockHeld: true, source: "PUBLIC_WEBHOOK"})
        : rescheduleManagedBooking_(payload, requestId), requestId);
    }

    if (payload.action === "cancel") {
      return apiJsonResponse_(typeof cancelConsultationBooking_ === "function"
        ? cancelConsultationBooking_(payload, {requestId: requestId, lockHeld: true, source: "PUBLIC_WEBHOOK"})
        : cancelManagedBooking_(payload, requestId), requestId);
    }

    if (payload.action === "reconcile") {
      return apiJsonResponse_(typeof reconcileBookingRecords_ === "function"
        ? reconcileBookingRecords_({requestId: requestId, lockHeld: true, source: "PUBLIC_WEBHOOK"})
        : reconcileBookingData_(requestId), requestId);
    }

    // Explicit submit action is preferred, while legacy row-only payloads remain
    // supported so already-deployed clients continue to work.
    if (payload.action === "submit" || Array.isArray(payload.row)) {
      return apiJsonResponse_(appendLead_(payload.row), requestId);
    }

    return apiJsonResponse_({
      ok: false,
      code: "INVALID_ACTION",
      message: "Unsupported action.",
      http_status: 400,
      retryable: false
    }, requestId);
  } catch (error) {
    console.error(error && error.stack ? error.stack : error);
    return apiJsonResponse_({
      ok: false,
      code: "INTERNAL_ERROR",
      message: "Unable to process request.",
      http_status: 500,
      retryable: true
    }, requestId);
  } finally {
    if (lock && lock.hasLock()) lock.releaseLock();
  }
}

function doGet(e) {
  const view = String(e && e.parameter && e.parameter.view || "")
    .trim().toLowerCase();
  if (view === "portal" && typeof foundationPublicDoGet_ === "function") {
    return foundationPublicDoGet_();
  }
  if (view === "hub" && typeof foundationDoGet_ === "function") {
    return foundationDoGet_();
  }
  return jsonResponse_({
    ok: true,
    service: "Avodah Operations Hub",
    version: PRODUCTION_VERSION,
    timezone: DEFAULT_TIMEZONE,
    server_iso_now: new Date().toISOString()
  });
}

function appendLead_(row) {
  if (!Array.isArray(row) || row.length !== 24) {
    return { ok: false, code: "INVALID_ROW", error: "Invalid row" };
  }

  const leadId = String(row[0] || "").trim();
  if (!isUuidV4_(leadId)) {
    return { ok: false, code: "INVALID_LEAD_ID", error: "Submission ID must be a UUID v4" };
  }

  const sheet = SpreadsheetApp.openById(SPREADSHEET_ID).getSheetByName(LEADS_SHEET_NAME);
  if (!sheet) throw new Error("Intake Submissions sheet was not found.");

  // Make website retries idempotent. A slow network response must not create
  // duplicate rows for the same visitor/submission.
  const lastRow = sheet.getLastRow();
  if (lastRow >= 2) {
    const existing = sheet
      .getRange(2, 1, lastRow - 1, 1)
      .createTextFinder(leadId)
      .matchEntireCell(true)
      .findNext();
    if (existing) {
      const promotion = typeof processIntakeSubmissionByRow_ === "function"
        ? processIntakeSubmissionByRow_(existing.getRow(), "LEGACY_WEBHOOK_RETRY")
        : null;
      return {
        ok: true,
        duplicate: true,
        lead_id: leadId,
        canonical_lead_id: promotion && promotion.leadId || "",
        intake_id: promotion && promotion.intakeId || "",
        duplicate_status: promotion && promotion.duplicateStatus || ""
      };
    }
  }

  sheet.appendRow(row.map(safeCell_));
  SpreadsheetApp.flush();
  const intakeRow = sheet.getLastRow();
  const promotion = typeof processIntakeSubmissionByRow_ === "function"
    ? processIntakeSubmissionByRow_(intakeRow, "LEGACY_WEBHOOK")
    : null;
  return {
    ok: true,
    lead_id: leadId,
    canonical_lead_id: promotion && promotion.leadId || "",
    intake_id: promotion && promotion.intakeId || "",
    duplicate_status: promotion && promotion.duplicateStatus || ""
  };
}

function getBookingConfig_() {
  const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
  const settingsSheet = spreadsheet.getSheetByName(SETTINGS_SHEET_NAME);
  if (!settingsSheet) throw new Error("Targets & Settings sheet was not found.");

  const properties = PropertiesService.getScriptProperties();
  const configuredCalendarId = String(
    properties.getProperty("CHRISTINE_CALENDAR_ID") || ""
  ).trim();
  if (!configuredCalendarId) {
    throw new Error("CHRISTINE_CALENDAR_ID is required in Script Properties.");
  }

  const values = settingsSheet.getRange(BOOKING_SETTINGS_RANGE_V2).getDisplayValues();
  const map = {};
  values.forEach(function(row) {
    if (row[0]) map[String(row[0]).trim()] = row[1];
  });

  const numberValue = function(key, fallback) {
    const value = Number(map[key]);
    return Number.isFinite(value) ? value : fallback;
  };

  const legacyBuffer = numberValue("Buffer Minutes", 30);
  const sheetCalendarId = String(map["Calendar ID"] || "").trim();
  if (sheetCalendarId && sheetCalendarId !== configuredCalendarId) {
    console.warn("Targets & Settings Calendar ID differs from CHRISTINE_CALENDAR_ID; Script Properties wins.");
  }

  return {
    calendarId: configuredCalendarId,
    owner: map["Owner"] || "Ma'am Christine",
    timezone: map["Time Zone"] || DEFAULT_TIMEZONE,
    days: (map["Days Available"] || "Mon,Tue,Wed,Thu,Fri,Sat,Sun")
      .split(",")
      .map(function(day) { return day.trim(); })
      .filter(Boolean),
    startHour: numberValue("Start Hour", 9),
    endHour: numberValue("End Hour", 17),
    durationMinutes: numberValue("Appointment Minutes", 30),
    slotIntervalMinutes: numberValue("Slot Interval Minutes", numberValue("Appointment Minutes", 30) + legacyBuffer),
    bufferBeforeMinutes: numberValue("Buffer Before Minutes", legacyBuffer),
    bufferAfterMinutes: numberValue("Buffer After Minutes", legacyBuffer),
    minimumNoticeHours: numberValue("Minimum Notice Hours", 24),
    horizonDays: numberValue("Booking Horizon Days", 30),
    emailReminderMinutes: numberValue("Email Reminder Minutes", 1440),
    popupReminderMinutes: numberValue("Popup Reminder Minutes", 60)
  };
}

function getCalendar_(calendarId) {
  const calendar = CalendarApp.getCalendarById(calendarId);
  if (!calendar) throw new Error("Ma'am Christine's calendar is unavailable to this Apps Script account.");
  return calendar;
}

function assertCalendarWritesEnabled_() {
  const enabled = String(
    PropertiesService.getScriptProperties().getProperty("ENABLE_CALENDAR_WRITES") || ""
  ).trim().toUpperCase();
  if (enabled !== "TRUE") {
    throw new Error("Calendar writes are disabled. Set ENABLE_CALENDAR_WRITES=TRUE only after TEST calendar verification.");
  }
}

function getAvailability_() {
  const config = getBookingConfig_();
  const calendar = getCalendar_(config.calendarId);
  const now = new Date();
  const earliest = new Date(now.getTime() + config.minimumNoticeHours * 60 * 60 * 1000);
  const latest = new Date(now.getTime() + config.horizonDays * 24 * 60 * 60 * 1000);
  const earliestParts = getDatePartsInTimezone_(earliest, config.timezone);
  const firstDay = makeDateInTimezone_(earliestParts.year, earliestParts.month - 1, earliestParts.day, 0, 0, config.timezone);
  const latestParts = getDatePartsInTimezone_(latest, config.timezone);
  const eventWindowEnd = makeDateInTimezone_(latestParts.year, latestParts.month - 1, latestParts.day, 23, 59, config.timezone);

  const busy = calendar.getEvents(firstDay, eventWindowEnd).map(function(event) {
    return { start: event.getStartTime().getTime(), end: event.getEndTime().getTime() };
  });
  const blackouts = getBookingBlackouts_(config, firstDay, eventWindowEnd);
  const days = [];
  const allowedDays = new Set(config.days);
  const stepMinutes = Math.max(1, config.slotIntervalMinutes);

  for (let dayOffset = 0; dayOffset <= config.horizonDays; dayOffset += 1) {
    const localParts = addDaysToDateParts_(earliestParts, dayOffset);
    const day = makeDateInTimezone_(localParts.year, localParts.month - 1, localParts.day, 0, 0, config.timezone);
    const dayName = Utilities.formatDate(day, config.timezone, "EEE");
    if (!allowedDays.has(dayName)) continue;

    const slots = [];
    for (let minutes = config.startHour * 60;
         minutes + config.durationMinutes <= config.endHour * 60;
         minutes += stepMinutes) {
      const start = makeDateInTimezone_(
        localParts.year,
        localParts.month - 1,
        localParts.day,
        Math.floor(minutes / 60),
        minutes % 60,
        config.timezone
      );
      const end = new Date(start.getTime() + config.durationMinutes * 60 * 1000);
      if (start.getTime() < earliest.getTime() || start.getTime() > latest.getTime()) continue;

      const bufferStart = start.getTime() - config.bufferBeforeMinutes * 60 * 1000;
      const bufferEnd = end.getTime() + config.bufferAfterMinutes * 60 * 1000;
      const blockedByCalendar = busy.some(function(item) {
        return bufferStart < item.end && bufferEnd > item.start;
      });
      if (blockedByCalendar || isBlockedByBlackout_(start, end, blackouts)) continue;

      slots.push({
        start: start.toISOString(),
        end: end.toISOString(),
        label: Utilities.formatDate(start, config.timezone, "h:mm a")
      });
    }

    if (slots.length) {
      days.push({
        date: Utilities.formatDate(day, config.timezone, "yyyy-MM-dd"),
        label: Utilities.formatDate(day, config.timezone, "EEE, MMM d"),
        slots: slots
      });
    }
  }

  return {
    ok: true,
    code: "AVAILABILITY_OK",
    http_status: 200,
    retryable: false,
    owner: config.owner,
    timezone: config.timezone,
    duration_minutes: config.durationMinutes,
    slot_interval_minutes: config.slotIntervalMinutes,
    buffer_before_minutes: config.bufferBeforeMinutes,
    buffer_after_minutes: config.bufferAfterMinutes,
    days: days
  };
}

function bookConsultation_(payload, requestId) {
  const leadId = String(payload.lead_id || "").trim();
  const requestedStart = new Date(payload.start);
  if (!isUuidV4_(leadId) || isNaN(requestedStart.getTime())) {
    return {
      ok: false,
      code: "INVALID_PAYLOAD",
      message: "Invalid booking request.",
      http_status: 400,
      retryable: false
    };
  }

  const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(spreadsheet);
  const leadSheet = spreadsheet.getSheetByName(LEADS_SHEET_NAME);
  const calendarLog = spreadsheet.getSheetByName(CALENDAR_LOG_SHEET_NAME);
  if (!leadSheet || !calendarLog) throw new Error("Required Operations Hub sheets were not found.");

  const fingerprint = bookingFingerprint_(leadId, requestedStart);
  const explicitIdempotencyKey = String(payload.idempotency_key || "").trim().slice(0, 200);
  const idempotencyKey = explicitIdempotencyKey || ("legacy:" + fingerprint);

  const idempotentBooking = findBookingByIdempotencyKey_(
    calendarLog,
    idempotencyKey,
    !explicitIdempotencyKey
  );
  if (idempotentBooking) {
    idempotentBooking.idempotent_replay = true;
    return idempotentBooking;
  }

  const existingBooking = findExistingBooking_(calendarLog, leadId);
  if (existingBooking) return existingBooking;

  const lastLeadRow = leadSheet.getLastRow();
  if (lastLeadRow < 2) {
    return { ok: false, code: "LEAD_NOT_FOUND", message: "Lead was not found.", http_status: 404, retryable: false };
  }

  const leadCell = leadSheet
    .getRange(2, 1, lastLeadRow - 1, 1)
    .createTextFinder(leadId)
    .matchEntireCell(true)
    .findNext();
  if (!leadCell) {
    return { ok: false, code: "LEAD_NOT_FOUND", message: "Lead was not found.", http_status: 404, retryable: false };
  }

  const leadRow = leadCell.getRow();
  const leadValues = leadSheet.getRange(leadRow, 1, 1, 24).getDisplayValues()[0];
  const config = getBookingConfig_();
  const validation = validateRequestedSlot_(requestedStart, config);
  if (!validation.ok) return validation;

  const end = new Date(requestedStart.getTime() + config.durationMinutes * 60 * 1000);
  const conflictStart = new Date(requestedStart.getTime() - config.bufferBeforeMinutes * 60 * 1000);
  const conflictEnd = new Date(end.getTime() + config.bufferAfterMinutes * 60 * 1000);
  if (calendarConflictExists_(config.calendarId, conflictStart, conflictEnd, "")) {
    return {
      ok: false,
      code: "SLOT_UNAVAILABLE",
      message: "The selected consultation schedule is no longer available.",
      http_status: 409,
      retryable: false
    };
  }

  const blackouts = getBookingBlackouts_(config, conflictStart, conflictEnd);
  if (isBlockedByBlackout_(requestedStart, end, blackouts)) {
    return {
      ok: false,
      code: "SLOT_UNAVAILABLE",
      message: "The selected consultation schedule is no longer available.",
      http_status: 409,
      retryable: false
    };
  }

  const bookingId = Utilities.getUuid();
  const managementToken = generateManagementToken_();
  const managementTokenHash = hashManagementToken_(managementToken);
  const managementUrl = buildManagementUrl_(managementToken);
  const clientName = leadValues[9] || "Client";
  const mobile = leadValues[10] || "";
  const email = leadValues[11] || "";
  const inquiryType = leadValues[2] || "Consultation";

  let event;
  try {
    event = createCalendarEvent_(config, {
      bookingId: bookingId,
      idempotencyKey: idempotencyKey,
      fingerprint: fingerprint,
      leadId: leadId,
      managementTokenHash: managementTokenHash,
      managementUrl: managementUrl,
      clientName: clientName,
      mobile: mobile,
      email: email,
      inquiryType: inquiryType,
      start: requestedStart,
      end: end
    });
  } catch (calendarError) {
    logBookingAudit_({ requestId: requestId, bookingId: bookingId, leadId: leadId, action: "BOOK_CREATED", result: "CALENDAR_CREATE_FAILED" });
    return {
      ok: false,
      code: "CALENDAR_CREATE_FAILED",
      message: "The calendar event could not be created.",
      http_status: 502,
      retryable: true
    };
  }

  try {
    addCalendarLog_(calendarLog, config, {
      bookingId: bookingId,
      idempotencyKey: idempotencyKey,
      fingerprint: fingerprint,
      leadId: leadId,
      managementTokenHash: managementTokenHash,
      clientName: clientName,
      inquiryType: inquiryType,
      start: requestedStart,
      end: end,
      meetLink: event.meetLink,
      eventId: event.id
    });
    SpreadsheetApp.flush();
  } catch (logError) {
    const rollback = deleteCalendarEvent_(config.calendarId, event.id);
    logBookingAudit_({
      requestId: requestId,
      bookingId: bookingId,
      leadId: leadId,
      action: "CALENDAR_ROLLBACK",
      result: rollback.ok ? "SUCCESS" : "FAILED"
    });

    if (!rollback.ok) {
      recordReconciliationIssue_({
        bookingId: bookingId,
        leadId: leadId,
        code: "ORPHAN_CALENDAR_EVENT",
        details: "Calendar event exists after Calendar Log write and rollback both failed.",
        repairAction: "Manual or scheduled reconciliation",
        result: "PENDING"
      });
      sendAdminAlert_("Avodah booking rollback failed", [
        "Booking ID: " + bookingId,
        "Lead ID: " + leadId,
        "Event ID: " + event.id,
        "Calendar Log write failed and automatic rollback failed."
      ].join("\n"));
      return {
        ok: false,
        code: "CALENDAR_ROLLBACK_FAILED",
        message: "The booking could not be logged and automatic calendar rollback failed. Administrative reconciliation is required.",
        http_status: 500,
        retryable: false,
        reconciliation_required: true,
        booking_id: bookingId,
        event_id: event.id
      };
    }

    return {
      ok: false,
      code: "LOG_WRITE_FAILED",
      message: "The booking could not be saved. The temporary calendar event was removed.",
      http_status: 500,
      retryable: true
    };
  }

  let registryPending = false;
  try {
    upsertBookingRegistry_({
      bookingId: bookingId,
      leadId: leadId,
      tokenHash: managementTokenHash,
      eventId: event.id,
      status: "Scheduled",
      start: requestedStart,
      end: end,
      meetLink: event.meetLink,
      idempotencyKey: idempotencyKey,
      fingerprint: fingerprint,
      reconciliationStatus: "OK",
      lastError: ""
    });
  } catch (registryError) {
    registryPending = true;
    recordReconciliationIssue_({
      bookingId: bookingId,
      leadId: leadId,
      code: "REGISTRY_WRITE_FAILED",
      details: String(registryError && registryError.message ? registryError.message : registryError),
      repairAction: "Rebuild Booking Registry from Calendar metadata",
      result: "PENDING"
    });
  }

  let leadUpdatePending = false;
  try {
    updateLead_(leadSheet, leadRow, config.owner, requestedStart);
    SpreadsheetApp.flush();
  } catch (leadError) {
    leadUpdatePending = true;
    console.error("Appointment created but lead row update failed: " +
      (leadError && leadError.stack ? leadError.stack : leadError));
  }

  try {
    refreshChristineCalendarColorCoding_(spreadsheet);
  } catch (viewError) {
    console.error("Appointment created, but calendar view refresh failed: " +
      (viewError && viewError.stack ? viewError.stack : viewError));
  }

  logBookingAudit_({
    requestId: requestId,
    bookingId: bookingId,
    leadId: leadId,
    action: "BOOK_CREATED",
    result: leadUpdatePending || registryPending ? "RECONCILIATION_PENDING" : "SUCCESS"
  });

  return {
    ok: true,
    code: leadUpdatePending || registryPending ? "BOOKING_CREATED_RECONCILIATION_PENDING" : "BOOKING_CREATED",
    message: leadUpdatePending || registryPending
      ? "Appointment created successfully. A non-critical Operations Hub update is pending reconciliation."
      : "Appointment created successfully.",
    http_status: 200,
    retryable: false,
    booking_id: bookingId,
    idempotency_key: idempotencyKey,
    start: requestedStart.toISOString(),
    end: end.toISOString(),
    meet_link: event.meetLink,
    event_id: event.id,
    management_url: managementUrl,
    lead_update_pending: leadUpdatePending,
    registry_update_pending: registryPending
  };
}

function validateRequestedSlot_(start, config) {
  const now = new Date();
  const earliest = new Date(now.getTime() + config.minimumNoticeHours * 60 * 60 * 1000);
  const latest = new Date(now.getTime() + config.horizonDays * 24 * 60 * 60 * 1000);
  const dayName = Utilities.formatDate(start, config.timezone, "EEE");
  const hour = Number(Utilities.formatDate(start, config.timezone, "H"));
  const minute = Number(Utilities.formatDate(start, config.timezone, "m"));
  const stepMinutes = Math.max(1, config.slotIntervalMinutes);
  const minutesFromOpen = (hour - config.startHour) * 60 + minute;

  if (start < earliest || start > latest || config.days.indexOf(dayName) === -1) {
    return {
      ok: false,
      code: "INVALID_SLOT",
      message: "The selected time is outside booking availability.",
      http_status: 400,
      retryable: false
    };
  }

  if (hour < config.startHour ||
      hour * 60 + minute + config.durationMinutes > config.endHour * 60 ||
      minutesFromOpen < 0 ||
      minutesFromOpen % stepMinutes !== 0) {
    return {
      ok: false,
      code: "INVALID_SLOT",
      message: "The selected time is not a valid consultation slot.",
      http_status: 400,
      retryable: false
    };
  }

  return { ok: true };
}

function createCalendarEvent_(config, details) {
  assertCalendarWritesEnabled_();
  const attendees = [];
  if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(details.email)) attendees.push({ email: details.email });

  const privateProperties = {
    source: "avodah-operations-hub",
    leadId: String(details.leadId || ""),
    bookingId: String(details.bookingId || ""),
    bookingFingerprint: String(details.fingerprint || ""),
    idempotencyKey: String(details.idempotencyKey || ""),
    managementTokenHash: String(details.managementTokenHash || ""),
    managementVersion: "v3"
  };

  const resource = {
    summary: "Avodah Consultation — " + details.clientName,
    description: [
      "Booked through the Avodah website.",
      "Inquiry: " + details.inquiryType,
      details.mobile ? "Mobile: " + details.mobile : "",
      details.email ? "Email: " + details.email : "",
      details.managementUrl ? "Manage appointment: " + details.managementUrl : ""
    ].filter(String).join("\n"),
    location: "Google Meet",
    visibility: "private",
    guestsCanSeeOtherGuests: false,
    guestsCanInviteOthers: false,
    start: { dateTime: details.start.toISOString(), timeZone: config.timezone },
    end: { dateTime: details.end.toISOString(), timeZone: config.timezone },
    attendees: attendees,
    extendedProperties: { private: privateProperties },
    reminders: {
      useDefault: false,
      overrides: [
        { method: "email", minutes: config.emailReminderMinutes },
        { method: "popup", minutes: config.popupReminderMinutes }
      ]
    },
    conferenceData: {
      createRequest: {
        requestId: "avodah" + String(details.bookingId || Utilities.getUuid()).replace(/-/g, ""),
        conferenceSolutionKey: { type: "hangoutsMeet" }
      }
    }
  };

  const baseUrl = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(config.calendarId) + "/events";
  const response = UrlFetchApp.fetch(baseUrl + "?conferenceDataVersion=1&sendUpdates=all", {
    method: "post",
    contentType: "application/json",
    headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
    payload: JSON.stringify(resource),
    muteHttpExceptions: true
  });
  const status = response.getResponseCode();
  let result = JSON.parse(response.getContentText() || "{}");
  if (status < 200 || status >= 300 || !result.id) {
    throw new Error("Google Calendar event creation failed: " + status + " " + response.getContentText());
  }

  for (let attempt = 0; attempt < 4 && !result.hangoutLink; attempt += 1) {
    Utilities.sleep(400 + attempt * 200);
    const readResponse = UrlFetchApp.fetch(baseUrl + "/" + encodeURIComponent(result.id), {
      headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
      muteHttpExceptions: true
    });
    if (readResponse.getResponseCode() === 200) {
      result = JSON.parse(readResponse.getContentText() || "{}");
    }
  }

  const meetLink = result.hangoutLink ||
    (((result.conferenceData || {}).entryPoints || []).find(function(item) {
      return item.entryPointType === "video";
    }) || {}).uri ||
    result.htmlLink || "";

  return { id: result.id, meetLink: meetLink };
}


function deleteCalendarEvent_(calendarId, eventId) {
  if (!eventId) return { ok: true, deleted: false };
  assertCalendarWritesEnabled_();

  const url = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(calendarId) + "/events/" + encodeURIComponent(eventId) +
    "?sendUpdates=all";

  try {
    const response = UrlFetchApp.fetch(url, {
      method: "delete",
      headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
      muteHttpExceptions: true
    });
    const status = response.getResponseCode();
    if (status === 204 || status === 404 || status === 410) {
      return { ok: true, deleted: status === 204, http_status: status };
    }

    console.error("Calendar rollback failed with HTTP " + status + ": " + response.getContentText());
    return { ok: false, rollbackFailed: true, http_status: status };
  } catch (error) {
    console.error("Calendar rollback failed: " + (error && error.stack ? error.stack : error));
    return { ok: false, rollbackFailed: true, error: String(error && error.message ? error.message : error) };
  }
}

function updateLead_(sheet, row, owner, appointmentStart) {
  sheet.getRange(row, 18).setValue("Appointment Set");
  sheet.getRange(row, 19).setValue(owner);
  sheet.getRange(row, 22).setValue(appointmentStart).setNumberFormat("yyyy-mm-dd h:mm AM/PM");
}

function addCalendarLog_(sheet, config, details) {
  const row = getNextCalendarLogRow_(sheet);
  const local = getDatePartsInTimezone_(details.start, config.timezone);
  const dateOnly = makeDateInTimezone_(local.year, local.month - 1, local.day, 0, 0, config.timezone);
  const startFraction = timeFractionInTimezone_(details.start, config.timezone);
  const endFraction = timeFractionInTimezone_(details.end, config.timezone);
  const notes = [
    "Client: " + details.clientName,
    "Lead ID: " + details.leadId,
    "Booking ID: " + details.bookingId,
    "Idempotency Key: " + details.idempotencyKey,
    "Booking Fingerprint: " + details.fingerprint,
    "Management Token Hash: " + String(details.managementTokenHash || ""),
    "Inquiry: " + details.inquiryType
  ].join("\n");

  // B:K = Owner, Date, Start, End, Activity Type, Link, Status, Notes, Reminder, Category.
  // A, L and M are formula-driven; N/O store Calendar sync metadata.
  sheet.getRange(row, 2, 1, 10).setValues([[
    config.owner,
    dateOnly,
    startFraction,
    endFraction,
    "Appointment",
    details.meetLink,
    "Scheduled",
    notes,
    "1 hour",
    "Avodah"
  ]]);
  sheet.getRange(row, 14, 1, 2).setValues([[details.eventId, "Synced"]]);
  sheet.getRange(row, 3).setNumberFormat("yyyy-mm-dd");
  sheet.getRange(row, 4, 1, 2).setNumberFormat("h:mm AM/PM");
}

function getNextCalendarLogRow_(sheet) {
  const maxRows = sheet.getMaxRows();
  if (maxRows < 2) {
    sheet.insertRowsAfter(1, 100);
    return 2;
  }

  // Owner (column B) is the reliable data boundary because formula-driven
  // columns can extend far below the actual event rows.
  const bottomOwnerCell = sheet.getRange(maxRows, 2);
  const lastOwnerCell = bottomOwnerCell.getNextDataCell(SpreadsheetApp.Direction.UP);
  const lastOwnerRow = lastOwnerCell.getRow();
  const nextRow = lastOwnerRow <= 1 || !String(lastOwnerCell.getDisplayValue() || "").trim()
    ? 2
    : lastOwnerRow + 1;

  if (nextRow > maxRows) sheet.insertRowsAfter(maxRows, 100);
  return nextRow;
}

function findExistingBooking_(calendarLog, leadId) {
  const lastDataRow = getLastCalendarLogDataRow_(calendarLog);
  if (lastDataRow < 2) return null;

  const rows = calendarLog.getRange(2, 2, lastDataRow - 1, 17).getValues();
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    const row = rows[i];
    const status = String(row[6] || "").trim();
    const notes = String(row[7] || "");
    const archiveStatus = String(row[16] || "").trim();
    if (notes.indexOf("Lead ID: " + leadId) === -1) continue;
    if (!ACTIVE_BOOKING_STATUSES.has(status) || archiveStatus === "Archived") continue;
    return calendarBookingResultFromRow_(row, true);
  }
  return null;
}

function safeCell_(value) {
  const text = String(value == null ? "" : value);
  return /^[=+\-@]/.test(text) ? "'" + text : text;
}

function jsonResponse_(body) {
  return ContentService.createTextOutput(JSON.stringify(body)).setMimeType(ContentService.MimeType.JSON);
}


function isUuidV4_(value) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value || "").trim());
}

function isAuthorizedWebhookSecret_(providedSecret) {
  const provided = String(providedSecret || "");
  const properties = PropertiesService.getScriptProperties();
  const current = String(properties.getProperty("WEBHOOK_SECRET") || "");
  const next = String(properties.getProperty("WEBHOOK_SECRET_NEXT") || "");
  if (!provided || (!current && !next)) return false;
  return (current && provided === current) || (next && provided === next);
}

function acquireScriptLock_() {
  const lock = LockService.getScriptLock();
  const backoff = [100, 250, 500, 1000];
  for (let i = 0; i < backoff.length; i += 1) {
    if (lock.tryLock(500)) return lock;
    Utilities.sleep(backoff[i]);
  }
  return null;
}

function apiJsonResponse_(body, requestId) {
  const configTimezone = (function() {
    try { return getBookingConfig_().timezone; } catch (error) { return DEFAULT_TIMEZONE; }
  })();
  const result = Object.assign({}, body || {});
  if (!Object.prototype.hasOwnProperty.call(result, "http_status")) result.http_status = result.ok === false ? 400 : 200;
  if (!Object.prototype.hasOwnProperty.call(result, "retryable")) result.retryable = false;
  result.request_id = requestId || Utilities.getUuid();
  result.server_iso_now = new Date().toISOString();
  result.timezone = result.timezone || configTimezone;
  result.version = PRODUCTION_VERSION;
  return jsonResponse_(result);
}

function bookingFingerprint_(leadId, start) {
  const source = String(leadId || "") + "|" + new Date(start).toISOString();
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, source, Utilities.Charset.UTF_8);
  return digest.map(function(byte) {
    const normalized = byte < 0 ? byte + 256 : byte;
    return ("0" + normalized.toString(16)).slice(-2);
  }).join("");
}

function findBookingByIdempotencyKey_(calendarLog, idempotencyKey, activeOnly) {
  const lastDataRow = getLastCalendarLogDataRow_(calendarLog);
  if (lastDataRow < 2 || !idempotencyKey) return null;
  const rows = calendarLog.getRange(2, 2, lastDataRow - 1, 17).getValues();
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    const row = rows[i];
    const notes = String(row[7] || "");
    const status = String(row[6] || "").trim();
    const archiveStatus = String(row[16] || "").trim();
    if (notes.indexOf("Idempotency Key: " + idempotencyKey) === -1) continue;
    if (activeOnly && (!ACTIVE_BOOKING_STATUSES.has(status) || archiveStatus === "Archived")) continue;
    return calendarBookingResultFromRow_(row, ACTIVE_BOOKING_STATUSES.has(status) && archiveStatus !== "Archived");
  }
  return null;
}

function calendarBookingResultFromRow_(row, active) {
  const notes = String(row[7] || "");
  const start = row[10];
  const end = row[11];
  const bookingIdMatch = notes.match(/(?:^|\n)Booking ID:\s*([^\n]+)/i);
  const idempotencyMatch = notes.match(/(?:^|\n)Idempotency Key:\s*([^\n]+)/i);
  return {
    ok: true,
    code: active ? "ALREADY_BOOKED" : "IDEMPOTENT_REPLAY",
    message: active ? "This lead already has an active appointment." : "Previous booking result returned.",
    http_status: 200,
    retryable: false,
    already_booked: Boolean(active),
    booking_id: bookingIdMatch ? bookingIdMatch[1].trim() : "",
    idempotency_key: idempotencyMatch ? idempotencyMatch[1].trim() : "",
    start: start instanceof Date ? start.toISOString() : "",
    end: end instanceof Date ? end.toISOString() : "",
    meet_link: row[5] || "",
    event_id: row[12] || ""
  };
}

function getLastCalendarLogDataRow_(sheet) {
  const maxRows = sheet.getMaxRows();
  if (maxRows < 2) return 1;
  const lastOwnerCell = sheet.getRange(maxRows, 2).getNextDataCell(SpreadsheetApp.Direction.UP);
  if (lastOwnerCell.getRow() <= 1 || !String(lastOwnerCell.getDisplayValue() || "").trim()) return 1;
  return lastOwnerCell.getRow();
}

function getDatePartsInTimezone_(date, timezone) {
  return {
    year: Number(Utilities.formatDate(date, timezone, "yyyy")),
    month: Number(Utilities.formatDate(date, timezone, "M")),
    day: Number(Utilities.formatDate(date, timezone, "d")),
    hour: Number(Utilities.formatDate(date, timezone, "H")),
    minute: Number(Utilities.formatDate(date, timezone, "m"))
  };
}

function addDaysToDateParts_(parts, days) {
  const utc = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + days));
  return {
    year: utc.getUTCFullYear(),
    month: utc.getUTCMonth() + 1,
    day: utc.getUTCDate()
  };
}

function timezoneOffsetMinutes_(date, timezone) {
  const offset = Utilities.formatDate(date, timezone, "Z");
  const sign = offset.charAt(0) === "-" ? -1 : 1;
  const hours = Number(offset.slice(1, 3));
  const minutes = Number(offset.slice(3, 5));
  return sign * (hours * 60 + minutes);
}

function makeDateInTimezone_(year, monthIndex, day, hour, minute, timezone) {
  const utcGuess = new Date(Date.UTC(year, monthIndex, day, hour || 0, minute || 0, 0, 0));
  let offset = timezoneOffsetMinutes_(utcGuess, timezone);
  let result = new Date(utcGuess.getTime() - offset * 60000);

  // Re-evaluate once for time zones with DST boundaries.
  const correctedOffset = timezoneOffsetMinutes_(result, timezone);
  if (correctedOffset !== offset) {
    result = new Date(utcGuess.getTime() - correctedOffset * 60000);
  }
  return result;
}

function timeFractionInTimezone_(date, timezone) {
  const hour = Number(Utilities.formatDate(date, timezone, "H"));
  const minute = Number(Utilities.formatDate(date, timezone, "m"));
  return (hour * 60 + minute) / 1440;
}

function getBookingBlackouts_(config, windowStart, windowEnd) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sheet = ss.getSheetByName(BOOKING_BLACKOUTS_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) return [];

  const rows = sheet.getRange(2, 1, sheet.getLastRow() - 1, 6).getValues();
  const blackouts = [];
  rows.forEach(function(row) {
    const date = row[0];
    const startTime = row[1];
    const endTime = row[2];
    const type = String(row[3] || "").trim();
    const active = row[5] === true || /^(true|yes|1)$/i.test(String(row[5] || "").trim());
    if (!active || !(date instanceof Date)) return;

    const dateParts = getDatePartsInTimezone_(date, config.timezone);
    let start;
    let end;
    if (/full/i.test(type) || !(startTime instanceof Date) || !(endTime instanceof Date)) {
      start = makeDateInTimezone_(dateParts.year, dateParts.month - 1, dateParts.day, 0, 0, config.timezone);
      const nextParts = addDaysToDateParts_(dateParts, 1);
      end = makeDateInTimezone_(nextParts.year, nextParts.month - 1, nextParts.day, 0, 0, config.timezone);
    } else {
      const startParts = getDatePartsInTimezone_(startTime, config.timezone);
      const endParts = getDatePartsInTimezone_(endTime, config.timezone);
      start = makeDateInTimezone_(dateParts.year, dateParts.month - 1, dateParts.day, startParts.hour, startParts.minute, config.timezone);
      end = makeDateInTimezone_(dateParts.year, dateParts.month - 1, dateParts.day, endParts.hour, endParts.minute, config.timezone);
    }

    if (start < windowEnd && end > windowStart) blackouts.push({ start: start.getTime(), end: end.getTime() });
  });
  return blackouts;
}

function isBlockedByBlackout_(start, end, blackouts) {
  const startMs = start.getTime();
  const endMs = end.getTime();
  return (blackouts || []).some(function(item) {
    return startMs < item.end && endMs > item.start;
  });
}


/* ========================================================================== 
   PRODUCTION V3 — SELF-SERVICE MANAGEMENT, RECONCILIATION, AND ALERTS
   ========================================================================== */

function generateManagementToken_() {
  return [Utilities.getUuid(), Utilities.getUuid(), Utilities.getUuid()]
    .join("")
    .replace(/-/g, "");
}

function hashManagementToken_(token) {
  const digest = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(token || ""),
    Utilities.Charset.UTF_8
  );
  return Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, "");
}

function getManagementBaseUrl_() {
  return String(
    PropertiesService.getScriptProperties().getProperty("BOOKING_MANAGEMENT_BASE_URL") ||
    BOOKING_MANAGEMENT_DEFAULT_URL
  ).trim();
}

function buildManagementUrl_(token) {
  const base = getManagementBaseUrl_();
  if (!base) return "";
  return base + (base.indexOf("?") === -1 ? "?" : "&") + "token=" + encodeURIComponent(token);
}

function getAdminAlertEmail_() {
  return String(
    PropertiesService.getScriptProperties().getProperty("BOOKING_ADMIN_ALERT_EMAIL") ||
    PropertiesService.getScriptProperties().getProperty("ADMIN_NOTIFICATION_EMAIL") ||
    BOOKING_ADMIN_DEFAULT_EMAIL
  ).trim();
}

function calendarConflictExists_(calendarId, start, end, excludeEventId) {
  const baseUrl = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(calendarId) + "/events";
  const query = [
    "singleEvents=true",
    "showDeleted=false",
    "maxResults=100",
    "timeMin=" + encodeURIComponent(start.toISOString()),
    "timeMax=" + encodeURIComponent(end.toISOString()),
    "fields=" + encodeURIComponent("items(id,status,start,end)")
  ].join("&");
  const response = UrlFetchApp.fetch(baseUrl + "?" + query, {
    headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  if (response.getResponseCode() !== 200) {
    throw new Error("Calendar conflict query failed: " + response.getResponseCode() + " " + response.getContentText());
  }
  const result = JSON.parse(response.getContentText() || "{}");
  return (result.items || []).some(function(item) {
    return item.status !== "cancelled" && String(item.id || "") !== String(excludeEventId || "");
  });
}

function getCalendarEventResource_(calendarId, eventId) {
  if (!eventId) return null;
  const url = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(calendarId) + "/events/" + encodeURIComponent(eventId);
  const response = UrlFetchApp.fetch(url, {
    headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  const status = response.getResponseCode();
  if (status === 404 || status === 410) return null;
  if (status < 200 || status >= 300) {
    throw new Error("Calendar event read failed: " + status + " " + response.getContentText());
  }
  return JSON.parse(response.getContentText() || "{}");
}

function updateCalendarEventTime_(config, eventId, start, end) {
  assertCalendarWritesEnabled_();
  const url = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(config.calendarId) + "/events/" + encodeURIComponent(eventId) +
    "?sendUpdates=all";
  const response = UrlFetchApp.fetch(url, {
    method: "patch",
    contentType: "application/json",
    headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
    payload: JSON.stringify({
      start: { dateTime: start.toISOString(), timeZone: config.timezone },
      end: { dateTime: end.toISOString(), timeZone: config.timezone }
    }),
    muteHttpExceptions: true
  });
  const status = response.getResponseCode();
  if (status < 200 || status >= 300) {
    throw new Error("Calendar event reschedule failed: " + status + " " + response.getContentText());
  }
  return JSON.parse(response.getContentText() || "{}");
}

function getEventMeetLink_(event) {
  if (!event) return "";
  return event.hangoutLink ||
    (((event.conferenceData || {}).entryPoints || []).find(function(item) {
      return item.entryPointType === "video";
    }) || {}).uri ||
    event.htmlLink || "";
}

function eventDate_(value) {
  const dateTime = value && (value.dateTime || value.date);
  if (!dateTime) return null;
  const parsed = new Date(dateTime);
  return isNaN(parsed.getTime()) ? null : parsed;
}

function findLeadRowById_(sheet, leadId) {
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return 0;
  const cell = sheet.getRange(2, 1, lastRow - 1, 1)
    .createTextFinder(String(leadId || ""))
    .matchEntireCell(true)
    .findNext();
  return cell ? cell.getRow() : 0;
}

function findCalendarLogRowByBookingId_(sheet, bookingId) {
  const lastRow = getLastCalendarLogDataRow_(sheet);
  if (lastRow < 2) return 0;
  const finder = sheet.getRange(2, 9, lastRow - 1, 1)
    .createTextFinder("Booking ID: " + String(bookingId || ""))
    .matchCase(false)
    .findNext();
  return finder ? finder.getRow() : 0;
}

function updateCalendarLogForReschedule_(sheet, row, config, start, end, eventId, meetLink) {
  const parts = getDatePartsInTimezone_(start, config.timezone);
  const dateOnly = makeDateInTimezone_(parts.year, parts.month - 1, parts.day, 0, 0, config.timezone);
  sheet.getRange(row, 3).setValue(dateOnly).setNumberFormat("yyyy-mm-dd");
  sheet.getRange(row, 4).setValue(timeFractionInTimezone_(start, config.timezone)).setNumberFormat("h:mm AM/PM");
  sheet.getRange(row, 5).setValue(timeFractionInTimezone_(end, config.timezone)).setNumberFormat("h:mm AM/PM");
  if (meetLink) sheet.getRange(row, 7).setValue(meetLink);
  sheet.getRange(row, 8).setValue("Rescheduled");
  if (eventId) sheet.getRange(row, 14).setValue(eventId);
  sheet.getRange(row, 15).setValue("Synced");
  sheet.getRange(row, 16).setValue(new Date());
  sheet.getRange(row, 17).clearContent();
}

function updateCalendarLogForCancellation_(sheet, row) {
  sheet.getRange(row, 8).setValue("Cancelled");
  sheet.getRange(row, 15).setValue("Synced");
  sheet.getRange(row, 16).setValue(new Date());
  sheet.getRange(row, 17).clearContent();
}

function updateLeadAfterCancellation_(sheet, row) {
  sheet.getRange(row, 18).setValue("New");
  sheet.getRange(row, 22).clearContent();
}

function findRegistryByToken_(token) {
  const tokenText = String(token || "").trim();
  if (tokenText.length < 40) return null;
  const hash = hashManagementToken_(tokenText);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const sheet = ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) return null;
  const cell = sheet.getRange(2, 3, sheet.getLastRow() - 1, 1)
    .createTextFinder(hash)
    .matchEntireCell(true)
    .findNext();
  if (!cell) return null;
  return registryRecordFromRow_(sheet, cell.getRow());
}

function findRegistryByBookingId_(bookingId) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const sheet = ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME);
  if (!sheet || sheet.getLastRow() < 2) return null;
  const cell = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
    .createTextFinder(String(bookingId || ""))
    .matchEntireCell(true)
    .findNext();
  if (!cell) return null;
  return registryRecordFromRow_(sheet, cell.getRow());
}

function registryRecordFromRow_(sheet, row) {
  const values = sheet.getRange(row, 1, 1, 15).getValues()[0];
  return {
    sheet: sheet,
    row: row,
    bookingId: String(values[0] || ""),
    leadId: String(values[1] || ""),
    tokenHash: String(values[2] || ""),
    eventId: String(values[3] || ""),
    status: String(values[4] || ""),
    start: values[5],
    end: values[6],
    meetLink: String(values[7] || ""),
    idempotencyKey: String(values[8] || ""),
    fingerprint: String(values[9] || ""),
    createdAt: values[10],
    updatedAt: values[11],
    lastReconciled: values[12],
    reconciliationStatus: String(values[13] || ""),
    lastError: String(values[14] || "")
  };
}

function upsertBookingRegistry_(entry) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const sheet = ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME);
  let row = 0;
  if (sheet.getLastRow() >= 2) {
    const cell = sheet.getRange(2, 1, sheet.getLastRow() - 1, 1)
      .createTextFinder(String(entry.bookingId || ""))
      .matchEntireCell(true)
      .findNext();
    row = cell ? cell.getRow() : 0;
  }
  const now = new Date();
  if (!row) row = sheet.getLastRow() + 1;
  const existingCreatedAt = row <= sheet.getLastRow() ? sheet.getRange(row, 11).getValue() : "";
  sheet.getRange(row, 1, 1, 15).setValues([[
    String(entry.bookingId || ""),
    String(entry.leadId || ""),
    String(entry.tokenHash || ""),
    String(entry.eventId || ""),
    String(entry.status || "Scheduled"),
    entry.start || "",
    entry.end || "",
    String(entry.meetLink || ""),
    String(entry.idempotencyKey || ""),
    String(entry.fingerprint || ""),
    existingCreatedAt || now,
    now,
    entry.lastReconciled || "",
    String(entry.reconciliationStatus || ""),
    String(entry.lastError || "")
  ]]);
  sheet.getRange(row, 6, 1, 2).setNumberFormat("yyyy-mm-dd h:mm AM/PM");
  return row;
}

function updateRegistryAfterManagementAction_(record, fields) {
  const row = record.row;
  const sheet = record.sheet;
  if (Object.prototype.hasOwnProperty.call(fields, "eventId")) sheet.getRange(row, 4).setValue(fields.eventId || "");
  if (Object.prototype.hasOwnProperty.call(fields, "status")) sheet.getRange(row, 5).setValue(fields.status || "");
  if (Object.prototype.hasOwnProperty.call(fields, "start")) sheet.getRange(row, 6).setValue(fields.start || "");
  if (Object.prototype.hasOwnProperty.call(fields, "end")) sheet.getRange(row, 7).setValue(fields.end || "");
  if (Object.prototype.hasOwnProperty.call(fields, "meetLink")) sheet.getRange(row, 8).setValue(fields.meetLink || "");
  sheet.getRange(row, 12).setValue(new Date());
  if (Object.prototype.hasOwnProperty.call(fields, "lastReconciled")) sheet.getRange(row, 13).setValue(fields.lastReconciled || "");
  if (Object.prototype.hasOwnProperty.call(fields, "reconciliationStatus")) sheet.getRange(row, 14).setValue(fields.reconciliationStatus || "");
  if (Object.prototype.hasOwnProperty.call(fields, "lastError")) sheet.getRange(row, 15).setValue(fields.lastError || "");
}

function getManagedBookingStatus_(payload, requestId) {
  const record = findRegistryByToken_(payload.management_token);
  if (!record) {
    return {
      ok: false,
      code: "INVALID_MANAGEMENT_TOKEN",
      message: "This appointment management link is invalid or no longer available.",
      http_status: 403,
      retryable: false
    };
  }

  const config = getBookingConfig_();
  let event = null;
  try {
    event = getCalendarEventResource_(config.calendarId, record.eventId);
  } catch (error) {
    // Registry data remains the fallback so a temporary Calendar API issue does
    // not make the management page unusable.
  }

  const start = eventDate_(event && event.start) || (record.start instanceof Date ? record.start : null);
  const end = eventDate_(event && event.end) || (record.end instanceof Date ? record.end : null);
  const meetLink = getEventMeetLink_(event) || record.meetLink;
  return {
    ok: true,
    code: "BOOKING_STATUS_OK",
    http_status: 200,
    retryable: false,
    booking_id: record.bookingId,
    status: record.status,
    active: ACTIVE_BOOKING_STATUSES.has(record.status),
    start: start ? start.toISOString() : "",
    end: end ? end.toISOString() : "",
    meet_link: meetLink,
    timezone: config.timezone
  };
}

function rescheduleManagedBooking_(payload, requestId) {
  const record = findRegistryByToken_(payload.management_token);
  const newStart = new Date(payload.start);
  if (!record) {
    return { ok: false, code: "INVALID_MANAGEMENT_TOKEN", message: "Invalid appointment management link.", http_status: 403, retryable: false };
  }
  if (!ACTIVE_BOOKING_STATUSES.has(record.status)) {
    return { ok: false, code: "BOOKING_NOT_ACTIVE", message: "This appointment can no longer be rescheduled online.", http_status: 409, retryable: false };
  }
  if (isNaN(newStart.getTime())) {
    return { ok: false, code: "INVALID_SLOT", message: "Invalid reschedule time.", http_status: 400, retryable: false };
  }

  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const config = getBookingConfig_();
  const validation = validateRequestedSlot_(newStart, config);
  if (!validation.ok) return validation;
  const newEnd = new Date(newStart.getTime() + config.durationMinutes * 60 * 1000);
  const conflictStart = new Date(newStart.getTime() - config.bufferBeforeMinutes * 60 * 1000);
  const conflictEnd = new Date(newEnd.getTime() + config.bufferAfterMinutes * 60 * 1000);
  if (calendarConflictExists_(config.calendarId, conflictStart, conflictEnd, record.eventId)) {
    return { ok: false, code: "SLOT_UNAVAILABLE", message: "The selected consultation schedule is no longer available.", http_status: 409, retryable: false };
  }
  const blackouts = getBookingBlackouts_(config, conflictStart, conflictEnd);
  if (isBlockedByBlackout_(newStart, newEnd, blackouts)) {
    return { ok: false, code: "SLOT_UNAVAILABLE", message: "The selected consultation schedule is no longer available.", http_status: 409, retryable: false };
  }

  const existingEvent = getCalendarEventResource_(config.calendarId, record.eventId);
  if (!existingEvent) {
    updateRegistryAfterManagementAction_(record, {
      reconciliationStatus: "EVENT_MISSING",
      lastError: "Calendar event is missing; reschedule was not applied."
    });
    recordReconciliationIssue_({
      bookingId: record.bookingId,
      leadId: record.leadId,
      code: "EVENT_MISSING",
      details: "Client attempted to reschedule but the Calendar event could not be found.",
      repairAction: "Run booking reconciliation",
      result: "PENDING"
    });
    sendAdminAlert_("Avodah booking requires reconciliation", "Missing Calendar event for Booking ID " + record.bookingId);
    return { ok: false, code: "RECONCILIATION_REQUIRED", message: "This appointment needs administrative assistance before it can be rescheduled.", http_status: 409, retryable: false };
  }

  let updatedEvent;
  try {
    updatedEvent = updateCalendarEventTime_(config, record.eventId, newStart, newEnd);
  } catch (error) {
    return { ok: false, code: "CALENDAR_UPDATE_FAILED", message: "The appointment could not be rescheduled.", http_status: 502, retryable: true };
  }

  const meetLink = getEventMeetLink_(updatedEvent) || record.meetLink;
  let reconciliationPending = false;
  try {
    const log = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
    const logRow = findCalendarLogRowByBookingId_(log, record.bookingId);
    if (!logRow) throw new Error("Calendar Log booking row was not found.");
    updateCalendarLogForReschedule_(log, logRow, config, newStart, newEnd, record.eventId, meetLink);
  } catch (error) {
    reconciliationPending = true;
    recordReconciliationIssue_({
      bookingId: record.bookingId,
      leadId: record.leadId,
      code: "LOG_RESCHEDULE_UPDATE_FAILED",
      details: String(error && error.message ? error.message : error),
      repairAction: "Repair Calendar Log from Calendar event",
      result: "PENDING"
    });
  }

  updateRegistryAfterManagementAction_(record, {
    status: "Rescheduled",
    start: newStart,
    end: newEnd,
    meetLink: meetLink,
    reconciliationStatus: reconciliationPending ? "PENDING" : "OK",
    lastError: reconciliationPending ? "Calendar Log update pending." : ""
  });

  try {
    const leadSheet = ss.getSheetByName(LEADS_SHEET_NAME);
    const leadRow = findLeadRowById_(leadSheet, record.leadId);
    if (leadRow) updateLead_(leadSheet, leadRow, config.owner, newStart);
  } catch (error) {
    reconciliationPending = true;
  }

  try { refreshChristineCalendarColorCoding_(ss); } catch (error) {}
  logBookingAudit_({
    requestId: requestId,
    bookingId: record.bookingId,
    leadId: record.leadId,
    action: "BOOK_RESCHEDULED",
    previousValue: record.start instanceof Date ? record.start.toISOString() : "",
    newValue: newStart.toISOString(),
    result: reconciliationPending ? "RECONCILIATION_PENDING" : "SUCCESS"
  });

  return {
    ok: true,
    code: reconciliationPending ? "RESCHEDULED_RECONCILIATION_PENDING" : "BOOKING_RESCHEDULED",
    message: "Appointment rescheduled successfully.",
    http_status: 200,
    retryable: false,
    booking_id: record.bookingId,
    start: newStart.toISOString(),
    end: newEnd.toISOString(),
    meet_link: meetLink,
    reconciliation_required: reconciliationPending
  };
}

function cancelManagedBooking_(payload, requestId) {
  const record = findRegistryByToken_(payload.management_token);
  if (!record) {
    return { ok: false, code: "INVALID_MANAGEMENT_TOKEN", message: "Invalid appointment management link.", http_status: 403, retryable: false };
  }
  if (!ACTIVE_BOOKING_STATUSES.has(record.status)) {
    return {
      ok: true,
      code: "BOOKING_ALREADY_INACTIVE",
      message: "This appointment is already inactive.",
      http_status: 200,
      retryable: false,
      booking_id: record.bookingId,
      status: record.status
    };
  }

  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const config = getBookingConfig_();
  const cancellation = deleteCalendarEvent_(config.calendarId, record.eventId);
  if (!cancellation.ok) {
    return { ok: false, code: "CALENDAR_CANCEL_FAILED", message: "The appointment could not be cancelled.", http_status: 502, retryable: true };
  }

  let reconciliationPending = false;
  try {
    const log = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
    const logRow = findCalendarLogRowByBookingId_(log, record.bookingId);
    if (!logRow) throw new Error("Calendar Log booking row was not found.");
    updateCalendarLogForCancellation_(log, logRow);
  } catch (error) {
    reconciliationPending = true;
    recordReconciliationIssue_({
      bookingId: record.bookingId,
      leadId: record.leadId,
      code: "LOG_CANCEL_UPDATE_FAILED",
      details: String(error && error.message ? error.message : error),
      repairAction: "Mark Calendar Log booking Cancelled",
      result: "PENDING"
    });
  }

  updateRegistryAfterManagementAction_(record, {
    status: "Cancelled",
    reconciliationStatus: reconciliationPending ? "PENDING" : "OK",
    lastError: reconciliationPending ? "Calendar Log cancellation update pending." : ""
  });

  try {
    const leadSheet = ss.getSheetByName(LEADS_SHEET_NAME);
    const leadRow = findLeadRowById_(leadSheet, record.leadId);
    if (leadRow) updateLeadAfterCancellation_(leadSheet, leadRow);
  } catch (error) {
    reconciliationPending = true;
  }

  try { refreshChristineCalendarColorCoding_(ss); } catch (error) {}
  logBookingAudit_({
    requestId: requestId,
    bookingId: record.bookingId,
    leadId: record.leadId,
    action: "BOOK_CANCELLED",
    result: reconciliationPending ? "RECONCILIATION_PENDING" : "SUCCESS"
  });

  return {
    ok: true,
    code: reconciliationPending ? "CANCELLED_RECONCILIATION_PENDING" : "BOOKING_CANCELLED",
    message: "Appointment cancelled successfully.",
    http_status: 200,
    retryable: false,
    booking_id: record.bookingId,
    status: "Cancelled",
    reconciliation_required: reconciliationPending
  };
}

function listManagedCalendarEvents_(calendarId) {
  const now = new Date();
  const timeMin = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
  const timeMax = new Date(now.getTime() + 730 * 24 * 60 * 60 * 1000);
  const baseUrl = "https://www.googleapis.com/calendar/v3/calendars/" +
    encodeURIComponent(calendarId) + "/events";
  const query = [
    "singleEvents=true",
    "showDeleted=true",
    "maxResults=2500",
    "timeMin=" + encodeURIComponent(timeMin.toISOString()),
    "timeMax=" + encodeURIComponent(timeMax.toISOString()),
    "privateExtendedProperty=" + encodeURIComponent("source=avodah-operations-hub")
  ].join("&");
  const response = UrlFetchApp.fetch(baseUrl + "?" + query, {
    headers: { Authorization: "Bearer " + ScriptApp.getOAuthToken() },
    muteHttpExceptions: true
  });
  if (response.getResponseCode() !== 200) {
    throw new Error("Managed Calendar event list failed: " + response.getResponseCode() + " " + response.getContentText());
  }
  return (JSON.parse(response.getContentText() || "{}").items || []);
}

function extractBookingMetaFromNotes_(notes) {
  const text = String(notes || "");
  const get = function(label) {
    const match = text.match(new RegExp("(?:^|\\n)" + label.replace(/[.*+?^${}()|[\\]\\]/g, "\\$&") + ":\\s*([^\\n]+)", "i"));
    return match ? match[1].trim() : "";
  };
  return {
    bookingId: get("Booking ID"),
    leadId: get("Lead ID"),
    idempotencyKey: get("Idempotency Key"),
    fingerprint: get("Booking Fingerprint"),
    tokenHash: get("Management Token Hash")
  };
}

function bootstrapRegistryFromCalendarLog_(ss) {
  const log = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
  const lastRow = getLastCalendarLogDataRow_(log);
  if (lastRow < 2) return 0;
  const rows = log.getRange(2, 2, lastRow - 1, 17).getValues();
  let created = 0;
  rows.forEach(function(row) {
    const meta = extractBookingMetaFromNotes_(row[7]);
    if (!meta.bookingId || findRegistryByBookingId_(meta.bookingId)) return;
    upsertBookingRegistry_({
      bookingId: meta.bookingId,
      leadId: meta.leadId,
      tokenHash: meta.tokenHash,
      eventId: String(row[12] || ""),
      status: String(row[6] || "Scheduled"),
      start: row[10],
      end: row[11],
      meetLink: String(row[5] || ""),
      idempotencyKey: meta.idempotencyKey,
      fingerprint: meta.fingerprint,
      reconciliationStatus: "BOOTSTRAPPED",
      lastError: meta.tokenHash ? "" : "Legacy booking has no management token; self-service management is unavailable."
    });
    created += 1;
  });
  return created;
}

function bootstrapRegistryFromCalendar_(ss, config) {
  const events = listManagedCalendarEvents_(config.calendarId);
  let created = 0;
  events.forEach(function(event) {
    const privateProps = ((event.extendedProperties || {}).private || {});
    const bookingId = String(privateProps.bookingId || "");
    if (!bookingId || findRegistryByBookingId_(bookingId)) return;
    const start = eventDate_(event.start);
    const end = eventDate_(event.end);
    upsertBookingRegistry_({
      bookingId: bookingId,
      leadId: String(privateProps.leadId || ""),
      tokenHash: String(privateProps.managementTokenHash || ""),
      eventId: String(event.id || ""),
      status: event.status === "cancelled" ? "Cancelled" : "Scheduled",
      start: start || "",
      end: end || "",
      meetLink: getEventMeetLink_(event),
      idempotencyKey: String(privateProps.idempotencyKey || ""),
      fingerprint: String(privateProps.bookingFingerprint || ""),
      reconciliationStatus: "BOOTSTRAPPED_FROM_CALENDAR",
      lastError: privateProps.managementTokenHash ? "" : "Legacy booking has no management token; self-service management is unavailable."
    });
    created += 1;
  });
  return created;
}

function reconcileBookingData() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  const result = reconcileBookingRecords_({source: 'LEGACY_MANUAL'});
  console.log(JSON.stringify(result));
  return result;
}

function reconcileBookingData_(requestId) {
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const config = getBookingConfig_();
  const leadSheet = ss.getSheetByName(LEADS_SHEET_NAME);
  const calendarLog = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
  const registry = ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME);

  const bootstrappedFromLog = bootstrapRegistryFromCalendarLog_(ss);
  const bootstrappedFromCalendar = bootstrapRegistryFromCalendar_(ss, config);
  const issues = [];
  let repairedLog = 0;
  let repairedLead = 0;
  let synchronized = 0;

  const lastRow = registry.getLastRow();
  if (lastRow >= 2) {
    const bookingIds = registry.getRange(2, 1, lastRow - 1, 1).getDisplayValues().flat();
    bookingIds.forEach(function(bookingId) {
      if (!bookingId) return;
      const record = findRegistryByBookingId_(bookingId);
      if (!record) return;

      let event = null;
      try {
        event = getCalendarEventResource_(config.calendarId, record.eventId);
      } catch (error) {
        issues.push({ bookingId: bookingId, leadId: record.leadId, code: "CALENDAR_READ_FAILED", details: String(error.message || error) });
        updateRegistryAfterManagementAction_(record, { lastReconciled: new Date(), reconciliationStatus: "ERROR", lastError: String(error.message || error) });
        return;
      }

      const activeRegistry = ACTIVE_BOOKING_STATUSES.has(record.status);
      if (!event && activeRegistry) {
        issues.push({ bookingId: bookingId, leadId: record.leadId, code: "EVENT_MISSING", details: "Active registry record has no Calendar event." });
        updateRegistryAfterManagementAction_(record, { lastReconciled: new Date(), reconciliationStatus: "EVENT_MISSING", lastError: "Calendar event not found." });
        return;
      }

      if (!event) {
        updateRegistryAfterManagementAction_(record, { lastReconciled: new Date(), reconciliationStatus: "OK", lastError: "" });
        return;
      }

      const eventStart = eventDate_(event.start);
      const eventEnd = eventDate_(event.end);
      const meetLink = getEventMeetLink_(event);
      const eventStatus = event.status === "cancelled" ? "Cancelled" : record.status;
      let logRow = findCalendarLogRowByBookingId_(calendarLog, bookingId);

      if (!logRow && eventStatus !== "Cancelled" && eventStart && eventEnd) {
        const leadRow = findLeadRowById_(leadSheet, record.leadId);
        const leadValues = leadRow ? leadSheet.getRange(leadRow, 1, 1, 24).getDisplayValues()[0] : [];
        try {
          addCalendarLog_(calendarLog, config, {
            bookingId: bookingId,
            idempotencyKey: record.idempotencyKey,
            fingerprint: record.fingerprint,
            leadId: record.leadId,
            managementTokenHash: record.tokenHash,
            clientName: leadValues[9] || "Client",
            inquiryType: leadValues[2] || "Consultation",
            start: eventStart,
            end: eventEnd,
            meetLink: meetLink,
            eventId: event.id
          });
          logRow = findCalendarLogRowByBookingId_(calendarLog, bookingId);
          repairedLog += 1;
        } catch (error) {
          issues.push({ bookingId: bookingId, leadId: record.leadId, code: "LOG_REPAIR_FAILED", details: String(error.message || error) });
        }
      }

      if (logRow) {
        try {
          if (eventStatus === "Cancelled") {
            updateCalendarLogForCancellation_(calendarLog, logRow);
          } else if (eventStart && eventEnd) {
            updateCalendarLogForReschedule_(calendarLog, logRow, config, eventStart, eventEnd, event.id, meetLink);
            if (record.status === "Scheduled") calendarLog.getRange(logRow, 8).setValue("Scheduled");
          }
        } catch (error) {
          issues.push({ bookingId: bookingId, leadId: record.leadId, code: "LOG_SYNC_FAILED", details: String(error.message || error) });
        }
      }

      if (eventStatus !== "Cancelled" && eventStart) {
        try {
          const leadRow = findLeadRowById_(leadSheet, record.leadId);
          if (leadRow) {
            const currentStatus = String(leadSheet.getRange(leadRow, 18).getDisplayValue() || "");
            const currentAppointment = leadSheet.getRange(leadRow, 22).getValue();
            const needsRepair = currentStatus !== "Appointment Set" ||
              !(currentAppointment instanceof Date) ||
              Math.abs(currentAppointment.getTime() - eventStart.getTime()) > 60000;
            if (needsRepair) {
              updateLead_(leadSheet, leadRow, config.owner, eventStart);
              repairedLead += 1;
            }
          }
        } catch (error) {
          issues.push({ bookingId: bookingId, leadId: record.leadId, code: "LEAD_REPAIR_FAILED", details: String(error.message || error) });
        }
      }

      updateRegistryAfterManagementAction_(record, {
        eventId: event.id,
        status: eventStatus,
        start: eventStart || record.start,
        end: eventEnd || record.end,
        meetLink: meetLink || record.meetLink,
        lastReconciled: new Date(),
        reconciliationStatus: "OK",
        lastError: ""
      });
      synchronized += 1;
    });
  }

  issues.forEach(function(issue) {
    recordReconciliationIssue_({
      bookingId: issue.bookingId,
      leadId: issue.leadId,
      code: issue.code,
      details: issue.details,
      repairAction: "Review or rerun reconcileBookingData",
      result: "PENDING"
    });
  });

  try { refreshChristineCalendarColorCoding_(ss); } catch (error) {}

  if (issues.length) {
    sendAdminAlert_(
      "Avodah booking reconciliation found " + issues.length + " issue(s)",
      issues.slice(0, 20).map(function(issue) {
        return [issue.code, issue.bookingId, issue.leadId, issue.details].join(" | ");
      }).join("\n")
    );
  }

  logBookingAudit_({
    requestId: requestId,
    bookingId: "",
    leadId: "",
    action: "RECONCILIATION_RUN",
    result: issues.length ? "ISSUES_FOUND" : "SUCCESS",
    newValue: JSON.stringify({ synchronized: synchronized, repairedLog: repairedLog, repairedLead: repairedLead })
  });

  return {
    ok: true,
    code: issues.length ? "RECONCILIATION_COMPLETED_WITH_ISSUES" : "RECONCILIATION_COMPLETED",
    http_status: 200,
    retryable: false,
    bootstrapped_from_calendar_log: bootstrappedFromLog,
    bootstrapped_from_calendar: bootstrappedFromCalendar,
    synchronized: synchronized,
    repaired_calendar_log: repairedLog,
    repaired_leads: repairedLead,
    issues_found: issues.length
  };
}

function recordReconciliationIssue_(entry) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    ensureProductionSupportSheets_(ss);
    const sheet = ss.getSheetByName(BOOKING_RECONCILIATION_SHEET_NAME);
    sheet.appendRow([
      new Date(),
      String(entry.bookingId || ""),
      String(entry.leadId || ""),
      String(entry.code || ""),
      String(entry.details || ""),
      String(entry.repairAction || ""),
      String(entry.result || "")
    ]);
  } catch (error) {
    console.error("Reconciliation issue logging failed: " + (error && error.stack ? error.stack : error));
  }
}

function sendAdminAlert_(subject, body) {
  try {
    const email = getAdminAlertEmail_();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return false;
    const key = "V3_ALERT_" + hashManagementToken_(String(subject || "") + "|" + String(body || "")).slice(0, 24);
    const props = PropertiesService.getScriptProperties();
    const last = Number(props.getProperty(key) || 0);
    const now = Date.now();
    if (last && now - last < 6 * 60 * 60 * 1000) return false;
    MailApp.sendEmail({
      to: email,
      subject: String(subject || "Avodah Operations Hub alert"),
      body: String(body || "") + "\n\nGenerated by Avodah Operations Hub " + PRODUCTION_VERSION + "."
    });
    props.setProperty(key, String(now));
    return true;
  } catch (error) {
    console.error("Admin alert failed: " + (error && error.stack ? error.stack : error));
    return false;
  }
}

function scheduledBookingReconciliation(event) {
  return runScheduledTask_('scheduledBookingReconciliation', event, function() {
    return reconcileBookingRecords_({source: 'LEGACY_TRIGGER'});
  });
}

function installV3MaintenanceTriggers() {
  requireUserRole_(['ADMIN']);
  if (!truthy_(PropertiesService.getScriptProperties()
      .getProperty('ENABLE_AUTOMATION_TRIGGERS'))) {
    throw avodahError_('AUTOMATION_TRIGGERS_DISABLED',
      'Set ENABLE_AUTOMATION_TRIGGERS=TRUE only during reviewed activation.');
  }
  return installRequiredTriggers_();
}

function removeV3MaintenanceTriggers() {
  return removeAvodahTriggers();
}

function normalizeImportedText_(value) {
  return String(value == null ? "" : value)
    .replace(/[\u2018\u2019]/g, "'")
    .replace(/[\u201C\u201D]/g, '"')
    .replace(/[\u2013\u2014]/g, "-")
    .replace(/[\u200B-\u200D\uFEFF]/g, "")
    .replace(/\u00A0/g, " ")
    .replace(/[‘’]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[—–]/g, "-")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function buildScheduleImportDuplicateIndex_(calendarLog) {
  const importKeys = new Set();
  const signatures = new Set();
  const lastDataRow = getLastCalendarLogDataRow_(calendarLog);
  if (lastDataRow < 2) return { importKeys: importKeys, signatures: signatures };

  const rows = calendarLog.getRange(2, 2, lastDataRow - 1, 8).getValues();
  rows.forEach(function(row) {
    const owner = String(row[0] || "").trim();
    const date = row[1];
    const startTime = row[2];
    const activityType = String(row[4] || "").trim();
    const notes = String(row[7] || "");
    const keyMatch = notes.match(/(?:^|\n)Import Key:\s*([^\n]+)/i);
    if (keyMatch) importKeys.add(keyMatch[1].trim());
    if (owner && date instanceof Date) {
      signatures.add(scheduleImportSignature_(owner, date, startTime, getCalendarDisplayTitle_(activityType, notes)));
    }
  });
  return { importKeys: importKeys, signatures: signatures };
}

function scheduleImportSignature_(owner, date, startTime, title) {
  const dateKey = Utilities.formatDate(date, DEFAULT_TIMEZONE, "yyyy-MM-dd");
  const timeKey = startTime instanceof Date ? Utilities.formatDate(startTime, DEFAULT_TIMEZONE, "HH:mm") : "";
  return [String(owner || "").trim(), dateKey, timeKey, normalizeKeyText_(title)].join("|");
}

function ensureProductionSupportSheets_(ss) {
  let audit = ss.getSheetByName(BOOKING_AUDIT_SHEET_NAME);
  if (!audit) {
    audit = ss.insertSheet(BOOKING_AUDIT_SHEET_NAME);
    audit.getRange(1, 1, 1, 8).setValues([[
      "Timestamp", "Request ID", "Booking ID", "Lead ID", "Action", "Previous Value", "New Value", "Result"
    ]]);
    audit.setFrozenRows(1);
  }

  let blackouts = ss.getSheetByName(BOOKING_BLACKOUTS_SHEET_NAME);
  if (!blackouts) {
    blackouts = ss.insertSheet(BOOKING_BLACKOUTS_SHEET_NAME);
    blackouts.getRange(1, 1, 1, 6).setValues([[
      "Date", "Start", "End", "Type", "Reason", "Active"
    ]]);
    blackouts.setFrozenRows(1);
    blackouts.getRange("A:A").setNumberFormat("yyyy-mm-dd");
    blackouts.getRange("B:C").setNumberFormat("h:mm AM/PM");
    blackouts.getRange("F2:F1000").insertCheckboxes();
  }

  let registry = ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME);
  if (!registry) {
    registry = ss.insertSheet(BOOKING_REGISTRY_SHEET_NAME);
    registry.getRange(1, 1, 1, 15).setValues([[
      "Booking ID", "Lead ID", "Management Token Hash", "Google Event ID", "Status",
      "Start", "End", "Meet Link", "Idempotency Key", "Fingerprint",
      "Created At", "Updated At", "Last Reconciled", "Reconciliation Status", "Last Error"
    ]]);
    registry.setFrozenRows(1);
    registry.getRange("F:G").setNumberFormat("yyyy-mm-dd h:mm AM/PM");
    registry.getRange("K:M").setNumberFormat("yyyy-mm-dd h:mm:ss AM/PM");
  }

  let reconciliation = ss.getSheetByName(BOOKING_RECONCILIATION_SHEET_NAME);
  if (!reconciliation) {
    reconciliation = ss.insertSheet(BOOKING_RECONCILIATION_SHEET_NAME);
    reconciliation.getRange(1, 1, 1, 7).setValues([[
      "Timestamp", "Booking ID", "Lead ID", "Issue Code", "Details", "Repair Action", "Result"
    ]]);
    reconciliation.setFrozenRows(1);
    reconciliation.getRange("A:A").setNumberFormat("yyyy-mm-dd h:mm:ss AM/PM");
  }
}

function logBookingAudit_(entry) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName(BOOKING_AUDIT_SHEET_NAME);
    if (!sheet) {
      ensureProductionSupportSheets_(ss);
      sheet = ss.getSheetByName(BOOKING_AUDIT_SHEET_NAME);
    }
    sheet.appendRow([
      new Date(),
      String(entry.requestId || ""),
      String(entry.bookingId || ""),
      String(entry.leadId || ""),
      String(entry.action || ""),
      String(entry.previousValue || ""),
      String(entry.newValue || ""),
      String(entry.result || "")
    ]);
  } catch (error) {
    console.error("Booking audit logging failed: " + (error && error.stack ? error.stack : error));
  }
}

function testAvailability() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  console.log(JSON.stringify(typeof getBookingAvailability_ === "function"
    ? getBookingAvailability_() : getAvailability_()));
}

function testSheetsAccess() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
  console.log("Sheets access OK: " + spreadsheet.getName());
}

function testCalendarAccess() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  const config = getBookingConfig_();
  const calendar = CalendarApp.getCalendarById(config.calendarId);

  if (!calendar) {
    throw new Error("Calendar was not found or is not accessible.");
  }

  console.log("Calendar access OK: " + calendar.getName());
}

/* ========================================================================== 
   PRODUCTION MAINTENANCE, MONTHLY SCHEDULE IMPORT, AND CALENDAR COLOR RENDERER
   ========================================================================== */

/**
 * Builds a reviewable import preview from the pasted monthly schedule matrix.
 * This function never writes to Calendar Log.
 */
function previewMonthlyScheduleImport() {
  return previewScheduleImport_();
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const sourceSheet = ss.getSheetByName(SCHEDULE_IMPORT_SHEET_NAME);
  const previewSheet = ss.getSheetByName(SCHEDULE_PREVIEW_SHEET_NAME);
  if (!sourceSheet || !previewSheet) throw new Error("Schedule Import sheets were not found.");

  const values = sourceSheet.getDataRange().getDisplayValues();
  const monthYear = detectImportMonthYear_(values);
  if (!monthYear.month || !monthYear.year) {
    throw new Error("Could not detect CALENDAR MONTH and YEAR from Schedule Import.");
  }

  const events = parseMonthlyMatrix_(values, monthYear.month, monthYear.year);

  if (previewSheet.getMaxRows() > 1) {
    previewSheet.getRange(2, 1, previewSheet.getMaxRows() - 1, 16).clearContent();
  }

  if (!events.length) {
    console.log("No schedule entries were detected.");
    return;
  }

  const output = events.map(function(event) {
    const include = event.startTime instanceof Date;
    return [
      include,
      event.importKey,
      event.date,
      event.period,
      event.startTime || "",
      event.endTime || "",
      event.activityType,
      event.title,
      event.link || "",
      "Scheduled",
      event.reminder,
      event.category,
      "Ma'am Christine",
      event.sourceCell,
      event.rawText,
      include ? "Ready" : "Needs Review - No Time"
    ];
  });

  previewSheet.getRange(2, 1, output.length, 16).setValues(output);
  previewSheet.getRange(2, 1, output.length, 1).insertCheckboxes();
  previewSheet.getRange(2, 3, output.length, 1).setNumberFormat("yyyy-mm-dd");
  previewSheet.getRange(2, 5, output.length, 2).setNumberFormat("h:mm AM/PM");
  SpreadsheetApp.flush();
  console.log(output.length + " schedule entries were extracted into Schedule Import Preview.");
}

/**
 * Writes only checked preview rows to Calendar Log.
 * Duplicate rows are skipped. Untimed/unchecked rows remain in Preview.
 */
function commitScheduleImportPreview() {
  return commitScheduleImport_();
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const previewSheet = ss.getSheetByName(SCHEDULE_PREVIEW_SHEET_NAME);
  const calendarLog = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
  if (!previewSheet || !calendarLog) throw new Error("Required sheets were not found.");

  const lastRow = previewSheet.getLastRow();
  if (lastRow < 2) {
    console.log("There are no preview rows to import.");
    return;
  }

  const rows = previewSheet.getRange(2, 1, lastRow - 1, 16).getValues();
  const duplicateIndex = buildScheduleImportDuplicateIndex_(calendarLog);
  const outputRows = [];
  const statuses = [];
  const outputKeys = [];
  let imported = 0;
  let duplicates = 0;
  let skipped = 0;

  rows.forEach(function(row) {
    const include = row[0] === true;
    const importKey = String(row[1] || "").trim();
    const date = row[2];
    const startTime = row[4];
    const endTime = row[5];
    const activityType = String(row[6] || "Other").trim();
    const title = String(row[7] || "").trim();
    const link = String(row[8] || "").trim();
    const status = String(row[9] || "Scheduled").trim();
    const reminder = String(row[10] || "30 minutes").trim();
    const category = String(row[11] || "Avodah").trim();
    const owner = String(row[12] || "Ma'am Christine").trim();
    const rawText = String(row[14] || "").trim();

    if (!include || !title || !(date instanceof Date)) {
      statuses.push(["Skipped"]);
      skipped += 1;
      return;
    }

    const signature = scheduleImportSignature_(owner, date, startTime, title);
    if (duplicateIndex.importKeys.has(importKey) || duplicateIndex.signatures.has(signature)) {
      statuses.push(["Duplicate"]);
      duplicates += 1;
      return;
    }

    const startFraction = startTime instanceof Date ? timeFractionFromDate_(startTime) : "";
    const endFraction = endTime instanceof Date ? timeFractionFromDate_(endTime) : "";
    const parts = getDatePartsInTimezone_(date, DEFAULT_TIMEZONE);
    const dateOnly = makeDateInTimezone_(parts.year, parts.month - 1, parts.day, 0, 0, DEFAULT_TIMEZONE);
    const notes = [
      "Imported monthly schedule",
      "Title: " + title,
      "Import Key: " + importKey,
      rawText
    ].filter(Boolean).join("\n");

    outputRows.push([
      owner,
      dateOnly,
      startFraction,
      endFraction,
      activityType,
      link,
      status,
      notes,
      reminder,
      category
    ]);
    outputKeys.push({ importKey: importKey, signature: signature });
    duplicateIndex.importKeys.add(importKey);
    duplicateIndex.signatures.add(signature);
    statuses.push(["Imported"]);
    imported += 1;
  });

  if (outputRows.length) {
    const startRow = getNextCalendarLogRow_(calendarLog);
    const requiredLastRow = startRow + outputRows.length - 1;
    if (requiredLastRow > calendarLog.getMaxRows()) {
      calendarLog.insertRowsAfter(calendarLog.getMaxRows(), requiredLastRow - calendarLog.getMaxRows() + 50);
    }

    calendarLog.getRange(startRow, 2, outputRows.length, 10).setValues(outputRows);
    calendarLog.getRange(startRow, 3, outputRows.length, 1).setNumberFormat("yyyy-mm-dd");
    calendarLog.getRange(startRow, 4, outputRows.length, 2).setNumberFormat("h:mm AM/PM");

    outputKeys.forEach(function(item) {
      duplicateIndex.importKeys.add(item.importKey);
      duplicateIndex.signatures.add(item.signature);
    });
  }

  previewSheet.getRange(2, 16, statuses.length, 1).setValues(statuses);
  SpreadsheetApp.flush();

  try {
    refreshChristineCalendarColorCoding_(ss);
  } catch (error) {
    console.error("Schedule import completed, but monthly calendar refresh failed: " +
      (error && error.stack ? error.stack : error));
  }

  console.log("Schedule import complete. Imported: " + imported +
    ", Duplicates: " + duplicates + ", Skipped: " + skipped);
}

function detectImportMonthYear_(values) {
  let month = "";
  let year = "";
  for (let r = 0; r < values.length; r += 1) {
    for (let c = 0; c < values[r].length; c += 1) {
      const value = String(values[r][c] || "").trim();
      const upper = value.toUpperCase();
      if (upper === "CALENDAR MONTH" && values[r][c + 1]) month = String(values[r][c + 1]).trim();
      if (upper === "YEAR" && values[r][c + 1]) year = Number(values[r][c + 1]);
    }
  }
  return { month: month, year: year };
}

function parseMonthlyMatrix_(values, monthName, year) {
  const monthIndex = monthNameToIndex_(monthName);
  if (monthIndex < 0) throw new Error("Unsupported month: " + monthName);
  const events = [];

  for (let r = 0; r < values.length; r += 1) {
    const label = normalizeImportedText_(values[r][0]).toUpperCase();
    if (label !== "DAY") continue;

    const dayRow = values[r] || [];
    const amRow = values[r + 1] || [];
    const pmRow = values[r + 2] || [];
    const objectiveRow = values[r + 3] || [];
    const validDayColumns = [];

    for (let c = 1; c < dayRow.length; c += 1) {
      const day = Number(normalizeImportedText_(dayRow[c]));
      if (Number.isInteger(day) && day >= 1 && day <= 31) {
        validDayColumns.push({ column: c, day: day });
      }
    }
    if (!validDayColumns.length) continue;

    const objectiveEntries = [];
    for (let c = 1; c < objectiveRow.length; c += 1) {
      const objectiveText = normalizeImportedText_(objectiveRow[c]);
      if (objectiveText) objectiveEntries.push({ text: objectiveText, column: c });
    }
    const sharedObjective = objectiveEntries.length === 1 ? objectiveEntries[0] : null;

    validDayColumns.forEach(function(dayInfo) {
      const c = dayInfo.column;
      const date = makeDateInTimezone_(year, monthIndex, dayInfo.day, 0, 0, DEFAULT_TIMEZONE);

      const amText = normalizeImportedText_(amRow[c]);
      if (amText) events.push.apply(events, parseScheduleCell_(amText, date, "AM", toA1_(r + 2, c + 1)));

      const pmText = normalizeImportedText_(pmRow[c]);
      if (pmText) events.push.apply(events, parseScheduleCell_(pmText, date, "PM", toA1_(r + 3, c + 1)));

      let objectiveText = normalizeImportedText_(objectiveRow[c]);
      let objectiveSourceColumn = c;
      if (!objectiveText && sharedObjective) {
        objectiveText = sharedObjective.text;
        objectiveSourceColumn = sharedObjective.column;
      }
      if (objectiveText) {
        events.push.apply(events, parseScheduleCell_(
          objectiveText,
          date,
          "OBJECTIVE",
          toA1_(r + 4, objectiveSourceColumn + 1)
        ));
      }
    });
  }
  return events;
}

function parseScheduleCell_(text, date, period, sourceCell) {
  const normalized = normalizeImportedText_(text)
    .replace(/[\u2022\u00B7\u25AA\u25E6]/g, " | ")
    .replace(/[•·▪◦]/g, " | ")
    .replace(/\s+\|\s+/g, " | ")
    .trim();
  if (!normalized) return [];

  if (/(?:GMeet|Google Meet|Meet|Meeting)\s*(?:link)?\s*:/i.test(normalized)) {
    return parseInterviewBlocks_(normalized, date, period, sourceCell);
  }

  const urls = [];
  const protectedText = normalized.replace(/https?:\/\/[^\s|]+/gi, function(url) {
    const token = "__AVODAH_URL_" + urls.length + "__";
    urls.push(url);
    return token;
  });

  const parts = protectedText
    .split(/\s*\/\s*|\s+\|\s+/)
    .map(function(part) {
      return part.replace(/__AVODAH_URL_(\d+)__/g, function(_, index) {
        return urls[Number(index)] || "";
      }).trim();
    })
    .filter(Boolean);

  const results = [];
  parts.forEach(function(part) {
    const parsed = parseSingleSchedulePart_(part, date, period, sourceCell, normalized);
    if (parsed) results.push(parsed);
  });
  adjustSequentialEndTimes_(results);
  return results;
}

function parseInterviewBlocks_(text, date, period, sourceCell) {
  const blocks = text.split(/(?=Final Interview\s*-\s*)/i).map(function(item) {
    return item.trim();
  }).filter(Boolean);
  const results = [];

  blocks.forEach(function(block) {
    const titleMatch = block.match(/(Final Interview\s*-\s*[^\n|]+)/i);
    const rangeMatch = block.match(/(\d{1,2}(?::\d{2})?)\s*(am|pm)?\s*(?:–|-|to|until)\s*(\d{1,2}(?::\d{2})?)\s*(am|pm)/i);
    const linkMatch = block.match(/https:\/\/meet\.google\.com\/[^\s|]+/i);
    if (!titleMatch) return;

    let startTime = null;
    let endTime = null;
    if (rangeMatch) {
      const endMeridiem = rangeMatch[4];
      const startMeridiem = rangeMatch[2] || endMeridiem;
      startTime = buildTimeDate_(date, rangeMatch[1], startMeridiem);
      endTime = buildTimeDate_(date, rangeMatch[3], endMeridiem);
    }

    results.push(buildScheduleEvent_(
      date,
      period,
      startTime,
      endTime,
      cleanScheduleTitle_(titleMatch[1]),
      linkMatch ? linkMatch[0] : "",
      sourceCell,
      block,
      true
    ));
  });
  return results;
}

function parseSingleSchedulePart_(text, date, period, sourceCell, rawText) {
  let cleaned = normalizeImportedText_(text);
  if (!cleaned) return null;

  const linkMatch = cleaned.match(/https?:\/\/\S+/i);
  const link = linkMatch ? linkMatch[0] : "";
  if (link) cleaned = cleaned.replace(link, "").trim();

  const explicitWholeMorning = cleaned.match(/^(\d{1,2}(?::\d{2})?)\s*(am|pm)\s*[-:]?\s*(.*?)\s*whole morning\s*$/i);
  if (explicitWholeMorning) {
    return buildScheduleEvent_(date, period,
      buildTimeDate_(date, explicitWholeMorning[1], explicitWholeMorning[2]),
      null,
      cleanScheduleTitle_(explicitWholeMorning[3]) || "Morning Schedule",
      link, sourceCell, rawText, false);
  }

  if (/whole morning/i.test(cleaned)) {
    return buildScheduleEvent_(date, period,
      null,
      null,
      cleanScheduleTitle_(cleaned.replace(/whole morning/ig, "")) || "Morning Schedule",
      link, sourceCell, rawText, false);
  }

  if (/whole afternoon/i.test(cleaned)) {
    return buildScheduleEvent_(date, period,
      null,
      null,
      cleanScheduleTitle_(cleaned.replace(/whole afternoon/ig, "")) || "Afternoon Schedule",
      link, sourceCell, rawText, false);
  }

  if (/whole day/i.test(cleaned)) {
    return buildScheduleEvent_(date, period,
      null,
      null,
      cleanScheduleTitle_(cleaned.replace(/whole day/ig, "")) || "Whole Day Schedule",
      link, sourceCell, rawText, false);
  }

  // Supports 9-10am, 9 AM - 10 AM, 9:00 AM to 10:30 AM, etc.
  const rangeMatch = cleaned.match(/^(\d{1,2}(?::\d{2})?)\s*(am|pm)?\s*(?:–|-|to|until)\s*(\d{1,2}(?::\d{2})?)\s*(am|pm)\s*[-:]?\s*(.*)$/i);
  if (rangeMatch) {
    const endMeridiem = rangeMatch[4];
    const startMeridiem = rangeMatch[2] || endMeridiem;
    return buildScheduleEvent_(
      date,
      period,
      buildTimeDate_(date, rangeMatch[1], startMeridiem),
      buildTimeDate_(date, rangeMatch[3], endMeridiem),
      cleanScheduleTitle_(rangeMatch[5] || cleaned),
      link,
      sourceCell,
      rawText,
      true
    );
  }

  const startMatch = cleaned.match(/^(\d{1,2}(?::\d{2})?)\s*(am|pm)\s*[-:]?\s*(.*)$/i);
  if (startMatch) {
    const start = buildTimeDate_(date, startMatch[1], startMatch[2]);
    const title = cleanScheduleTitle_(startMatch[3] || cleaned);
    return buildScheduleEvent_(date, period, start,
      new Date(start.getTime() + defaultDurationMinutes_(title) * 60000),
      title, link, sourceCell, rawText, false);
  }

  const trailingTimeMatch = cleaned.match(/^(.*?)\s*,?\s*(\d{1,2}(?::\d{2})?)\s*(am|pm)$/i);
  if (trailingTimeMatch) {
    const start = buildTimeDate_(date, trailingTimeMatch[2], trailingTimeMatch[3]);
    const title = cleanScheduleTitle_(trailingTimeMatch[1]);
    return buildScheduleEvent_(date, period, start,
      new Date(start.getTime() + defaultDurationMinutes_(title) * 60000),
      title, link, sourceCell, rawText, false);
  }

  const bareHourMatch = cleaned.match(/^(\d{1,2})(?::(\d{2}))?\s+(.+)$/);
  if (bareHourMatch && Number(bareHourMatch[1]) >= 1 && Number(bareHourMatch[1]) <= 12) {
    const timeText = bareHourMatch[1] + (bareHourMatch[2] ? ":" + bareHourMatch[2] : "");
    const start = buildTimeDate_(date, timeText, inferMeridiemForPeriod_(period));
    const title = cleanScheduleTitle_(bareHourMatch[3]);
    return buildScheduleEvent_(date, period, start,
      new Date(start.getTime() + defaultDurationMinutes_(title) * 60000),
      title, link, sourceCell, rawText, false);
  }

  return buildScheduleEvent_(
    date,
    period,
    null,
    null,
    cleanScheduleTitle_(cleaned),
    link,
    sourceCell,
    rawText,
    false
  );
}

function buildScheduleEvent_(date, period, startTime, endTime, title, link, sourceCell, rawText, endWasExplicit) {
  const cleanTitle = cleanScheduleTitle_(title);
  const category = classifyScheduleCategory_(cleanTitle, rawText);
  const activityType = classifyScheduleActivityType_(cleanTitle);
  const dateKey = Utilities.formatDate(date, DEFAULT_TIMEZONE, "yyyy-MM-dd");
  const timeKey = startTime instanceof Date
    ? Utilities.formatDate(startTime, DEFAULT_TIMEZONE, "HH:mm")
    : period;

  return {
    importKey: dateKey + "|" + timeKey + "|" + normalizeKeyText_(cleanTitle),
    date: date,
    period: period,
    startTime: startTime,
    endTime: endTime,
    activityType: activityType,
    title: cleanTitle,
    link: link,
    reminder: activityType === "Appointment" ? "1 hour" : "30 minutes",
    category: category,
    sourceCell: sourceCell,
    rawText: rawText,
    _endWasExplicit: endWasExplicit === true
  };
}

function adjustSequentialEndTimes_(events) {
  for (let i = 0; i < events.length; i += 1) {
    const current = events[i];
    if (!(current.startTime instanceof Date) || !(current.endTime instanceof Date) || current._endWasExplicit) continue;

    let nextTimed = null;
    for (let j = i + 1; j < events.length; j += 1) {
      if (events[j].startTime instanceof Date && events[j].startTime > current.startTime) {
        nextTimed = events[j];
        break;
      }
    }
    if (nextTimed && current.endTime > nextTimed.startTime) current.endTime = new Date(nextTimed.startTime);
  }
}

function classifyScheduleCategory_(title, rawText) {
  const value = String(title || "").toUpperCase();
  const context = String(rawText || "").toUpperCase();

  if (/LAUNDRY|FAMILY|FAM TIME|CHOIR|CHURCH|DAUGHTERS OF MARY|\bDOM\b|BIRTHDAY|CHAO PI MAI|COFFEE SHOP/.test(value)) return "Personal";
  if (/AVODAH|JOB INTERVIEW|FINAL INTERVIEW|INTERVIEW|ORIENTATION|PAYROLL|PASS REPORT|PROJECT 1|ERECRUITMENT|E-RECRUITMENT|\bGAS\b|RECRUIT|OONA/.test(value)) return "Avodah";
  if (/\bCSB\b|CITY SAVINGS/.test(value)) return "CSB";
  if (/\bINS\b|MANULIFE/.test(value)) return "Manulife";

  if (/\bCSB\b|CITY SAVINGS/.test(context) &&
      /BM WEEKLY MEETING|CLIENT LISTING|APPOINTMENT CALL|FOLLOW\s*UPS?|CALLS UPDATING REVIEWS|FIELD RAPPORT/.test(value)) {
    return "CSB";
  }

  if (/CLIENT|FIELD RAPPORT|PRESENTATION|GAMETIME|FOLLOW\s*UPS?|APPOINTMENT CALL/.test(value)) {
    if (/RECRUIT/.test(value)) return "Avodah";
    return "Manulife";
  }

  if (/AVODAH|RECRUIT|ERECRUITMENT|JOB INTERVIEW/.test(context)) return "Avodah";
  if (/\bINS\b|MANULIFE|FIELD RAPPORT|CLIENT/.test(context)) return "Manulife";
  if (/\bCSB\b|CITY SAVINGS/.test(context)) return "CSB";
  return "Avodah";
}

function classifyScheduleActivityType_(title) {
  const value = String(title || "").toUpperCase();
  if (/DEADLINE/.test(value)) return "Deadline";
  if (/INTERVIEW|APPOINTMENT|CONSULTATION/.test(value)) return "Appointment";
  if (/FOLLOW[\s-]*UPS?|CALL/.test(value)) return "Follow-up";
  if (/MEETING|CHECK.?IN|ORIENTATION|PRACTICE/.test(value)) return "Meeting";
  if (/LAUNDRY|FAMILY|FAM TIME|CHOIR|CHURCH|DAUGHTERS OF MARY|\bDOM\b|BIRTHDAY|CHAO PI MAI/.test(value)) return "Personal";
  return "Other";
}

function defaultDurationMinutes_(title) {
  const value = String(title || "").toUpperCase();
  if (/INTERVIEW|APPOINTMENT|CONSULTATION|CALL/.test(value)) return 30;
  if (/MEETING|ORIENTATION|PRACTICE/.test(value)) return 60;
  return 60;
}

function scheduleImportExists_(calendarLog, importKey, owner, date, startTime, title) {
  const maxRows = calendarLog.getMaxRows();
  if (maxRows < 2) return false;

  // B:I = Owner, Date, Start, End, Activity Type, Link, Status, Notes.
  const rows = calendarLog.getRange(2, 2, maxRows - 1, 8).getDisplayValues();
  const dateKey = Utilities.formatDate(date, "Asia/Manila", "yyyy-MM-dd");
  const startKey = startTime instanceof Date
    ? Utilities.formatDate(startTime, "Asia/Manila", "h:mm a")
    : "";
  const normalizedTitle = normalizeKeyText_(title);

  return rows.some(function(row) {
    const rowOwner = String(row[0] || "").trim();
    if (!rowOwner) return false;
    const rowDate = normalizeDateDisplay_(row[1]);
    const rowStart = String(row[2] || "").trim();
    const notes = String(row[7] || "");
    return rowOwner === owner && rowDate === dateKey && (
      notes.indexOf("Import Key: " + importKey) !== -1 ||
      (rowStart === startKey && normalizeKeyText_(notes).indexOf(normalizedTitle) !== -1)
    );
  });
}

function monthNameToIndex_(month) {
  return [
    "JANUARY", "FEBRUARY", "MARCH", "APRIL", "MAY", "JUNE",
    "JULY", "AUGUST", "SEPTEMBER", "OCTOBER", "NOVEMBER", "DECEMBER"
  ].indexOf(String(month || "").trim().toUpperCase());
}

function buildTimeDate_(date, timeText, meridiem) {
  const parts = String(timeText).split(":");
  let hour = Number(parts[0]);
  const minute = Number(parts[1] || 0);
  const mer = String(meridiem || "").toLowerCase();
  if (mer === "pm" && hour !== 12) hour += 12;
  if (mer === "am" && hour === 12) hour = 0;

  const local = getDatePartsInTimezone_(date, DEFAULT_TIMEZONE);
  return makeDateInTimezone_(local.year, local.month - 1, local.day, hour, minute, DEFAULT_TIMEZONE);
}

function inferMeridiemForPeriod_(period) {
  return String(period || "").toUpperCase() === "PM" ? "pm" : "am";
}

function timeFractionFromDate_(date) {
  return timeFractionInTimezone_(date, DEFAULT_TIMEZONE);
}

function cleanScheduleTitle_(text) {
  return String(text || "")
    .replace(/^[-–|:\s]+/, "")
    .replace(/[,\s]+$/, "")
    .replace(/\s+/g, " ")
    .trim();
}

function normalizeKeyText_(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function normalizeDateDisplay_(value) {
  const parsed = value instanceof Date ? value : new Date(value);
  if (isNaN(parsed.getTime())) return "";
  return Utilities.formatDate(parsed, DEFAULT_TIMEZONE, "yyyy-MM-dd");
}

function toA1_(row, column) {
  let letters = "";
  let col = column;
  while (col > 0) {
    const remainder = (col - 1) % 26;
    letters = String.fromCharCode(65 + remainder) + letters;
    col = Math.floor((col - 1) / 26);
  }
  return letters + row;
}

/* ========================================================================== 
   RICH-TEXT MONTHLY CALENDAR COLOR CODING
   CSB = Purple | Manulife = Green | Avodah = Red | Personal = Blue
   ========================================================================== */

function refreshChristineCalendarColorCoding() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  refreshChristineCalendarColorCoding_(SpreadsheetApp.openById(SPREADSHEET_ID));
}

function refreshChristineCalendarColorCoding_(ss) {
  const calendar = ss.getSheetByName(CHRISTINE_CALENDAR_SHEET_NAME);
  const calendarLog = ss.getSheetByName(CALENDAR_LOG_SHEET_NAME);
  if (!calendar || !calendarLog) {
    throw new Error("Ma'am Christine Calendar or Calendar Log was not found.");
  }

  removeLegacyMonthlyCalendarColorRules_(calendar);

  const timezone = ss.getSpreadsheetTimeZone() || DEFAULT_TIMEZONE;
  const monthValue = calendar.getRange("B2").getValue();
  const monthDate = monthValue instanceof Date ? new Date(monthValue) : new Date(monthValue);
  if (isNaN(monthDate.getTime())) throw new Error("Invalid month value in Ma'am Christine Calendar!B2.");

  const monthParts = getDatePartsInTimezone_(monthDate, timezone);
  const selectedMonth = monthParts.month - 1;
  const selectedYear = monthParts.year;
  const firstOfMonth = makeDateInTimezone_(selectedYear, selectedMonth, 1, 0, 0, timezone);
  const weekdayMap = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };
  const mondayOffset = weekdayMap[Utilities.formatDate(firstOfMonth, timezone, "EEE")];
  const firstParts = addDaysToDateParts_({ year: selectedYear, month: selectedMonth + 1, day: 1 }, -mondayOffset);
  const gridStart = makeDateInTimezone_(firstParts.year, firstParts.month - 1, firstParts.day, 0, 0, timezone);

  const eventsByDate = {};
  const lastDataRow = getLastCalendarLogDataRow_(calendarLog);
  if (lastDataRow >= 2) {
    const rows = calendarLog.getRange(2, 2, lastDataRow - 1, 17).getValues();
    rows.forEach(function(row) {
      const owner = String(row[0] || "").trim();
      const date = row[1];
      const startTime = row[2];
      const activityType = String(row[4] || "").trim();
      const link = String(row[5] || "").trim();
      const status = String(row[6] || "").trim();
      const notes = String(row[7] || "");
      const category = String(row[9] || "").trim();
      const archiveStatus = String(row[16] || "").trim();

      if (owner !== "Ma'am Christine" || !(date instanceof Date) ||
          status === "Cancelled" || archiveStatus === "Archived") return;

      const parts = getDatePartsInTimezone_(date, timezone);
      if (parts.month - 1 !== selectedMonth || parts.year !== selectedYear) return;

      const dateKey = Utilities.formatDate(date, timezone, "yyyy-MM-dd");
      const displayTitle = getCalendarDisplayTitle_(activityType, notes);
      const timeText = startTime instanceof Date
        ? Utilities.formatDate(startTime, timezone, "h:mm a")
        : "";
      const line = [timeText, displayTitle].filter(Boolean).join(" ") +
        (link ? " • " + link : "") +
        (category ? " [" + category + "]" : "");

      if (!eventsByDate[dateKey]) eventsByDate[dateKey] = [];
      eventsByDate[dateKey].push({
        line: line,
        category: category,
        startSort: startTime instanceof Date ? startTime.getTime() : 0
      });
    });
  }

  Object.keys(eventsByDate).forEach(function(key) {
    eventsByDate[key].sort(function(a, b) { return a.startSort - b.startSort; });
  });

  const categoryColors = {
    CSB: "#6A1B9A",
    Manulife: "#1B5E20",
    Avodah: "#B71C1C",
    Personal: "#0D47A1"
  };

  [5, 7, 9, 11, 13, 15].forEach(function(rowNumber) {
    calendar.getRange(rowNumber, 1, 1, 7).setFontColor("#000000").setFontWeight("normal");
  });

  for (let week = 0; week < 6; week += 1) {
    const eventRow = 6 + week * 2;
    const richRow = [];

    for (let dayColumn = 0; dayColumn < 7; dayColumn += 1) {
      const currentParts = addDaysToDateParts_(firstParts, week * 7 + dayColumn);
      if (currentParts.month - 1 !== selectedMonth) {
        richRow.push(SpreadsheetApp.newRichTextValue().setText("").build());
        continue;
      }

      const currentDate = makeDateInTimezone_(currentParts.year, currentParts.month - 1, currentParts.day, 0, 0, timezone);
      const dateKey = Utilities.formatDate(currentDate, timezone, "yyyy-MM-dd");
      const events = eventsByDate[dateKey] || [];
      if (!events.length) {
        richRow.push(SpreadsheetApp.newRichTextValue().setText("").build());
        continue;
      }

      const fullText = events.map(function(event) { return event.line; }).join("\n");
      const builder = SpreadsheetApp.newRichTextValue().setText(fullText);
      let offset = 0;

      events.forEach(function(event) {
        const end = offset + event.line.length;
        const style = SpreadsheetApp.newTextStyle()
          .setForegroundColor(categoryColors[event.category] || "#222222")
          .setBold(true)
          .setFontSize(9)
          .build();
        builder.setTextStyle(offset, end, style);
        offset = end + 1;
      });

      richRow.push(builder.build());
    }

    calendar.getRange(eventRow, 1, 1, 7).setRichTextValues([richRow]);
  }

  SpreadsheetApp.flush();
  console.log("Ma'am Christine monthly calendar rich-text color coding refreshed.");
}

function getCalendarDisplayTitle_(activityType, notes) {
  const titleMatch = String(notes || "").match(/(?:^|\n)Title:\s*([^\n]+)/i);
  if (titleMatch && titleMatch[1]) return titleMatch[1].trim();

  const clientMatch = String(notes || "").match(/(?:^|\n)Client:\s*([^\n]+)/i);
  if (clientMatch && clientMatch[1]) return activityType + " — " + clientMatch[1].trim();

  return activityType || "Event";
}

function removeLegacyMonthlyCalendarColorRules_(calendar) {
  const monthlyRows = { 6: true, 8: true, 10: true, 12: true, 14: true, 16: true };
  const existingRules = calendar.getConditionalFormatRules();
  const rulesToKeep = existingRules.filter(function(rule) {
    return !rule.getRanges().some(function(range) {
      return monthlyRows[range.getRow()] === true &&
        range.getColumn() === 1 &&
        range.getNumColumns() === 7;
    });
  });
  if (rulesToKeep.length !== existingRules.length) {
    calendar.setConditionalFormatRules(rulesToKeep);
  }
}

/**
 * Keeps the monthly rich-text view synchronized after manual Calendar Log edits
 * or a manual month change in Ma'am Christine Calendar!B2.
 * Programmatic booking/import writes call the refresh directly because onEdit
 * does not fire for script-made changes.
 */
function onEdit(e) {
  try {
    if (!e || !e.range || !e.source) return;
    const sheet = e.range.getSheet();
    const name = sheet.getName();

    if (name === CALENDAR_LOG_SHEET_NAME) {
      const firstRow = Math.max(2, e.range.getRow());
      const lastRow = e.range.getLastRow();
      const firstCol = e.range.getColumn();
      const lastCol = e.range.getLastColumn();
      if (firstRow > lastRow || firstCol > 18 || lastCol < 2) return;

      // Avoid rebuilding Christine's calendar for edits that clearly belong only
      // to another owner. Blank Owner/Date edits still refresh because they may
      // represent deletion of a previously visible Christine event.
      const count = lastRow - firstRow + 1;
      const ownerDateRows = sheet.getRange(firstRow, 2, count, 2).getValues();
      const calendar = e.source.getSheetByName(CHRISTINE_CALENDAR_SHEET_NAME);
      const displayedMonth = calendar ? calendar.getRange("B2").getValue() : null;
      const displayed = displayedMonth instanceof Date
        ? getDatePartsInTimezone_(displayedMonth, e.source.getSpreadsheetTimeZone() || DEFAULT_TIMEZONE)
        : null;

      const shouldRefresh = ownerDateRows.some(function(row) {
        const owner = String(row[0] || "").trim();
        const date = row[1];
        if (!owner || !(date instanceof Date)) return true;
        if (owner !== "Ma'am Christine") return false;
        if (!displayed) return true;
        const parts = getDatePartsInTimezone_(date, e.source.getSpreadsheetTimeZone() || DEFAULT_TIMEZONE);
        return parts.year === displayed.year && parts.month === displayed.month;
      });

      if (shouldRefresh) refreshChristineCalendarColorCoding_(e.source);
      return;
    }

    if (name === CHRISTINE_CALENDAR_SHEET_NAME && e.range.getA1Notation() === "B2") {
      refreshChristineCalendarColorCoding_(e.source);
    }
  } catch (error) {
    console.error("onEdit calendar refresh failed: " + (error && error.stack ? error.stack : error));
  }
}

function onOpen() {
  try {
    SpreadsheetApp.getUi()
      .createMenu("Avodah Tools")
      .addItem("Refresh Christine Calendar Colors", "refreshChristineCalendarColorCoding")
      .addSeparator()
      .addItem("Preview Monthly Schedule", "previewMonthlyScheduleImport")
      .addItem("Commit Schedule Preview", "commitScheduleImportPreview")
      .addSeparator()
      .addItem("Run TEST Cleanup", "runProductionCleanup")
      .addItem("TEST Health Check", "productionHealthCheck")
      .addSeparator()
      .addItem("Reconcile Booking Data", "reconcileBookingData")
      .addItem("Install Required Automation Triggers", "installV3MaintenanceTriggers")
      .addToUi();
  } catch (error) {
    console.log("Custom menu unavailable in this execution context.");
  }
}

/**
 * Non-destructive production cleanup: validates required sheets/configuration,
 * removes obsolete whole-cell monthly color rules, and rebuilds the monthly
 * rich-text calendar. It does not delete leads, appointments, or import rows.
 */
function runProductionCleanup() {
  requireUserRole_(['ADMIN']);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const result = productionHealthCheck();
  refreshChristineCalendarColorCoding_(ss);
  console.log("Production cleanup complete: " + JSON.stringify(result));
  return result;
}

function productionHealthCheck() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  const requiredSheets = [
    LEADS_SHEET_NAME,
    CALENDAR_LOG_SHEET_NAME,
    SETTINGS_SHEET_NAME,
    CHRISTINE_CALENDAR_SHEET_NAME,
    SCHEDULE_IMPORT_SHEET_NAME,
    SCHEDULE_PREVIEW_SHEET_NAME
  ];
  const missingSheets = requiredSheets.filter(function(name) { return !ss.getSheetByName(name); });
  const optionalMissingSheets = [
    BOOKING_AUDIT_SHEET_NAME,
    BOOKING_BLACKOUTS_SHEET_NAME,
    BOOKING_REGISTRY_SHEET_NAME,
    BOOKING_RECONCILIATION_SHEET_NAME
  ].filter(function(name) { return !ss.getSheetByName(name); });

  let config = null;
  let configError = "";
  try {
    config = typeof getBookingRuntimeConfig_ === "function"
      ? getBookingRuntimeConfig_() : getBookingConfig_();
  } catch (error) {
    configError = String(error && error.message ? error.message : error);
  }

  const properties = PropertiesService.getScriptProperties();
  const secretConfigured = Boolean(properties.getProperty("WEBHOOK_SECRET"));
  const nextSecretConfigured = Boolean(properties.getProperty("WEBHOOK_SECRET_NEXT"));
  const environment = String(properties.getProperty("ENVIRONMENT") || "").trim().toUpperCase();
  const calendarWritesEnabled = String(properties.getProperty("ENABLE_CALENDAR_WRITES") || "")
    .trim().toUpperCase() === "TRUE";
  const bookingWorkflowEnabled = String(properties.getProperty("ENABLE_BOOKING_WORKFLOW") || "")
    .trim().toUpperCase() === "TRUE";
  const project1WritesEnabled = String(properties.getProperty("ENABLE_PROJECT1_WRITES") || "")
    .trim().toUpperCase() === "TRUE";
  const managementBaseUrl = getManagementBaseUrl_();
  const adminAlertEmail = getAdminAlertEmail_();
  let calendarAccessible = false;
  let calendarError = "";
  if (config) {
    try {
      calendarAccessible = Boolean(getCalendar_(config.calendarId));
    } catch (error) {
      calendarError = String(error && error.message ? error.message : error);
    }
  }

  const scriptTimezone = Session.getScriptTimeZone();
  const spreadsheetTimezone = ss.getSpreadsheetTimeZone();
  const configuredTimezone = config ? config.timezone : "";
  const timezoneAligned = Boolean(configuredTimezone) &&
    scriptTimezone === configuredTimezone &&
    spreadsheetTimezone === configuredTimezone;

  const warnings = [];
  if (!timezoneAligned) warnings.push("Script, spreadsheet, and booking configuration time zones are not aligned.");
  if (optionalMissingSheets.length) warnings.push("Optional production support sheets are missing: " + optionalMissingSheets.join(", "));
  if (!nextSecretConfigured) warnings.push("WEBHOOK_SECRET_NEXT is not configured; zero-downtime secret rotation is unavailable.");
  if (!calendarWritesEnabled) warnings.push("Calendar writes are disabled by default and require an approved TEST transaction.");
  if (!bookingWorkflowEnabled) warnings.push("The booking workflow write gate is disabled by default.");
  if (!project1WritesEnabled) warnings.push("Project 1 writes are disabled by default.");
  if (!managementBaseUrl) warnings.push("Self-service booking management is unavailable until BOOKING_MANAGEMENT_BASE_URL is configured.");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(adminAlertEmail)) warnings.push("No valid booking/admin notification email is configured.");

  const result = {
    ok: missingSheets.length === 0 && !configError && secretConfigured && calendarAccessible && timezoneAligned,
    version: PRODUCTION_VERSION,
    environment: environment,
    spreadsheet: ss.getName(),
    missing_sheets: missingSheets,
    optional_missing_sheets: optionalMissingSheets,
    webhook_secret_configured: secretConfigured,
    webhook_secret_next_configured: nextSecretConfigured,
    booking_management_configured: Boolean(managementBaseUrl),
    booking_admin_alert_configured: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(adminAlertEmail),
    calendar_id_configured: Boolean(config && config.calendarId),
    calendar_binding: config && config.calendarBinding || "",
    calendar_accessible: calendarAccessible,
    calendar_writes_enabled: calendarWritesEnabled,
    booking_workflow_enabled: bookingWorkflowEnabled,
    project1_writes_enabled: project1WritesEnabled,
    calendar_error: calendarError,
    booking_owner: config ? config.owner : "",
    configured_timezone: configuredTimezone,
    script_timezone: scriptTimezone,
    spreadsheet_timezone: spreadsheetTimezone,
    timezone_aligned: timezoneAligned,
    config_error: configError,
    warnings: warnings
  };
  console.log(JSON.stringify(result));
  return result;
}

function testV3ResilienceSetup() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
  ensureProductionSupportSheets_(ss);
  const token = generateManagementToken_();
  const hash = hashManagementToken_(token);
  if (!token || !hash || token === hash) throw new Error("Management token hashing test failed.");
  console.log(JSON.stringify({
    ok: true,
    version: PRODUCTION_VERSION,
    registry_sheet: Boolean(ss.getSheetByName(BOOKING_REGISTRY_SHEET_NAME)),
    reconciliation_sheet: Boolean(ss.getSheetByName(BOOKING_RECONCILIATION_SHEET_NAME)),
    management_url_configured: Boolean(getManagementBaseUrl_()),
    admin_alert_email_configured: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(getAdminAlertEmail_())
  }));
}

function testBasicRuntime() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  console.log("Basic runtime OK — " + PRODUCTION_VERSION);
}

function testCalendarWriteAccess() {
  requireUserRole_(['ADMIN']);
  assertCalendarWritesEnabled_();
  const config = getBookingConfig_();
  const calendar = getCalendar_(config.calendarId);
  const start = new Date(Date.now() + 10 * 60000);
  const end = new Date(start.getTime() + 5 * 60000);
  const event = calendar.createEvent("[TEST] Avodah Calendar Write Access", start, end, {
    description: "Temporary event created by testCalendarWriteAccess()."
  });
  const id = event.getId();
  event.deleteEvent();
  console.log("Calendar write access OK. Temporary event deleted. Event ID: " + id);
}
function authorizeConfiguredTestScopes() {
  requireUserRole_(['ADMIN']);
  ScriptApp.requireAllScopes(ScriptApp.AuthMode.FULL);
  console.log("Configured TEST scopes are fully authorized.");
}
