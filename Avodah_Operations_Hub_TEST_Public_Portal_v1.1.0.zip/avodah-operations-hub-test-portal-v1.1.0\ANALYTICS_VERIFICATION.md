# Analytics and Management Dashboard Verification

Version: `0.7.0-test-analytics`

Environment: copied `TEST` spreadsheet and copied Apps Script project only.

## Architecture verified

The implemented dependency path is:

`Targets & Settings -> operational source databases -> analytics refresh -> derived analytics tabs -> Management Dashboard`

Operational source ownership is unchanged:

| Module | Authoritative source | Derived output |
|---|---|---|
| Leads | `Lead Database` | `Lead Analytics` |
| Recruitment | `Applicant Tracking` | `Recruitment Analytics` |
| Booking/Calendar | `Booking Registry`, `Calendar Log` | `Calendar and Booking Analytics` |
| Project 1 | `Project 1 Activity Database` | `Project 1 Performance Analytics` |
| Monthly reporting | Four analytics modules | `Monthly Reports` |
| Reporting inventory | Reporting layer state | `Reports and Analytics` |
| Management view | Analytics snapshot | `Dashboard!A45:L69` |

`Dashboard!A1:K17`, the legacy floating chart, `Daily Report`, and `Weekly Report`
remain preserved. The dashboard refresh refuses to write its owned block when
that block contains unrelated content.

## Metric definitions

- Lead totals use rows with a Lead ID. Active counts exclude explicit inactive,
  archived, void, or deleted records. Booking coverage is leads with Booking ID
  divided by all leads. Repeat inquiry rate uses `Inquiry Count > 1`.
- Recruitment totals use rows with an Applicant ID. Stage and Status are grouped
  independently. Requirements and onboarding completion rates use all
  applicants as the denominator.
- Active bookings are Scheduled, Confirmed, or Rescheduled rows that are not
  explicitly inactive. Calendar/Meet coverage divides populated IDs/links by all
  bookings. Reconciliation and sync issues exclude `OK`, `MATCHED`, and `SYNCED`.
- Project 1 totals include non-void activity rows. Current month is derived from
  `Reporting Month` or `Activity Date`. Points always come from stored controlled
  activity rows; no second point table is hard-coded.

No target comparison was added because the blueprint does not supply verified
production target values or a canonical cross-module target schema.

## Derived output verified

| Output | Data rows |
|---|---:|
| Lead Analytics | 10 |
| Recruitment Analytics | 10 |
| Calendar and Booking Analytics | 14 |
| Project 1 Performance Analytics | 25 |
| Monthly Reports (`2026-07`) | 59 |
| Reports and Analytics | 8 |

Final TEST dashboard cards reconcile to the derived tabs:

| Card | TEST value |
|---|---:|
| Total Leads | 6 |
| Active Applicants | 2 |
| Active Bookings | 4 |
| Project 1 points for `2026-07` | 82 |

## Tests passed

### Analytics unit suite: 9/9

- lead totals include historical records;
- active leads exclude archived records;
- repeat inquiry count uses Inquiry Count;
- recruitment keeps Stage and Status separate;
- hired applicants are status-based;
- active booking rules exclude cancelled records;
- booking reconciliation issues are surfaced;
- Project 1 totals exclude void activities; and
- Project 1 current-month points group correctly.

### Initial live transaction suite: 9/9

- operational source fingerprints remained unchanged;
- legacy Dashboard, Daily Report, and Weekly Report formulas remained unchanged;
- a repeat refresh was idempotent after excluding freshness timestamps;
- all four analytics row counts matched the source-backed model;
- the second refresh completed in TEST; and
- current-month metric keys remained unique.

### Final bounded layout verification

Visual QA found the legacy floating chart over the initially blank cell block.
The owned range was migrated from `A20:L44` to `A45:L69`; the earlier block was
cleared only after its ownership marker matched. Two bounded refreshes then
produced identical values across all four analytics tabs, Monthly Reports,
Reports and Analytics, and the Management Dashboard.

One monolithic post-migration editor run exceeded the Apps Script editor's live
connection window before any dashboard write. The same checks were split into
bounded refresh/read-back passes and completed successfully.

### Regression and setup

- 21 `.gs` files parsed successfully.
- 359 declared global functions; 0 duplicate names.
- 9/9 final live analytics unit checks passed.
- 13/13 foundation regression checks passed.
- `masterSetup()` created 0 sheets, appended 0 headers, seeded 0 duplicate
  settings, preserved all 24 logical/aliased sheets, and skipped triggers because
  the trigger gate was disabled.
- Final Apps Script source matches the local package for `Config.gs`,
  `Analytics.gs`, and `Dashboard.gs`.

## Visual and native-sheet QA

- Derived headers, filters, and frozen header rows remain intact.
- Rate rows display as percentages.
- Long dimensions wrap or fit without clipping.
- Derived tabs and the dashboard owned block have warning-only protection.
- The new dashboard is below the legacy chart and does not obstruct it.
- The dashboard shows source/freshness metadata and a derived-view warning.

## Final safety state

- All seven module/portal/trigger gates are `FALSE`, including
  `ENABLE_ANALYTICS_WRITES`.
- Installed Apps Script triggers: 0.
- No deployment was created or changed.
- No production spreadsheet was accessed or modified.
- Calendar, booking, applicant, Project 1, intake, and lead source rows were not
  changed by the analytics phase.

## Next blueprint stage

Implement and verify scheduled daily, weekly, and monthly operations. Keep
`ENABLE_AUTOMATION_TRIGGERS=FALSE` until the callback tests, ownership review,
and trigger inventory pass in TEST.
