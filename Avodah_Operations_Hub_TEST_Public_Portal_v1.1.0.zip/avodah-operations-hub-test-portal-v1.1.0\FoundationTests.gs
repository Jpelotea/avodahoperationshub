/** Read-only helper tests and schema gap inspection. */

function runFoundationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  testAssert_(tests, 'email normalization',
    normalizeEmail_(' Test.User@Example.COM ') === 'test.user@example.com');
  testAssert_(tests, 'valid email', isValidEmail_('test.user@example.com'));
  testAssert_(tests, 'invalid email rejected', !isValidEmail_('not-an-email'));
  testAssert_(tests, 'Philippines phone normalization',
    normalizePhone_('0917 123 4567') === '+639171234567');
  testAssert_(tests, 'normalized phone validation',
    isValidPhone_('+639171234567'));
  testAssert_(tests, 'explicit consent accepted', isConsentGranted_('Yes'));
  testAssert_(tests, 'missing consent rejected', !isConsentGranted_('No'));
  testAssert_(tests, 'header normalization',
    normalizeHeader_('Booking_ID') === normalizeHeader_('Booking ID'));
  var intakeId = generateUniqueId_('INTAKE');
  var secondIntakeId = generateUniqueId_('INTAKE');
  testAssert_(tests, 'INT id prefix', intakeId.indexOf('INT-') === 0);
  testAssert_(tests, 'unique IDs', intakeId !== secondIntakeId);
  var names = AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(item) { return item.name; });
  testAssert_(tests, 'unique logical sheet names',
    names.length === names.filter(function(name, index) {
      return names.indexOf(name) === index;
    }).length);
  testAssert_(tests, 'README Project 1 mapping count',
    AVODAH_PROJECT1_ACTIVITY_SEEDS.length === 18);
  var pointSum = AVODAH_PROJECT1_ACTIVITY_SEEDS.reduce(function(sum, row) {
    return sum + Number(row[2]);
  }, 0);
  testAssert_(tests, 'README Project 1 point total', pointSum === 41);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  try { console.log(JSON.stringify(result)); } catch (ignored) {}
  return result;
}

function testAssert_(tests, name, condition) {
  tests.push({name: name, passed: Boolean(condition)});
}

function runIntakeLeadValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var valid = {
    'Submission ID': 'test-submission',
    'Submitted At': '2026-07-22T09:00:00.000Z',
    'Full Name': 'Test Client',
    'Email Address': 'test.client@example.com',
    'Mobile Number': '0917 123 4567',
    'Consent': 'Yes'
  };
  testAssert_(tests, 'valid intake record',
    validateIntakeRecord_(valid, normalizeEmail_(valid['Email Address']),
      normalizePhone_(valid['Mobile Number'])) === true);
  var noConsent = Object.assign({}, valid, {'Consent': 'No'});
  testAssert_(tests, 'consent validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(noConsent, normalizeEmail_(noConsent['Email Address']),
        normalizePhone_(noConsent['Mobile Number']));
    }) === 'CONSENT_REQUIRED');
  var badEmail = Object.assign({}, valid, {'Email Address': 'not-an-email'});
  testAssert_(tests, 'email validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(badEmail, normalizeEmail_(badEmail['Email Address']),
        normalizePhone_(badEmail['Mobile Number']));
    }) === 'INVALID_EMAIL');
  var badPhone = Object.assign({}, valid, {'Mobile Number': '123'});
  testAssert_(tests, 'phone validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(badPhone, normalizeEmail_(badPhone['Email Address']),
        normalizePhone_(badPhone['Mobile Number']));
    }) === 'INVALID_PHONE');
  var leadRows = [{rowNumber: 2, record: {
    'Lead ID': 'LEAD-TEST',
    'Normalized Email': 'existing@example.com',
    'Normalized Phone': '+639171234567'
  }}];
  var exact = resolveLeadIdentity_(leadRows, 'existing@example.com', '+639171234567');
  testAssert_(tests, 'exact email resolves existing lead',
    exact.match && exact.match.record['Lead ID'] === 'LEAD-TEST');
  var sharedPhone = resolveLeadIdentity_(leadRows, 'different@example.com',
    '+639171234567');
  testAssert_(tests, 'shared phone does not merge different email',
    !sharedPhone.match && sharedPhone.possiblePhoneDuplicate === true);
  testAssert_(tests, 'formula-like input is escaped',
    safeCellValue_('=1+1', 'Full Name').indexOf("'=") === 0);
  testAssert_(tests, 'international phone is stored as literal text',
    safeCellValue_('+639171234567', 'Normalized Phone') === "'+639171234567");
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  try { console.log(JSON.stringify(result)); } catch (ignored) {}
  return result;
}

function testErrorCode_(callback) {
  try {
    callback();
    return '';
  } catch (error) {
    return error.code || error.name || 'ERROR';
  }
}

function runBookingValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var config = {
    timezone: 'Asia/Manila',
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    startHour: 9,
    endHour: 17,
    durationMinutes: 30,
    slotIntervalMinutes: 60,
    bufferBeforeMinutes: 30,
    bufferAfterMinutes: 30,
    minimumNoticeHours: 24,
    horizonDays: 30
  };
  var now = makeDateInTimezone_(2026, 6, 22, 8, 0, config.timezone);
  var valid = makeDateInTimezone_(2026, 6, 24, 9, 0, config.timezone);
  testAssert_(tests, 'valid booking slot accepted',
    validateBookingSlotRules_(valid, config, now).ok);
  testAssert_(tests, '24-hour notice enforced',
    validateBookingSlotRules_(makeDateInTimezone_(2026, 6, 23, 7, 0,
      config.timezone), config, now).code === 'MINIMUM_NOTICE_REQUIRED');
  testAssert_(tests, '30-day booking horizon enforced',
    validateBookingSlotRules_(makeDateInTimezone_(2026, 7, 22, 9, 0,
      config.timezone), config, now).code === 'BOOKING_HORIZON_EXCEEDED');
  testAssert_(tests, 'opening-hour restriction enforced',
    validateBookingSlotRules_(makeDateInTimezone_(2026, 6, 24, 8, 0,
      config.timezone), config, now).code === 'WORKING_HOURS_RESTRICTED');
  testAssert_(tests, 'closing-hour restriction enforced',
    validateBookingSlotRules_(makeDateInTimezone_(2026, 6, 24, 17, 0,
      config.timezone), config, now).code === 'WORKING_HOURS_RESTRICTED');
  testAssert_(tests, 'slot interval enforced',
    validateBookingSlotRules_(makeDateInTimezone_(2026, 6, 24, 9, 30,
      config.timezone), config, now).code === 'INVALID_SLOT_INTERVAL');
  var weekdayConfig = Object.assign({}, config, {days: ['Mon']});
  testAssert_(tests, 'working-day restriction enforced',
    validateBookingSlotRules_(valid, weekdayConfig, now).code === 'WORKING_DAY_RESTRICTED');
  testAssert_(tests, 'blackout overlap detected', isBlockedByBlackout_(
    valid, new Date(valid.getTime() + 30 * 60 * 1000), [{
      start: valid.getTime() - 1,
      end: valid.getTime() + 1
    }]));
  testAssert_(tests, 'calendar binding is stable',
    bookingCalendarBinding_('calendar-a', 'TEST') ===
      bookingCalendarBinding_('calendar-a', 'TEST'));
  testAssert_(tests, 'calendar binding separates environments',
    bookingCalendarBinding_('calendar-a', 'TEST') !==
      bookingCalendarBinding_('calendar-a', 'PRODUCTION'));
  testAssert_(tests, 'BOOK ID prefix available',
    generateUniqueId_('BOOKING').indexOf('BOOK-') === 0);
  testAssert_(tests, 'CAL ID prefix available',
    generateUniqueId_('CALENDAR').indexOf('CAL-') === 0);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(result));
  return result;
}

function createBookingIntegrationFixture_(label, phone) {
  var submittedAt = new Date();
  var intakeId = generateUniqueId_('INTAKE');
  var leadId = generateUniqueId_('LEAD');
  var submissionId = Utilities.getUuid();
  var email = 'booking.test.' + String(label || Utilities.getUuid())
    .toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 24) + '@example.com';
  var normalizedPhone = normalizePhone_(phone || '09170000001');
  var intakeRow = appendObjectRow_('Intake Submissions', {
    'Submission ID': submissionId,
    'Submitted At': submittedAt,
    'Primary Need': 'TEST booking integration',
    'Recommended Service Path': 'TEST only',
    'Consultation Requested': 'Yes',
    'Full Name': 'TEST Booking Fixture ' + label,
    'Mobile Number': phone || '09170000001',
    'Email Address': email,
    'Consent': 'Yes',
    'Follow-up Status': 'New',
    'Intake ID': intakeId,
    'Normalized Email': email,
    'Normalized Phone': normalizedPhone,
    'Lead ID': leadId,
    'Duplicate Status': 'TEST_FIXTURE',
    'Processing Status': 'PROCESSED',
    'Last Processed At': submittedAt
  });
  var leadRow = appendObjectRow_('Lead Database', {
    'Lead ID': leadId,
    'Primary Intake ID': intakeId,
    'First Inquiry At': submittedAt,
    'Latest Inquiry At': submittedAt,
    'Full Name': 'TEST Booking Fixture ' + label,
    'Email Address': email,
    'Normalized Email': email,
    'Mobile Number': phone || '09170000001',
    'Normalized Phone': normalizedPhone,
    'Primary Need': 'TEST booking integration',
    'Recommended Service Path': 'TEST only',
    'Lead Source': 'BOOKING_INTEGRATION_TEST',
    'Assigned To': "Ma'am Christine",
    'Lead Status': 'NEW',
    'Follow-up Status': 'New',
    'Duplicate Status': 'TEST_FIXTURE',
    'Inquiry Count': 1,
    'Record Status': 'ACTIVE',
    'Created At': submittedAt,
    'Updated At': submittedAt,
    'Created By': bookingActorEmail_(),
    'Updated By': bookingActorEmail_()
  });
  return {intakeId: intakeId, leadId: leadId, intakeRow: intakeRow,
    leadRow: leadRow, email: email};
}

function runBookingLifecycleIntegrationTest() {
  requireUserRole_(['ADMIN']);
  assertBookingWritesEnabled_();
  var spreadsheet = getHubSpreadsheet_();
  if (!/^TEST(?:\s|-)/i.test(spreadsheet.getName())) {
    throw avodahError_('TEST_ONLY', 'Booking integration tests require the copied TEST spreadsheet.');
  }
  var suffix = Utilities.formatDate(new Date(), AVODAH_CONFIG.TIME_ZONE,
    'yyyyMMddHHmmss');
  var primary = createBookingIntegrationFixture_(suffix + 'A', '09170000001');
  var secondary = createBookingIntegrationFixture_(suffix + 'B', '09170000002');
  var availability = getBookingAvailability_();
  if (!availability.days.length || !availability.days[0].slots.length) {
    throw avodahError_('NO_TEST_SLOT', 'No TEST calendar slot is available for integration testing.');
  }
  var firstSlot = availability.days[0].slots[0];
  var idempotencyKey = 'integration-' + Utilities.getUuid();
  var created;
  var results = [];
  try {
    created = createConsultationBooking_({
      lead_id: primary.leadId,
      intake_id: primary.intakeId,
      start: firstSlot.start,
      idempotency_key: idempotencyKey
    }, {source: 'INTEGRATION_TEST'});
    testAssert_(results, 'booking created', created.ok &&
      created.code.indexOf('BOOKING_CREATED') === 0);
    testAssert_(results, 'BOOK-prefixed booking ID',
      String(created.booking_id || '').indexOf('BOOK-') === 0);
    testAssert_(results, 'Calendar event ID stored', Boolean(created.event_id));
    testAssert_(results, 'unique Google Meet created',
      /^https:\/\/meet\.google\.com\//.test(String(created.meet_link || '')));

    var replay = createConsultationBooking_({
      lead_id: primary.leadId,
      intake_id: primary.intakeId,
      start: firstSlot.start,
      idempotency_key: idempotencyKey
    }, {source: 'INTEGRATION_TEST'});
    testAssert_(results, 'idempotent replay returns same booking',
      replay.code === 'IDEMPOTENT_REPLAY' && replay.booking_id === created.booking_id);

    var conflict = createConsultationBooking_({
      lead_id: secondary.leadId,
      intake_id: secondary.intakeId,
      start: firstSlot.start,
      idempotency_key: 'integration-conflict-' + Utilities.getUuid()
    }, {source: 'INTEGRATION_TEST'});
    testAssert_(results, 'busy-slot and buffer conflict rejected',
      !conflict.ok && conflict.code === 'SLOT_UNAVAILABLE');

    var registry = firstObjectByHeaderValue_('Booking Database', 'Booking ID',
      created.booking_id);
    var log = findCalendarLogBooking_(created.booking_id);
    var intake = firstObjectByHeaderValue_('Intake Submissions', 'Intake ID',
      primary.intakeId);
    var lead = firstObjectByHeaderValue_('Lead Database', 'Lead ID', primary.leadId);
    testAssert_(results, 'Booking Database row created', Boolean(registry));
    testAssert_(results, 'Calendar Log row created with CAL ID', Boolean(log) &&
      String(log.record['Calendar Log ID'] || '').indexOf('CAL-') === 0);
    testAssert_(results, 'Intake linked to booking', intake &&
      intake.record['Booking ID'] === created.booking_id);
    testAssert_(results, 'Lead linked to booking', lead &&
      lead.record['Booking ID'] === created.booking_id);

    var logContext = getTableContext_('Calendar Log');
    logContext.sheet.getRange(log.rowNumber, 2, 1,
      logContext.headers.length - 1).clearContent();
    var repaired = reconcileBookingRecords_({source: 'INTEGRATION_TEST'});
    testAssert_(results, 'reconciliation repaired removed Calendar Log row',
      repaired.repaired_calendar_log >= 1 && Boolean(findCalendarLogBooking_(created.booking_id)));
    testAssert_(results, 'legacy rows skipped by calendar binding',
      repaired.skipped_unbound_legacy >= 1);

    var laterAvailability = getBookingAvailability_();
    var rescheduleSlot = null;
    for (var d = 0; d < laterAvailability.days.length && !rescheduleSlot; d += 1) {
      for (var s = 0; s < laterAvailability.days[d].slots.length; s += 1) {
        if (laterAvailability.days[d].slots[s].start !== firstSlot.start) {
          rescheduleSlot = laterAvailability.days[d].slots[s];
          break;
        }
      }
    }
    if (!rescheduleSlot) throw avodahError_('NO_RESCHEDULE_SLOT',
      'No second TEST slot is available for reschedule testing.');
    var rescheduled = rescheduleConsultationBooking_({
      booking_id: created.booking_id,
      start: rescheduleSlot.start
    }, {source: 'INTEGRATION_TEST'});
    testAssert_(results, 'reschedule lifecycle passed', rescheduled.ok &&
      rescheduled.code === 'BOOKING_RESCHEDULED');

    var cancelled = cancelConsultationBooking_({
      booking_id: created.booking_id,
      reason: 'Automated TEST lifecycle cleanup'
    }, {source: 'INTEGRATION_TEST'});
    testAssert_(results, 'cancellation lifecycle passed', cancelled.ok &&
      cancelled.code === 'BOOKING_CANCELLED');
    var config = getBookingRuntimeConfig_();
    var removedEvent = readBookingCalendarEvent_(config, created.event_id);
    testAssert_(results, 'TEST Calendar event removed after cancellation',
      removedEvent === null || removedEvent.status === 'cancelled');
    var finalRegistry = firstObjectByHeaderValue_('Booking Database', 'Booking ID',
      created.booking_id);
    testAssert_(results, 'cancelled registry retained for audit', finalRegistry &&
      finalRegistry.record.Status === 'Cancelled');
  } catch (error) {
    if (created && created.event_id) {
      try { deleteBookingCalendarEvent_(getBookingRuntimeConfig_(), created.event_id); } catch (ignored) {}
    }
    throw error;
  }
  var failures = results.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: results, failures: failures,
    bookingId: created && created.booking_id || '', eventRemoved: true};
  console.log(JSON.stringify(result));
  return result;
}

function inspectFoundationGap_() {
  var spreadsheet = getHubSpreadsheet_();
  return AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(definition) {
    var sheet = findSheetForDefinition_(spreadsheet, definition);
    var missingHeaders = [];
    if (sheet && (definition.mode === 'TABLE' || definition.mode === 'DERIVED')) {
      var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
      missingHeaders = (definition.headers || []).filter(function(header) {
        return map[normalizeHeader_(header)] == null;
      });
    }
    return {
      logicalName: definition.name,
      physicalName: sheet ? sheet.getName() : '',
      exists: Boolean(sheet),
      missingHeaders: missingHeaders
    };
  });
}

/** Read-only security and activation-gate regression for the copied TEST project. */
function runSecurityValidationTests() {
  var user = requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var properties = PropertiesService.getScriptProperties();
  var spreadsheet = getHubSpreadsheet_();
  var writeGates = [
    'ENABLE_BOOKING_WORKFLOW', 'ENABLE_PROJECT1_WRITES',
    'ENABLE_RECRUITMENT_WRITES', 'ENABLE_ANALYTICS_WRITES',
    'ENABLE_SCHEDULE_IMPORT_WRITES', 'ENABLE_CALENDAR_WRITES',
    'PUBLIC_PORTAL_ENABLED', 'ENABLE_AUTOMATION_TRIGGERS'
  ];
  testAssert_(tests, 'authenticated USER_ROLE is active',
    Boolean(user && ['ADMIN', 'MANAGER'].indexOf(user.role) !== -1));
  testAssert_(tests, 'environment remains TEST', getEnvironment_() === 'TEST');
  testAssert_(tests, 'configured spreadsheet remains TEST-labelled',
    /^TEST(?:\s|-)/i.test(spreadsheet.getName()));
  testAssert_(tests, 'required Script Properties are present',
    AVODAH_CONFIG.REQUIRED_SCRIPT_PROPERTIES.every(function(name) {
      return Boolean(properties.getProperty(name));
    }));
  testAssert_(tests, 'all activation/write gates are disabled',
    writeGates.every(function(name) {
      return !truthy_(properties.getProperty(name));
    }));
  testAssert_(tests, 'no project triggers are installed while disabled',
    ScriptApp.getProjectTriggers().length === 0);
  testAssert_(tests, 'trigger definitions are valid',
    validateRequiredTriggerDefinitions_().valid);
  testAssert_(tests, 'forged webhook secret is rejected',
    !isAuthorizedWebhookSecret_('AVODAH-INVALID-SECURITY-TEST'));
  testAssert_(tests, 'direct trigger callback is rejected',
    testErrorCode_(function() {
      assertAuthorizedTriggerEvent_('scheduledDashboardRefresh', null);
    }) === 'AUTOMATION_TRIGGERS_DISABLED');
  testAssert_(tests, 'Advanced Calendar service is available',
    Boolean(typeof Calendar !== 'undefined' && Calendar.Events && Calendar.Freebusy));
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(result));
  return result;
}

/** Read-only public-portal validation while every public/write gate is disabled. */
function runPublicPortalValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var validPayload = {
    submission_id: '123e4567-e89b-42d3-a456-426614174000',
    full_name: 'TEST Portal Client',
    email: ' Portal.Client@Example.com ',
    mobile_number: '0917 123 4567',
    location: 'TEST City',
    primary_need: 'TEST inquiry only',
    consultation_requested: true,
    consent: true,
    website: ''
  };
  var normalized = normalizePublicIntakePayload_(validPayload);
  testAssert_(tests, 'valid public intake payload is accepted',
    normalized.fullName === 'TEST Portal Client');
  testAssert_(tests, 'public intake email is normalized',
    normalized.email === 'portal.client@example.com');
  testAssert_(tests, 'public intake phone is normalized',
    normalized.normalizedPhone === '+639171234567');
  testAssert_(tests, 'public intake consultation preference is preserved',
    normalized.consultationRequested === true);
  testAssert_(tests, 'honeypot submission is rejected',
    testErrorCode_(function() {
      normalizePublicIntakePayload_(Object.assign({}, validPayload,
        {website: 'https://spam.example'}));
    }) === 'INVALID_SUBMISSION');
  testAssert_(tests, 'invalid public submission ID is rejected',
    testErrorCode_(function() {
      normalizePublicIntakePayload_(Object.assign({}, validPayload,
        {submission_id: 'not-a-uuid'}));
    }) === 'INVALID_SUBMISSION_ID');
  testAssert_(tests, 'public consent is required',
    testErrorCode_(function() {
      normalizePublicIntakePayload_(Object.assign({}, validPayload,
        {consent: false}));
    }) === 'CONSENT_REQUIRED');

  var issuedAt = new Date('2026-07-23T00:00:00.000Z');
  var testOnlyTokenSecret = 'TEST_ONLY_PUBLIC_TOKEN_SECRET_32_BYTES';
  var token = issuePublicWorkflowToken_('INT-TEST', 'LEAD-TEST',
    'portal.client@example.com', issuedAt, testOnlyTokenSecret);
  var claims = verifyPublicWorkflowToken_(token,
    new Date('2026-07-23T00:30:00.000Z'), testOnlyTokenSecret);
  testAssert_(tests, 'signed public workflow token round-trips',
    claims.intake_id === 'INT-TEST' && claims.lead_id === 'LEAD-TEST');
  var tokenParts = token.split('.');
  var tamperedToken = tokenParts[0] + '.' +
    (tokenParts[1].charAt(0) === 'a' ? 'b' : 'a') + tokenParts[1].substring(1);
  testAssert_(tests, 'tampered public workflow token is rejected',
    testErrorCode_(function() {
      verifyPublicWorkflowToken_(tamperedToken,
        new Date('2026-07-23T00:30:00.000Z'), testOnlyTokenSecret);
    }) === 'INVALID_PUBLIC_TOKEN');
  testAssert_(tests, 'expired public workflow token is rejected',
    testErrorCode_(function() {
      verifyPublicWorkflowToken_(token,
        new Date('2026-07-23T02:00:01.000Z'), testOnlyTokenSecret);
    }) === 'INVALID_PUBLIC_TOKEN');

  var status = publicPortalGateStatus_();
  testAssert_(tests, 'public portal remains disabled during staging',
    status.enabled === false && status.intakeEnabled === false);
  testAssert_(tests, 'public booking remains disabled during staging',
    status.bookingEnabled === false);
  testAssert_(tests, 'direct public intake call fails closed while disabled',
    testErrorCode_(function() { submitPublicIntake(validPayload); }) ===
      'PUBLIC_PORTAL_DISABLED');
  testAssert_(tests, 'direct public availability call fails closed while disabled',
    testErrorCode_(function() { getPublicBookingAvailability(); }) ===
      'PUBLIC_PORTAL_DISABLED');
  testAssert_(tests, 'explicit portal route renders the public template',
    foundationPublicDoGet_().getTitle() === 'Avodah Consultation Portal');

  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(result));
  return result;
}

/** Aggregates every side-effect-free validation suite for deployment checks. */
function runAllReadOnlyValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var definitions = [
    ['Foundation', runFoundationTests],
    ['Intake and Leads', runIntakeLeadValidationTests],
    ['Booking Rules', runBookingValidationTests],
    ['Project 1', runProject1ValidationTests],
    ['Recruitment', runRecruitmentValidationTests],
    ['Analytics', runAnalyticsValidationTests],
    ['Scheduled Reporting', runScheduledReportingValidationTests],
    ['Schedule Import', runScheduleImportValidationTests],
    ['Security Gates', runSecurityValidationTests],
    ['Public Portal', runPublicPortalValidationTests]
  ];
  var suites = definitions.map(function(definition) {
    try {
      var result = definition[1]();
      return {
        name: definition[0],
        passed: Boolean(result && result.passed),
        assertions: result && result.tests ? result.tests.length : 0,
        failures: result && result.failures ? result.failures : []
      };
    } catch (error) {
      return {
        name: definition[0],
        passed: false,
        assertions: 0,
        failures: [{name: error.code || error.name || 'ERROR',
          message: error.message}]
      };
    }
  });
  var output = {
    passed: suites.every(function(suite) { return suite.passed; }),
    assertions: suites.reduce(function(total, suite) {
      return total + Number(suite.assertions || 0);
    }, 0),
    suites: suites
  };
  console.log(JSON.stringify(output));
  return output;
}
