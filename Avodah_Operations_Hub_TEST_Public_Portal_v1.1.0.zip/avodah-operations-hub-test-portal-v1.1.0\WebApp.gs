/** Gated web-app routing and public consultation portal endpoints. */

function renderHubTemplate_(fileName, title) {
  return HtmlService.createTemplateFromFile(fileName)
    .evaluate()
    .setTitle(title)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function foundationDoGet_() {
  var email = getCurrentUserEmail_();
  var role = null;
  try { role = email ? getUserRoleRecord_(email) : null; } catch (ignored) {}
  return role ? renderHubTemplate_('Index', 'Avodah Operations Hub') :
    renderHubTemplate_('PublicPortal', 'Avodah Consultation Portal');
}

function foundationPublicDoGet_() {
  return renderHubTemplate_('PublicPortal', 'Avodah Consultation Portal');
}

function foundationDoPostDisabled_() {
  return foundationJsonResponse_({
    status: 'NOT_ACTIVE',
    code: 'FOUNDATION_GATE',
    message: 'Webhook intake is not active in the Foundation package.'
  });
}

function include_(fileName) {
  return HtmlService.createHtmlOutputFromFile(fileName).getContent();
}

function foundationJsonResponse_(payload) {
  return ContentService.createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

function getInternalFoundationStatus() {
  var user = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var verification = verifyConfiguration_();
  return {
    version: AVODAH_CONFIG.VERSION,
    environment: verification.environment,
    user: {email: user.email, role: user.role},
    configurationGates: verification.configurationGates,
    readyForProduction: verification.readyForProduction
  };
}

function publicPortalGateStatus_() {
  var properties = PropertiesService.getScriptProperties();
  var enabled = truthy_(properties.getProperty('PUBLIC_PORTAL_ENABLED'));
  var bookingEnabled = enabled &&
    truthy_(properties.getProperty('ENABLE_BOOKING_WORKFLOW')) &&
    truthy_(properties.getProperty('ENABLE_CALENDAR_WRITES'));
  return {
    version: AVODAH_CONFIG.VERSION,
    environment: getEnvironment_(),
    enabled: enabled,
    intakeEnabled: enabled,
    bookingEnabled: bookingEnabled
  };
}

function getPublicFoundationStatus() {
  var status = publicPortalGateStatus_();
  return {
    version: status.version,
    environment: status.environment,
    publicPortalEnabled: status.enabled,
    intakeActive: status.intakeEnabled,
    bookingActive: status.bookingEnabled
  };
}

function getPublicPortalBootstrap() {
  var status = publicPortalGateStatus_();
  var output = {
    version: status.version,
    environment: status.environment,
    enabled: status.enabled,
    intake_enabled: status.intakeEnabled,
    booking_enabled: status.bookingEnabled,
    timezone: AVODAH_CONFIG.TIME_ZONE
  };
  if (status.bookingEnabled) {
    var config = getBookingRuntimeConfig_();
    output.booking_policy = {
      duration_minutes: config.durationMinutes,
      minimum_notice_hours: config.minimumNoticeHours,
      booking_horizon_days: config.horizonDays
    };
  }
  return output;
}

function assertPublicPortalEnabled_() {
  var status = publicPortalGateStatus_();
  if (status.environment !== 'TEST') {
    throw avodahError_('TEST_ONLY',
      'This public portal package is restricted to the copied TEST environment.');
  }
  if (!status.enabled) {
    throw avodahError_('PUBLIC_PORTAL_DISABLED',
      'The public consultation portal is not active.');
  }
  var spreadsheet = getHubSpreadsheet_();
  if (!/^TEST(?:\s|-)/i.test(spreadsheet.getName())) {
    throw avodahError_('TEST_ONLY',
      'The public portal may write only to the copied TEST spreadsheet.');
  }
  publicTokenSecret_();
  return status;
}

function assertPublicBookingEnabled_() {
  var status = assertPublicPortalEnabled_();
  if (!status.bookingEnabled) {
    throw avodahError_('PUBLIC_BOOKING_DISABLED',
      'Consultation booking is not active.');
  }
  assertBookingWritesEnabled_();
  return status;
}

function publicPortalText_(value, maximum) {
  return String(value == null ? '' : value)
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .substring(0, Number(maximum || 500));
}

function normalizePublicIntakePayload_(payload) {
  var input = payload || {};
  if (publicPortalText_(input.website, 200)) {
    throw avodahError_('INVALID_SUBMISSION', 'The submission could not be accepted.');
  }
  var fullName = publicPortalText_(input.full_name || input.fullName, 120);
  var email = normalizeEmail_(input.email || input.email_address);
  var rawPhone = publicPortalText_(input.mobile_number || input.phone, 40);
  var phone = normalizePhone_(rawPhone);
  var submissionId = publicPortalText_(input.submission_id || input.submissionId, 60);
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
      .test(submissionId)) {
    throw avodahError_('INVALID_SUBMISSION_ID', 'Please refresh and submit the form again.');
  }
  if (fullName.length < 2) {
    throw avodahError_('FULL_NAME_REQUIRED', 'Please enter your full name.');
  }
  if (!isValidEmail_(email)) {
    throw avodahError_('INVALID_EMAIL', 'Please enter a valid email address.');
  }
  if (rawPhone && !isValidPhone_(phone)) {
    throw avodahError_('INVALID_PHONE', 'Please enter a valid mobile number.');
  }
  if (!isConsentGranted_(input.consent)) {
    throw avodahError_('CONSENT_REQUIRED',
      'Consent is required before the inquiry can be submitted.');
  }
  return {
    submissionId: submissionId,
    fullName: fullName,
    email: email,
    rawPhone: rawPhone,
    normalizedPhone: phone,
    location: publicPortalText_(input.location, 120),
    primaryNeed: publicPortalText_(input.primary_need || input.primaryNeed, 300),
    preferredContactMethod: publicPortalText_(
      input.preferred_contact_method || input.preferredContactMethod, 100),
    preferredSchedule: publicPortalText_(
      input.preferred_schedule || input.preferredSchedule, 160),
    additionalNotes: publicPortalText_(input.additional_notes || input.notes, 1000),
    consultationRequested: truthy_(
      input.consultation_requested || input.consultationRequested)
  };
}

function publicRateKey_(scope, value) {
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    String(scope || '') + '|' + String(value || ''), Utilities.Charset.UTF_8);
  return 'AVODAH_PUBLIC_' + String(scope || 'ACTION').toUpperCase() + '_' +
    Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '').substring(0, 32);
}

function assertPublicRateLimit_(scope, value, maximum, ttlSeconds) {
  var cache = CacheService.getScriptCache();
  var key = publicRateKey_(scope, value);
  var count = Number(cache.get(key) || 0);
  if (count >= Number(maximum || 5)) {
    throw avodahError_('RATE_LIMITED',
      'Too many attempts were received. Please try again later.');
  }
  cache.put(key, String(count + 1), Number(ttlSeconds || 3600));
}

function publicTokenSecret_() {
  var secret = String(PropertiesService.getScriptProperties()
    .getProperty('WEBHOOK_SECRET') || '');
  if (secret.length < 24) {
    throw avodahError_('PUBLIC_TOKEN_NOT_CONFIGURED',
      'The public workflow token service is not configured.');
  }
  return secret;
}

function publicBase64Encode_(value) {
  return Utilities.base64EncodeWebSafe(String(value), Utilities.Charset.UTF_8)
    .replace(/=+$/g, '');
}

function publicBase64Decode_(value) {
  return Utilities.newBlob(Utilities.base64DecodeWebSafe(String(value)))
    .getDataAsString('UTF-8');
}

function publicHmac_(value, secretOverride) {
  var secret = String(secretOverride || publicTokenSecret_());
  var signature = Utilities.computeHmacSha256Signature(String(value),
    secret, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(signature).replace(/=+$/g, '');
}

function publicConstantTimeEquals_(left, right) {
  var a = String(left || '');
  var b = String(right || '');
  var mismatch = a.length ^ b.length;
  var length = Math.max(a.length, b.length);
  for (var index = 0; index < length; index += 1) {
    mismatch |= (a.charCodeAt(index % Math.max(a.length, 1)) || 0) ^
      (b.charCodeAt(index % Math.max(b.length, 1)) || 0);
  }
  return mismatch === 0;
}

function issuePublicWorkflowToken_(intakeId, leadId, email, nowValue,
    secretOverride) {
  var issuedAt = nowValue instanceof Date ? nowValue : new Date();
  var claims = {
    kind: 'PUBLIC_BOOKING',
    intake_id: String(intakeId || ''),
    lead_id: String(leadId || ''),
    email: normalizeEmail_(email),
    exp: Math.floor(issuedAt.getTime() / 1000) + 3600,
    nonce: Utilities.getUuid()
  };
  var encoded = publicBase64Encode_(JSON.stringify(claims));
  return encoded + '.' + publicHmac_(encoded, secretOverride);
}

function verifyPublicWorkflowToken_(token, nowValue, secretOverride) {
  var text = publicPortalText_(token, 4096);
  var parts = text.split('.');
  if (parts.length !== 2 || !publicConstantTimeEquals_(
      publicHmac_(parts[0], secretOverride), parts[1])) {
    throw avodahError_('INVALID_PUBLIC_TOKEN',
      'The consultation session is invalid or has expired.');
  }
  var claims;
  try { claims = JSON.parse(publicBase64Decode_(parts[0])); } catch (error) {
    throw avodahError_('INVALID_PUBLIC_TOKEN',
      'The consultation session is invalid or has expired.');
  }
  var current = nowValue instanceof Date ? nowValue : new Date();
  if (!claims || claims.kind !== 'PUBLIC_BOOKING' ||
      !claims.intake_id || !claims.lead_id ||
      Number(claims.exp || 0) < Math.floor(current.getTime() / 1000)) {
    throw avodahError_('INVALID_PUBLIC_TOKEN',
      'The consultation session is invalid or has expired.');
  }
  return claims;
}

function publicIntakeResult_(promotion, rowNumber, email, idempotent) {
  return {
    ok: true,
    code: idempotent ? 'PUBLIC_INTAKE_REPLAY' : 'PUBLIC_INTAKE_ACCEPTED',
    submission_id: String(promotion.submissionId || ''),
    intake_id: String(promotion.intakeId || ''),
    lead_id: String(promotion.leadId || ''),
    duplicate_status: String(promotion.duplicateStatus || ''),
    workflow_token: issuePublicWorkflowToken_(promotion.intakeId,
      promotion.leadId, email),
    idempotent: Boolean(idempotent)
  };
}

function submitPublicIntake(payload) {
  assertPublicPortalEnabled_();
  var normalized = normalizePublicIntakePayload_(payload);
  return withScriptLock_('public intake ' + normalized.submissionId, function() {
    var existingRows = findRowsByHeaderValue_('Intake Submissions',
      'Submission ID', normalized.submissionId);
    if (existingRows.length) {
      var existing = getObjectRow_('Intake Submissions', existingRows[0]);
      if (normalizeEmail_(existing.record['Email Address']) !== normalized.email) {
        throw avodahError_('INVALID_SUBMISSION',
          'The submission could not be accepted.');
      }
      var replay = processIntakeSubmissionByRow_(existingRows[0],
        'PUBLIC_PORTAL_RETRY');
      replay.submissionId = normalized.submissionId;
      return publicIntakeResult_(replay, existingRows[0], normalized.email, true);
    }
    assertPublicRateLimit_('INTAKE', normalized.email, 5, 3600);
    var rowNumber = appendObjectRow_('Intake Submissions', {
      'Submission ID': normalized.submissionId,
      'Submitted At': new Date(),
      'Primary Need': normalized.primaryNeed,
      'Recommended Service Path': '',
      'Consultation Requested': normalized.consultationRequested ? 'Yes' : 'No',
      'Full Name': normalized.fullName,
      'Mobile Number': normalized.rawPhone,
      'Email Address': normalized.email,
      'Location': normalized.location,
      'Preferred Contact Method': normalized.preferredContactMethod,
      'Preferred Schedule': normalized.preferredSchedule,
      'Additional Notes': normalized.additionalNotes,
      'Consent': 'Yes',
      'Follow-up Status': 'New',
      'Submission Metadata': safeJsonStringify_({
        portalVersion: AVODAH_CONFIG.VERSION,
        receivedAt: new Date().toISOString()
      }),
      'Form Source': 'PUBLIC_PORTAL',
      'Source Page': 'PUBLIC_PORTAL',
      'Processing Status': 'PENDING'
    });
    var promotion = processIntakeSubmissionByRow_(rowNumber, 'PUBLIC_PORTAL');
    promotion.submissionId = normalized.submissionId;
    return publicIntakeResult_(promotion, rowNumber, normalized.email, false);
  }, 30000);
}

function getPublicBookingAvailability() {
  assertPublicBookingEnabled_();
  return getBookingAvailability_();
}

function createPublicConsultationBooking(payload) {
  assertPublicBookingEnabled_();
  var input = payload || {};
  var claims = verifyPublicWorkflowToken_(input.workflow_token || input.workflowToken);
  var start = publicPortalText_(input.start, 80);
  var idempotencyKey = publicPortalText_(
    input.idempotency_key || input.idempotencyKey, 200);
  return createConsultationBooking_({
    intake_id: claims.intake_id,
    lead_id: claims.lead_id,
    start: start,
    idempotency_key: idempotencyKey
  }, {source: 'PUBLIC_PORTAL'});
}

function publicManagementToken_(payload) {
  var token = publicPortalText_((payload || {}).management_token ||
    (payload || {}).managementToken || (payload || {}).token, 256);
  if (!token) {
    throw avodahError_('MANAGEMENT_TOKEN_REQUIRED',
      'A booking management link is required.');
  }
  return token;
}

function getPublicManagedBooking(payload) {
  assertPublicPortalEnabled_();
  var token = publicManagementToken_(payload);
  var config = getBookingRuntimeConfig_();
  var item = resolveManagedBookingV4_({management_token: token}, config);
  if (!item) {
    return {ok: false, code: 'BOOKING_NOT_FOUND',
      message: 'The booking could not be found.', retryable: false};
  }
  return bookingResultFromObject_(item, 'BOOKING_FOUND');
}

function reschedulePublicConsultationBooking(payload) {
  assertPublicBookingEnabled_();
  var token = publicManagementToken_(payload);
  return rescheduleConsultationBooking_({
    management_token: token,
    start: publicPortalText_((payload || {}).start, 80)
  }, {source: 'PUBLIC_PORTAL_MANAGEMENT'});
}

function cancelPublicConsultationBooking(payload) {
  assertPublicBookingEnabled_();
  var token = publicManagementToken_(payload);
  return cancelConsultationBooking_({
    management_token: token,
    reason: publicPortalText_((payload || {}).reason, 500)
  }, {source: 'PUBLIC_PORTAL_MANAGEMENT'});
}
