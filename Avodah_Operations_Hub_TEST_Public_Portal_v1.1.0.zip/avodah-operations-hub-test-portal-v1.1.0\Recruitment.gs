/** Recruitment pipeline, interviews, requirements, and onboarding. */

var RECRUITMENT_SCORE_HEADERS = Object.freeze([
  ['communication_score', 'Communication Score'],
  ['customer_service_score', 'Customer Service Score'],
  ['selling_background_score', 'Selling Background Score'],
  ['quota_experience_score', 'Quota Experience Score'],
  ['handling_objections_score', 'Handling Objections Score'],
  ['appointment_strategy_score', 'Appointment Strategy Score']
]);

function recruitmentSettingValues_(groupName) {
  return settingValues_(groupName);
}

function recruitmentPropertyEnabled_(name) {
  return truthy_(PropertiesService.getScriptProperties().getProperty(name));
}

function assertRecruitmentWritesEnabled_() {
  if (getEnvironment_() !== 'TEST') {
    throw avodahError_('TEST_ONLY',
      'This recruitment package is restricted to the copied TEST environment.');
  }
  if (!recruitmentPropertyEnabled_('ENABLE_RECRUITMENT_WRITES')) {
    throw avodahError_('RECRUITMENT_WRITES_DISABLED',
      'Set ENABLE_RECRUITMENT_WRITES=TRUE only for an approved TEST run.');
  }
}

function recruitmentActor_() {
  return requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
}

function getRecruitmentFormDefinition() {
  var user = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  return {
    version: AVODAH_CONFIG.VERSION,
    userRole: user.role,
    writeEnabled: getEnvironment_() === 'TEST' &&
      recruitmentPropertyEnabled_('ENABLE_RECRUITMENT_WRITES'),
    calendarWriteEnabled: recruitmentPropertyEnabled_('ENABLE_CALENDAR_WRITES'),
    stages: recruitmentSettingValues_('RECRUITMENT_STAGE'),
    statuses: recruitmentSettingValues_('RECRUITMENT_STATUS'),
    interviewTypes: recruitmentSettingValues_('INTERVIEW_TYPE'),
    interviewStatuses: recruitmentSettingValues_('INTERVIEW_STATUS'),
    interviewResults: recruitmentSettingValues_('INTERVIEW_RESULT'),
    requirementStatuses: recruitmentSettingValues_('REQUIREMENT_STATUS'),
    onboardingStatuses: recruitmentSettingValues_('ONBOARDING_STATUS')
  };
}

function recruitmentFirstBy_(logicalSheetName, headerName, value) {
  var rows = findRowsByHeaderValue_(logicalSheetName, headerName, value);
  return rows.length ? getObjectRow_(logicalSheetName, rows[0]) : null;
}

function recruitmentRequireApplicant_(applicantId) {
  var id = String(applicantId || '').trim();
  if (!id) throw avodahError_('APPLICANT_ID_REQUIRED', 'Applicant ID is required.');
  var applicant = recruitmentFirstBy_('Applicant Tracking', 'Applicant ID', id);
  if (!applicant || String(applicant.record['Record Status'] || '').toUpperCase() === 'VOID') {
    throw avodahError_('APPLICANT_NOT_FOUND', 'No active applicant matches that ID.');
  }
  return applicant;
}

function validateRecruitmentStageStatus_(stage, status) {
  var stageValue = String(stage || '').trim();
  var statusValue = String(status || '').trim();
  var stages = recruitmentSettingValues_('RECRUITMENT_STAGE');
  var statuses = recruitmentSettingValues_('RECRUITMENT_STATUS');
  if (stageValue === 'No Show') {
    throw avodahError_('NO_SHOW_IS_STATUS',
      'No Show is a status and cannot be used as a pipeline stage.');
  }
  if (stages.indexOf(stageValue) === -1) {
    throw avodahError_('INVALID_RECRUITMENT_STAGE',
      'Stage must be one of the controlled recruitment stages.');
  }
  if (statuses.indexOf(statusValue) === -1) {
    throw avodahError_('INVALID_RECRUITMENT_STATUS',
      'Status must be one of the controlled recruitment statuses.');
  }
  return {stage: stageValue, status: statusValue};
}

function appendApplicantTimeline_(details) {
  return appendObjectRow_('Applicant Timeline', {
    'Timeline ID': generateUniqueId_('TIMELINE'),
    'Applicant ID': details.applicantId,
    'Occurred At': new Date(),
    'Previous Stage': details.previousStage || '',
    'New Stage': details.newStage || '',
    'Previous Status': details.previousStatus || '',
    'New Status': details.newStatus || '',
    'Reason': details.reason || '',
    'Notes': details.notes || '',
    'Changed By': details.changedBy || getCurrentUserEmail_()
  });
}

function updateApplicantStateCore_(applicant, nextStage, nextStatus, details) {
  var validated = validateRecruitmentStageStatus_(nextStage, nextStatus);
  var previousStage = String(applicant.record['Current Stage'] || '');
  var previousStatus = String(applicant.record['Current Status'] || '');
  var changed = previousStage !== validated.stage || previousStatus !== validated.status;
  if (!changed && !(details && details.allowUnchanged)) {
    throw avodahError_('NO_PIPELINE_CHANGE',
      'The applicant is already in the requested stage and status.');
  }
  var updates = {
    'Current Stage': validated.stage,
    'Current Status': validated.status,
    'Updated At': new Date()
  };
  Object.keys(details && details.updates || {}).forEach(function(header) {
    updates[header] = details.updates[header];
  });
  updateObjectRow_('Applicant Tracking', applicant.rowNumber, updates);
  if (changed) {
    appendApplicantTimeline_({
      applicantId: applicant.record['Applicant ID'],
      previousStage: previousStage,
      newStage: validated.stage,
      previousStatus: previousStatus,
      newStatus: validated.status,
      reason: details && details.reason,
      notes: details && details.notes,
      changedBy: details && details.changedBy
    });
  }
  applicant.record['Current Stage'] = validated.stage;
  applicant.record['Current Status'] = validated.status;
  Object.keys(updates).forEach(function(header) { applicant.record[header] = updates[header]; });
  return {changed: changed, stage: validated.stage, status: validated.status};
}

function recruitmentDuplicateApplicant_(normalizedEmail, normalizedPhone) {
  var rows = getObjectRows_('Applicant Tracking');
  for (var i = 0; i < rows.length; i += 1) {
    var record = rows[i].record;
    if (String(record['Record Status'] || 'ACTIVE').toUpperCase() === 'VOID') continue;
    if (normalizedEmail && normalizeEmail_(record['Normalized Email']) === normalizedEmail) {
      return rows[i];
    }
    if (normalizedPhone && String(record['Normalized Phone'] || '') === normalizedPhone) {
      return rows[i];
    }
  }
  return null;
}

function validateRecruitmentApplicantPayload_(payload) {
  var data = payload || {};
  var name = String(data.applicant_name || '').trim();
  var email = normalizeEmail_(data.email);
  var phone = normalizePhone_(data.phone);
  if (!name) throw avodahError_('APPLICANT_NAME_REQUIRED', 'Applicant name is required.');
  if (!isValidEmail_(email)) {
    throw avodahError_('INVALID_EMAIL', 'A valid applicant email is required.');
  }
  if (data.phone && !isValidPhone_(phone)) {
    throw avodahError_('INVALID_PHONE', 'Applicant phone must be a valid mobile number.');
  }
  return {
    name: name,
    email: email,
    phone: phone,
    applicationDate: data.application_date ?
      parseRequiredDate_(data.application_date, 'Application date') : new Date()
  };
}

function createRecruitmentApplicant(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('create recruitment applicant', function() {
    var clean = validateRecruitmentApplicantPayload_(payload);
    var duplicate = recruitmentDuplicateApplicant_(clean.email, clean.phone);
    if (duplicate) {
      return {ok: true, code: 'APPLICANT_ALREADY_EXISTS',
        applicant_id: duplicate.record['Applicant ID'], duplicate: true};
    }
    var applicantId = generateUniqueId_('APPLICANT');
    var now = new Date();
    var row = appendObjectRow_('Applicant Tracking', {
      'Applicant ID': applicantId,
      'Applicant Name': clean.name,
      'Email': clean.email,
      'Normalized Email': clean.email,
      'Phone': clean.phone,
      'Normalized Phone': clean.phone,
      'Location': String(payload.location || '').trim(),
      'Application Date': clean.applicationDate,
      'Source': String(payload.source || '').trim(),
      'Resume File / Link': String(payload.resume_url || '').trim(),
      'Current Stage': 'Screening',
      'Current Status': 'New',
      'Screening Status': 'Not Started',
      'Assigned Recruiter': String(payload.assigned_recruiter || actor.email).trim(),
      'Recruiter Notes': String(payload.notes || '').trim(),
      'Record Status': 'ACTIVE',
      'Created At': now,
      'Updated At': now
    });
    appendApplicantTimeline_({applicantId: applicantId, newStage: 'Screening',
      newStatus: 'New', reason: 'Applicant created', notes: payload.notes,
      changedBy: actor.email});
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'APPLICANT_CREATED', entityType: 'APPLICANT', entityId: applicantId,
      requestId: String(payload.request_id || ''), details: {row: row}});
    return {ok: true, code: 'APPLICANT_CREATED', applicant_id: applicantId,
      stage: 'Screening', status: 'New', duplicate: false};
  });
}

function transitionRecruitmentApplicant(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('transition recruitment applicant', function() {
    var applicant = recruitmentRequireApplicant_(payload && payload.applicant_id);
    var result = updateApplicantStateCore_(applicant, payload.stage, payload.status, {
      reason: String(payload.reason || 'Pipeline update'),
      notes: String(payload.notes || ''), changedBy: actor.email
    });
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'APPLICANT_PIPELINE_UPDATED', entityType: 'APPLICANT',
      entityId: applicant.record['Applicant ID'], requestId: String(payload.request_id || ''),
      details: {stage: result.stage, status: result.status}});
    return {ok: true, code: 'APPLICANT_PIPELINE_UPDATED',
      applicant_id: applicant.record['Applicant ID'], stage: result.stage,
      status: result.status};
  });
}

function recruitmentCalendarConfig_() {
  var config = getBookingRuntimeConfig_();
  if (config.environment !== 'TEST') {
    throw avodahError_('TEST_ONLY', 'Interview scheduling is restricted to TEST.');
  }
  return config;
}

function assertRecruitmentCalendarWritesEnabled_() {
  assertRecruitmentWritesEnabled_();
  assertCalendarWritesEnabled_();
}

function inspectRecruitmentCalendarWindow_(timeMin, timeMax) {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var config = recruitmentCalendarConfig_();
  var start = parseRequiredDate_(timeMin, 'Window start');
  var end = parseRequiredDate_(timeMax, 'Window end');
  if (end.getTime() <= start.getTime() || end.getTime() - start.getTime() > 31 * 86400000) {
    throw avodahError_('INVALID_CALENDAR_WINDOW',
      'Calendar inspection must be a positive window of no more than 31 days.');
  }
  var busy = getBookingBusyIntervals_(config, start, end);
  return {ok: true, environment: config.environment, timezone: config.timezone,
    window_start: start.toISOString(), window_end: end.toISOString(),
    busy_interval_count: busy.length};
}

function runRecruitmentCalendarReadinessCheck() {
  var start = new Date();
  var end = new Date(start.getTime() + 14 * 86400000);
  var response = inspectRecruitmentCalendarWindow_(start, end);
  response.write_gate_enabled = recruitmentPropertyEnabled_('ENABLE_CALENDAR_WRITES');
  console.log(JSON.stringify(response));
  return response;
}

function runRecruitmentCalendarCleanupCheck() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var config = recruitmentCalendarConfig_();
  var rows = getObjectRows_('Interview Records').filter(function(item) {
    return Boolean(item.record['Calendar Event ID']);
  });
  var result = {checked: rows.length, active: 0, cancelled: 0, missing: 0,
    recruitment_write_gate_enabled:
      recruitmentPropertyEnabled_('ENABLE_RECRUITMENT_WRITES'),
    calendar_write_gate_enabled:
      recruitmentPropertyEnabled_('ENABLE_CALENDAR_WRITES')};
  rows.forEach(function(item) {
    var event = readBookingCalendarEvent_(config, item.record['Calendar Event ID']);
    if (!event) result.missing += 1;
    else if (event.status === 'cancelled') result.cancelled += 1;
    else result.active += 1;
  });
  result.ok = result.active === 0;
  console.log(JSON.stringify(result));
  return result;
}

function recruitmentInterviewDuplicate_(applicantId, interviewType, start) {
  var rows = getObjectRows_('Interview Records');
  for (var i = 0; i < rows.length; i += 1) {
    var record = rows[i].record;
    var storedStart = record['Scheduled Start'] instanceof Date ?
      record['Scheduled Start'] : new Date(record['Scheduled Start']);
    if (String(record['Applicant ID']) === applicantId &&
        String(record['Interview Type']) === interviewType &&
        !isNaN(storedStart.getTime()) && storedStart.getTime() === start.getTime() &&
        String(record['Interview Status']) !== 'Cancelled') return rows[i];
  }
  return null;
}

function createRecruitmentCalendarEvent_(config, details) {
  assertRecruitmentCalendarWritesEnabled_();
  var event = {
    summary: '[TEST] Avodah ' + details.interviewType + ' - ' + details.applicantName,
    description: ['Avodah Operations Hub recruitment interview.',
      'Applicant ID: ' + details.applicantId,
      'Interview ID: ' + details.interviewId].join('\n'),
    location: 'Google Meet', visibility: 'private', transparency: 'opaque',
    guestsCanModify: false, guestsCanInviteOthers: false,
    guestsCanSeeOtherGuests: false,
    start: {dateTime: details.start.toISOString(), timeZone: config.timezone},
    end: {dateTime: details.end.toISOString(), timeZone: config.timezone},
    attendees: [],
    conferenceData: {createRequest: {
      requestId: ('avodahrecruitment' + details.interviewId + Utilities.getUuid())
        .toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 120),
      conferenceSolutionKey: {type: 'hangoutsMeet'}
    }},
    extendedProperties: {private: {
      source: 'avodah-operations-hub-recruitment',
      sourceVersion: AVODAH_CONFIG.VERSION,
      environment: config.environment,
      calendarBinding: config.calendarBinding,
      applicantId: details.applicantId,
      interviewId: details.interviewId
    }},
    reminders: {useDefault: false, overrides: [{method: 'popup', minutes: 30}]}
  };
  var created = Calendar.Events.insert(event, config.calendarId,
    {conferenceDataVersion: 1, sendUpdates: 'none'});
  for (var attempt = 0; attempt < 4 && !bookingEventMeetLink_(created); attempt += 1) {
    Utilities.sleep(400 + attempt * 200);
    created = Calendar.Events.get(config.calendarId, created.id);
  }
  return created;
}

function deleteRecruitmentCalendarEvent_(config, eventId) {
  if (!eventId) return {ok: true, deleted: false};
  assertRecruitmentCalendarWritesEnabled_();
  try {
    Calendar.Events.remove(config.calendarId, eventId, {sendUpdates: 'none'});
    return {ok: true, deleted: true};
  } catch (error) {
    var message = String(error && error.message ? error.message : error);
    if (/\b(404|410)\b|not found|gone/i.test(message)) {
      return {ok: true, deleted: false, alreadyMissing: true};
    }
    return {ok: false, deleted: false, error: message};
  }
}

function scheduleRecruitmentInterview(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentCalendarWritesEnabled_();
  return withScriptLock_('schedule recruitment interview', function() {
    var applicant = recruitmentRequireApplicant_(payload && payload.applicant_id);
    var interviewType = String(payload.interview_type || '').trim();
    if (recruitmentSettingValues_('INTERVIEW_TYPE').indexOf(interviewType) === -1) {
      throw avodahError_('INVALID_INTERVIEW_TYPE',
        'Interview type must be Initial Interview or Final Interview.');
    }
    var start = parseRequiredDate_(payload.start, 'Interview start');
    var end = payload.end ? parseRequiredDate_(payload.end, 'Interview end') :
      new Date(start.getTime() + 30 * 60000);
    if (end.getTime() <= start.getTime() || end.getTime() - start.getTime() > 4 * 3600000) {
      throw avodahError_('INVALID_INTERVIEW_WINDOW',
        'Interview end must be after start and within four hours.');
    }
    var duplicate = recruitmentInterviewDuplicate_(
      applicant.record['Applicant ID'], interviewType, start);
    if (duplicate) {
      return {ok: true, code: 'INTERVIEW_ALREADY_SCHEDULED',
        interview_id: duplicate.record['Interview ID'], duplicate: true};
    }
    var config = recruitmentCalendarConfig_();
    if (bookingCalendarConflictExists_(config, start, end, '')) {
      throw avodahError_('INTERVIEW_SLOT_BUSY',
        'The TEST calendar is already busy during that interview time.');
    }
    var interviewId = generateUniqueId_('INTERVIEW');
    var event = null;
    var interviewRow = null;
    try {
      event = createRecruitmentCalendarEvent_(config, {
        interviewId: interviewId,
        applicantId: applicant.record['Applicant ID'],
        applicantName: applicant.record['Applicant Name'],
        interviewType: interviewType, start: start, end: end
      });
      interviewRow = appendObjectRow_('Interview Records', {
        'Interview ID': interviewId,
        'Applicant ID': applicant.record['Applicant ID'],
        'Interview Type': interviewType,
        'Scheduled Start': start,
        'Scheduled End': end,
        'Interviewer': String(payload.interviewer || actor.email).trim(),
        'Calendar Event ID': event.id,
        'Meet Link': bookingEventMeetLink_(event),
        'Interview Status': 'Scheduled',
        'Created At': new Date(), 'Updated At': new Date()
      });
      var targetStage = interviewType === 'Initial Interview' ?
        'Initial Interview' : 'Final Interview';
      var dateHeader = interviewType === 'Initial Interview' ?
        'Initial Interview Date' : 'Final Interview Date';
      var state = updateApplicantStateCore_(applicant, targetStage, 'Scheduled', {
        reason: interviewType + ' scheduled', notes: payload.notes,
        changedBy: actor.email, allowUnchanged: true,
        updates: {'Interview Status': 'Scheduled', [dateHeader]: start}
      });
      logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
        action: 'INTERVIEW_SCHEDULED', entityType: 'INTERVIEW', entityId: interviewId,
        requestId: String(payload.request_id || ''), details: {
          applicantId: applicant.record['Applicant ID'], interviewType: interviewType,
          stage: state.stage, hasMeet: Boolean(bookingEventMeetLink_(event))
        }});
      return {ok: true, code: 'INTERVIEW_SCHEDULED', interview_id: interviewId,
        applicant_id: applicant.record['Applicant ID'], stage: state.stage,
        status: state.status, event_id: event.id,
        meet_link: bookingEventMeetLink_(event), duplicate: false};
    } catch (error) {
      if (interviewRow) {
        try { updateObjectRow_('Interview Records', interviewRow,
          {'Interview Status': 'Cancelled', 'Updated At': new Date()}); } catch (ignored) {}
      }
      if (event && event.id) deleteRecruitmentCalendarEvent_(config, event.id);
      throw error;
    }
  });
}

function recruitmentScoreValues_(payload, required) {
  var values = [];
  var record = {};
  RECRUITMENT_SCORE_HEADERS.forEach(function(pair) {
    var raw = payload[pair[0]];
    if ((raw == null || raw === '') && !required) {
      record[pair[1]] = '';
      return;
    }
    var score = Number(raw);
    if (!isFinite(score) || score < 1 || score > 5) {
      throw avodahError_('INVALID_INTERVIEW_SCORE',
        pair[1] + ' must be a number from 1 to 5.');
    }
    values.push(score);
    record[pair[1]] = score;
  });
  record['Overall Score'] = values.length ?
    Math.round(values.reduce(function(sum, score) { return sum + score; }, 0) /
      values.length * 100) / 100 : '';
  return record;
}

function validateInterviewProgression_(interviewType, currentStage, nextStage) {
  var allowed = interviewType === 'Initial Interview' ?
    ['Initial Interview', 'Final Interview', 'Closed'] :
    ['Final Interview', 'Requirements', 'Closed'];
  if (allowed.indexOf(nextStage) === -1) {
    throw avodahError_('INVALID_INTERVIEW_PROGRESSION',
      'The selected next stage is not valid for this interview type.');
  }
  if (currentStage === 'Closed' && nextStage !== 'Closed') {
    throw avodahError_('APPLICANT_CLOSED', 'A closed applicant cannot be reopened implicitly.');
  }
}

function recordRecruitmentInterviewResult(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('record recruitment interview result', function() {
    var interview = recruitmentFirstBy_('Interview Records', 'Interview ID',
      payload && payload.interview_id);
    if (!interview) throw avodahError_('INTERVIEW_NOT_FOUND', 'Interview record not found.');
    var applicant = recruitmentRequireApplicant_(interview.record['Applicant ID']);
    var status = String(payload.interview_status || '').trim();
    if (recruitmentSettingValues_('INTERVIEW_STATUS').indexOf(status) === -1) {
      throw avodahError_('INVALID_INTERVIEW_STATUS',
        'Interview status must be one of the controlled interview statuses.');
    }
    var isNoShow = status === 'No Show';
    if (status !== 'Completed' && !isNoShow) {
      throw avodahError_('INTERVIEW_RESULT_STATUS_REQUIRED',
        'Results can only be recorded as Completed or No Show.');
    }
    var result = String(payload.interview_result || '').trim();
    var nextStage = isNoShow ? applicant.record['Current Stage'] :
      String(payload.next_stage || '').trim();
    var nextStatus = isNoShow ? 'No Show' : String(payload.next_status || '').trim();
    if (!isNoShow) {
      if (recruitmentSettingValues_('INTERVIEW_RESULT').indexOf(result) === -1) {
        throw avodahError_('INVALID_INTERVIEW_RESULT',
          'Completed interviews require a controlled interview result.');
      }
      validateInterviewProgression_(interview.record['Interview Type'],
        applicant.record['Current Stage'], nextStage);
    }
    validateRecruitmentStageStatus_(nextStage, nextStatus);
    var scores = recruitmentScoreValues_(payload, !isNoShow);
    var interviewUpdates = {
      'Interview Status': status,
      'Interview Result': isNoShow ? '' : result,
      'Interview Notes': String(payload.notes || ''),
      'Updated At': new Date()
    };
    Object.keys(scores).forEach(function(header) { interviewUpdates[header] = scores[header]; });
    updateObjectRow_('Interview Records', interview.rowNumber, interviewUpdates);
    var applicantUpdates = {'Interview Status': status};
    if (interview.record['Interview Type'] === 'Final Interview' && !isNoShow) {
      applicantUpdates['Final Decision'] = result;
    }
    var state = updateApplicantStateCore_(applicant, nextStage, nextStatus, {
      reason: interview.record['Interview Type'] + ' result: ' + status,
      notes: payload.notes, changedBy: actor.email, allowUnchanged: isNoShow,
      updates: applicantUpdates
    });
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: isNoShow ? 'INTERVIEW_NO_SHOW_RECORDED' : 'INTERVIEW_RESULT_RECORDED',
      entityType: 'INTERVIEW', entityId: interview.record['Interview ID'],
      requestId: String(payload.request_id || ''), details: {
        applicantId: applicant.record['Applicant ID'], interviewStatus: status,
        result: isNoShow ? '' : result, stage: state.stage, status: state.status
      }});
    return {ok: true, code: isNoShow ? 'INTERVIEW_NO_SHOW_RECORDED' :
      'INTERVIEW_RESULT_RECORDED', interview_id: interview.record['Interview ID'],
      applicant_id: applicant.record['Applicant ID'], stage: state.stage,
      status: state.status, overall_score: scores['Overall Score']};
  });
}

function recruitmentCompositeRow_(logicalSheet, applicantId, keyHeader, keyValue) {
  var rows = getObjectRows_(logicalSheet);
  for (var i = 0; i < rows.length; i += 1) {
    if (String(rows[i].record['Applicant ID']) === applicantId &&
        String(rows[i].record[keyHeader]) === keyValue) return rows[i];
  }
  return null;
}

function recruitmentRequirementSummary_(applicantId) {
  var rows = getObjectRows_('Requirements Tracker').filter(function(item) {
    return String(item.record['Applicant ID']) === applicantId;
  });
  if (!rows.length) return 'Not Started';
  var statuses = rows.map(function(item) { return String(item.record.Status || ''); });
  if (statuses.some(function(status) { return status === 'Rejected'; })) return 'Needs Attention';
  if (statuses.every(function(status) { return status === 'Verified'; })) return 'Complete';
  if (statuses.some(function(status) { return status === 'Submitted' || status === 'Verified'; })) {
    return 'In Progress';
  }
  return 'Not Started';
}

function upsertApplicantRequirement(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('upsert applicant requirement', function() {
    var applicant = recruitmentRequireApplicant_(payload && payload.applicant_id);
    var key = String(payload.requirement_key || '').trim().toUpperCase()
      .replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    var name = String(payload.requirement_name || '').trim();
    var status = String(payload.status || '').trim();
    if (!key || !name) throw avodahError_('REQUIREMENT_FIELDS_REQUIRED',
      'Requirement key and name are required.');
    if (recruitmentSettingValues_('REQUIREMENT_STATUS').indexOf(status) === -1) {
      throw avodahError_('INVALID_REQUIREMENT_STATUS',
        'Requirement status must use the controlled status list.');
    }
    var existing = recruitmentCompositeRow_('Requirements Tracker',
      applicant.record['Applicant ID'], 'Requirement Key', key);
    var now = new Date();
    var record = {
      'Applicant ID': applicant.record['Applicant ID'], 'Requirement Key': key,
      'Requirement Name': name, 'Status': status,
      'Submitted At': status === 'Submitted' || status === 'Verified' ?
        (existing && existing.record['Submitted At'] || now) : '',
      'Verified At': status === 'Verified' ? now : '',
      'Verified By': status === 'Verified' ? actor.email : '',
      'File / Link': String(payload.file_url || ''),
      'Notes': String(payload.notes || ''), 'Updated At': now
    };
    if (existing) updateObjectRow_('Requirements Tracker', existing.rowNumber, record);
    else appendObjectRow_('Requirements Tracker', record);
    var summary = recruitmentRequirementSummary_(applicant.record['Applicant ID']);
    updateObjectRow_('Applicant Tracking', applicant.rowNumber,
      {'Requirements Status': summary, 'Updated At': now});
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'APPLICANT_REQUIREMENT_UPSERTED', entityType: 'APPLICANT_REQUIREMENT',
      entityId: applicant.record['Applicant ID'] + '|' + key,
      requestId: String(payload.request_id || ''),
      details: {status: status, summary: summary}});
    return {ok: true, code: existing ? 'REQUIREMENT_UPDATED' : 'REQUIREMENT_CREATED',
      applicant_id: applicant.record['Applicant ID'], requirement_key: key,
      status: status, requirements_summary: summary};
  });
}

function recruitmentOnboardingSummary_(applicantId) {
  var rows = getObjectRows_('Onboarding Tracker').filter(function(item) {
    return String(item.record['Applicant ID']) === applicantId;
  });
  if (!rows.length) return 'Not Started';
  var statuses = rows.map(function(item) { return String(item.record.Status || ''); });
  if (statuses.some(function(status) { return status === 'Blocked'; })) return 'Blocked';
  if (statuses.every(function(status) { return status === 'Completed'; })) return 'Complete';
  if (statuses.some(function(status) { return status === 'In Progress' ||
      status === 'Completed'; })) return 'In Progress';
  return 'Not Started';
}

function upsertApplicantOnboardingStep(payload) {
  var actor = recruitmentActor_();
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('upsert applicant onboarding step', function() {
    var applicant = recruitmentRequireApplicant_(payload && payload.applicant_id);
    var key = String(payload.step_key || '').trim().toUpperCase()
      .replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    var name = String(payload.step_name || '').trim();
    var status = String(payload.status || '').trim();
    if (!key || !name) throw avodahError_('ONBOARDING_FIELDS_REQUIRED',
      'Onboarding step key and name are required.');
    if (recruitmentSettingValues_('ONBOARDING_STATUS').indexOf(status) === -1) {
      throw avodahError_('INVALID_ONBOARDING_STATUS',
        'Onboarding status must use the controlled status list.');
    }
    var existing = recruitmentCompositeRow_('Onboarding Tracker',
      applicant.record['Applicant ID'], 'Step Key', key);
    var now = new Date();
    var record = {
      'Applicant ID': applicant.record['Applicant ID'], 'Step Key': key,
      'Step Name': name, 'Status': status,
      'Due Date': payload.due_date ? parseRequiredDate_(payload.due_date, 'Due date') : '',
      'Completed At': status === 'Completed' ? now : '',
      'Completed By': status === 'Completed' ? actor.email : '',
      'Evidence / Link': String(payload.evidence_url || ''),
      'Notes': String(payload.notes || ''), 'Updated At': now
    };
    if (existing) updateObjectRow_('Onboarding Tracker', existing.rowNumber, record);
    else appendObjectRow_('Onboarding Tracker', record);
    var summary = recruitmentOnboardingSummary_(applicant.record['Applicant ID']);
    updateObjectRow_('Applicant Tracking', applicant.rowNumber,
      {'Onboarding Status': summary, 'Updated At': now});
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'APPLICANT_ONBOARDING_UPSERTED', entityType: 'APPLICANT_ONBOARDING',
      entityId: applicant.record['Applicant ID'] + '|' + key,
      requestId: String(payload.request_id || ''),
      details: {status: status, summary: summary}});
    return {ok: true, code: existing ? 'ONBOARDING_UPDATED' : 'ONBOARDING_CREATED',
      applicant_id: applicant.record['Applicant ID'], step_key: key,
      status: status, onboarding_summary: summary};
  });
}

function listRecruitmentApplicants(limit) {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var maxRows = Math.max(1, Math.min(Number(limit || 100), 200));
  return getObjectRows_('Applicant Tracking').filter(function(item) {
    return String(item.record['Record Status'] || 'ACTIVE').toUpperCase() !== 'VOID';
  }).slice(-maxRows).reverse().map(function(item) {
    return {
      applicant_id: item.record['Applicant ID'],
      applicant_name: item.record['Applicant Name'],
      stage: item.record['Current Stage'], status: item.record['Current Status'],
      interview_status: item.record['Interview Status'],
      requirements_status: item.record['Requirements Status'],
      onboarding_status: item.record['Onboarding Status'],
      assigned_recruiter: item.record['Assigned Recruiter']
    };
  });
}

function repairRecruitmentPhoneStorage() {
  var actor = requireUserRole_(['ADMIN']);
  assertRecruitmentWritesEnabled_();
  return withScriptLock_('repair recruitment phone storage', function() {
    var rows = getObjectRows_('Applicant Tracking');
    var repaired = 0;
    rows.forEach(function(item) {
      var phone = normalizePhone_(item.record.Phone || item.record['Normalized Phone']);
      if (!phone || !isValidPhone_(phone)) return;
      updateObjectRow_('Applicant Tracking', item.rowNumber,
        {'Phone': phone, 'Normalized Phone': phone, 'Updated At': new Date()});
      repaired += 1;
    });
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'RECRUITMENT_PHONE_STORAGE_REPAIRED',
      entityType: 'APPLICANT', entityId: 'BATCH', details: {rowsRepaired: repaired}});
    var response = {ok: true, rows_repaired: repaired};
    console.log(JSON.stringify(response));
    return response;
  });
}

function runRecruitmentValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  requireUserRole_(['ADMIN', 'MANAGER']);
  var results = [];
  testAssert_(results, 'Screening/New stage and status accepted',
    validateRecruitmentStageStatus_('Screening', 'New').status === 'New');
  testAssert_(results, 'No Show rejected as a stage',
    testErrorCode_(function() { validateRecruitmentStageStatus_('No Show', 'No Show'); }) ===
      'NO_SHOW_IS_STATUS');
  testAssert_(results, 'Invalid score rejected',
    testErrorCode_(function() { recruitmentScoreValues_({
      communication_score: 6, customer_service_score: 5,
      selling_background_score: 5, quota_experience_score: 5,
      handling_objections_score: 5, appointment_strategy_score: 5
    }, true); }) === 'INVALID_INTERVIEW_SCORE');
  var average = recruitmentScoreValues_({
    communication_score: 5, customer_service_score: 4,
    selling_background_score: 3, quota_experience_score: 2,
    handling_objections_score: 1, appointment_strategy_score: 3
  }, true)['Overall Score'];
  testAssert_(results, 'Six interview scores average correctly', average === 3);
  testAssert_(results, 'Phone values are stored as text, not formulas',
    safeCellValue_('+639171234567', 'Normalized Phone').charAt(0) === "'");
  testAssert_(results, 'Initial interview progression accepts Final Interview',
    !testErrorCode_(function() {
      validateInterviewProgression_('Initial Interview', 'Initial Interview', 'Final Interview');
    }));
  testAssert_(results, 'Final interview cannot regress to Screening',
    testErrorCode_(function() {
      validateInterviewProgression_('Final Interview', 'Final Interview', 'Screening');
    }) === 'INVALID_INTERVIEW_PROGRESSION');
  var failures = results.filter(function(test) { return !test.passed; });
  var response = {passed: failures.length === 0, tests: results, failures: failures};
  console.log(JSON.stringify(response));
  return response;
}

function recruitmentTestScores_() {
  return {communication_score: 5, customer_service_score: 4,
    selling_background_score: 4, quota_experience_score: 3,
    handling_objections_score: 4, appointment_strategy_score: 5};
}

function runRecruitmentLifecycleIntegrationTest() {
  var actor = requireUserRole_(['ADMIN']);
  assertRecruitmentCalendarWritesEnabled_();
  var results = [];
  var createdEvents = [];
  var applicantId = '';
  try {
    var availability = getBookingAvailability_();
    var slots = [];
    availability.days.forEach(function(day) {
      day.slots.forEach(function(slot) {
        if (slots.length < 3) slots.push(slot);
      });
    });
    if (slots.length < 3) throw avodahError_('TEST_SLOTS_UNAVAILABLE',
      'At least three free TEST calendar slots are required.');
    var label = Utilities.formatDate(new Date(), AVODAH_CONFIG.TIME_ZONE,
      'yyyyMMddHHmmss') + Utilities.getUuid().substring(0, 6);
    var applicant = createRecruitmentApplicant({
      applicant_name: 'TEST Recruitment ' + label,
      email: 'recruitment+' + label.toLowerCase() + '@example.test',
      phone: '+639' + String(Date.now()).slice(-9), location: 'TEST',
      source: 'INTEGRATION_TEST', assigned_recruiter: actor.email,
      notes: 'Automated TEST recruitment lifecycle'
    });
    applicantId = applicant.applicant_id;
    testAssert_(results, 'Applicant starts in Screening/New',
      applicant.stage === 'Screening' && applicant.status === 'New');

    var initialNoShow = scheduleRecruitmentInterview({applicant_id: applicantId,
      interview_type: 'Initial Interview', start: slots[0].start,
      end: slots[0].end, interviewer: actor.email});
    createdEvents.push(initialNoShow.event_id);
    var noShow = recordRecruitmentInterviewResult({
      interview_id: initialNoShow.interview_id, interview_status: 'No Show',
      notes: 'Automated no-show status test'
    });
    testAssert_(results, 'No Show remains status and does not create a stage',
      noShow.stage === 'Initial Interview' && noShow.status === 'No Show');

    var initial = scheduleRecruitmentInterview({applicant_id: applicantId,
      interview_type: 'Initial Interview', start: slots[1].start,
      end: slots[1].end, interviewer: actor.email});
    createdEvents.push(initial.event_id);
    var initialPayload = recruitmentTestScores_();
    initialPayload.interview_id = initial.interview_id;
    initialPayload.interview_status = 'Completed';
    initialPayload.interview_result = 'Proceed';
    initialPayload.next_stage = 'Final Interview';
    initialPayload.next_status = 'Shortlisted';
    var initialResult = recordRecruitmentInterviewResult(initialPayload);
    testAssert_(results, 'Initial interview advances to Final Interview',
      initialResult.stage === 'Final Interview' && initialResult.overall_score > 0);

    var finalInterview = scheduleRecruitmentInterview({applicant_id: applicantId,
      interview_type: 'Final Interview', start: slots[2].start,
      end: slots[2].end, interviewer: actor.email});
    createdEvents.push(finalInterview.event_id);
    var event = Calendar.Events.get(recruitmentCalendarConfig_().calendarId,
      finalInterview.event_id);
    testAssert_(results, 'Interview event has Google Meet and no guest invitations',
      Boolean(bookingEventMeetLink_(event)) && !(event.attendees || []).length);
    var finalPayload = recruitmentTestScores_();
    finalPayload.interview_id = finalInterview.interview_id;
    finalPayload.interview_status = 'Completed';
    finalPayload.interview_result = 'Proceed';
    finalPayload.next_stage = 'Requirements';
    finalPayload.next_status = 'Completed';
    var finalResult = recordRecruitmentInterviewResult(finalPayload);
    testAssert_(results, 'Final interview advances to Requirements',
      finalResult.stage === 'Requirements');

    upsertApplicantRequirement({applicant_id: applicantId,
      requirement_key: 'TEST_IDENTITY', requirement_name: 'TEST identity fixture',
      status: 'Verified', notes: 'TEST only'});
    var requirements = upsertApplicantRequirement({applicant_id: applicantId,
      requirement_key: 'TEST_BACKGROUND', requirement_name: 'TEST background fixture',
      status: 'Verified', notes: 'TEST only'});
    testAssert_(results, 'Requirements summary rolls into Applicant Tracking',
      requirements.requirements_summary === 'Complete');

    transitionRecruitmentApplicant({applicant_id: applicantId, stage: 'Onboarding',
      status: 'For Review', reason: 'TEST requirements completed'});
    upsertApplicantOnboardingStep({applicant_id: applicantId,
      step_key: 'TEST_ORIENTATION', step_name: 'TEST orientation fixture',
      status: 'Completed', notes: 'TEST only'});
    var onboarding = upsertApplicantOnboardingStep({applicant_id: applicantId,
      step_key: 'TEST_ACCESS', step_name: 'TEST access fixture',
      status: 'Completed', notes: 'TEST only'});
    testAssert_(results, 'Onboarding summary rolls into Applicant Tracking',
      onboarding.onboarding_summary === 'Complete');
    var closed = transitionRecruitmentApplicant({applicant_id: applicantId,
      stage: 'Closed', status: 'Hired', reason: 'Automated TEST completion'});
    testAssert_(results, 'Pipeline closes with Hired status',
      closed.stage === 'Closed' && closed.status === 'Hired');
    var timeline = findRowsByHeaderValue_('Applicant Timeline', 'Applicant ID', applicantId);
    testAssert_(results, 'Timeline retains every pipeline movement', timeline.length >= 6);
  } finally {
    var config = recruitmentCalendarConfig_();
    createdEvents.forEach(function(eventId) {
      try { deleteRecruitmentCalendarEvent_(config, eventId); } catch (ignored) {}
    });
  }
  var configAfter = recruitmentCalendarConfig_();
  var remaining = createdEvents.filter(function(eventId) {
    var event = readBookingCalendarEvent_(configAfter, eventId);
    return event !== null && event.status !== 'cancelled';
  });
  testAssert_(results, 'All TEST interview events inactive after lifecycle test',
    remaining.length === 0);
  var failures = results.filter(function(test) { return !test.passed; });
  var response = {passed: failures.length === 0, tests: results, failures: failures,
    applicantId: applicantId, calendarEventsRemoved: remaining.length === 0};
  console.log(JSON.stringify(response));
  return response;
}
