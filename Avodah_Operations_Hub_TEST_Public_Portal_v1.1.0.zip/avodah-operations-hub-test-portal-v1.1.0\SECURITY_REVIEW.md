# Avodah Operations Hub — Manual Security Review

Date: 2026-07-22  
Scope: package `1.0.0-test-readiness` and copied TEST runtime

## Important limitation

The Codex Security workflow's mandatory preflight could not start because the
machine has Windows Store Python stubs but no usable Python runtime. Installing
system software was outside this phase's scope. The findings below come from a
manual, evidence-backed source and runtime review and must not be represented as
an exhaustive Codex Security scan.

## Reviewed boundaries

- `doGet` and secret-authenticated `doPost`
- internal `google.script.run` methods
- setup/property/role bootstrap functions
- installable and simple trigger callbacks
- retained legacy menu and maintenance entry points
- Calendar/Meet booking lifecycle and reconciliation
- Schedule Import preview/commit
- validation, LockService, idempotency, duplicate detection, audit logging
- HTML injection sinks and client rendering
- Script Properties and source credential exposure

## Findings and disposition

| Severity | Finding | Disposition |
|---|---|---|
| High | Retained legacy reconciliation and trigger installers bypassed modern role and activation gates. | Fixed: role checks added; reconciliation delegates to canonical gated workflow; legacy installer delegates to safe de-duplicated installation. |
| High | Setup/property bootstrap globals could become callable from a future HTML deployment. | Fixed: direct project-operator context is required; after USER_ROLE exists, ADMIN is required. |
| Medium | Trigger callbacks could be invoked directly without proving a registered trigger event. | Fixed: automation gate, trigger UID, registered project trigger, and handler match are required. |
| Medium | A legacy six-hour reconciliation trigger could coexist with canonical hourly reconciliation. | Fixed: canonical installation removes the legacy trigger and prevents duplicates. |
| Medium | Four required controlled-setting groups were absent, leaving validation gaps. | Fixed from existing TEST operational values only; no unverified status or owner was invented. |
| Medium | Existing web deployment is detectable but its ID, access policy, execute-as identity, owner, and deployed version are not recorded. | Open production blocker; no deployment was changed. |
| Medium | Public portal is a placeholder and secure anonymous intake/booking UX is not active. | Open production blocker; gate remains false. |
| Low | `WEBHOOK_SECRET_NEXT` is absent, so zero-downtime secret rotation is unavailable. | Recommended before production. |
| Low | Shared-secret equality is performed in Apps Script rather than behind an external gateway. | Accepted for trusted server-to-server TEST use; stronger gateway authentication remains a future hook. |

## Confirmed controls

- TEST spreadsheet name and environment fail closed before legacy code opens a
  spreadsheet.
- No production spreadsheet ID is present in executable source.
- Secrets and environment IDs are read from Script Properties.
- All operational write paths reviewed use role checks and/or explicit gates;
  scheduled callbacks additionally require a registered trigger event.
- Booking, Project 1, recruitment, analytics, and Schedule Import write paths
  use locks and module-specific activation gates.
- Booking uses idempotency keys/fingerprints, active-booking checks, Calendar
  conflict checks, rollback handling, event IDs, reconciliation, and audit logs.
- Formula-like cell input is escaped; normalized international phone values are
  stored as literal text.
- Client-rendered operational values use `textContent` or created DOM nodes. The
  only `innerHTML` occurrence is a fixed developer-authored warning string.
- Internal APIs require USER_ROLE. Anonymous users do not receive an internal
  role assignment.
- Trigger inventory is zero while automation is disabled.

## Required follow-up

Run the full Codex Security scan after a supported Python runtime is explicitly
approved and available. Re-run it against the exact versioned deployment
candidate, not only the editable HEAD source.

