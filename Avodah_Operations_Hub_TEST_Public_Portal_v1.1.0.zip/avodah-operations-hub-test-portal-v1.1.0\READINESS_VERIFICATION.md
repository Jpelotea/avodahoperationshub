# Avodah Operations Hub — TEST Readiness Verification

Date: 2026-07-22  
Package: `1.0.0-test-readiness`  
Scope: copied TEST spreadsheet and copied Apps Script project only

## Result

The current source is ready for controlled TEST use. It is not ready for a
production deployment.

- Required logical sheets: 24 of 24 present; no required sheet missing.
- Physical spreadsheet tabs: 31, including preserved legacy/support views.
- Advanced Calendar service: available.
- Active roles: one ADMIN; no unassigned role was invented.
- Configuration gates: none for controlled TEST readiness.
- Activation/write gates: all eight are `FALSE`.
- Installed project triggers: 0.
- Production spreadsheet: not accessed or changed.
- Apps Script source: 26 live files exactly match this package after newline
  normalization.
- Server source: 21 `.gs` files, 414 named functions, zero duplicate function
  names, and zero V8 parse errors.
- Source scans: zero occurrences of the production spreadsheet ID and zero
  hard-coded real email, Calendar ID, webhook secret, API key, or private-key
  candidates in `.gs`, `.html`, and `appsscript.json`.

## Settings completion

The readiness audit found four README-required setting groups that were absent.
Only values already present in preserved TEST operational data were added:

| Group | Rows added | Source evidence |
|---|---:|---|
| `LEAD_STATUS` | 1 | Existing Lead Database status |
| `FOLLOW_UP_STATUS` | 2 | Existing intake/lead booking lifecycle states |
| `TEAM_MEMBER` | 3 | Existing Calendar Log owners |
| `CALENDAR_CATEGORY` | 4 | Existing Calendar Log categories |

`masterSetup()` appended these settings without changing existing values or
headers. It applied missing Lead Status, Follow-up Status, and Project 1 Team
Member validations. Existing Calendar Log owner/status/category validations
were preserved.

The final idempotency run reported:

- created sheets: 0
- appended headers: 0
- settings seeded: 0
- triggers: skipped because disabled
- existing validations: preserved

## Regression evidence

All 112 read-only helper/security assertions passed:

| Suite | Passed |
|---|---:|
| Foundation | 13/13 |
| Intake and Lead | 8/8 |
| Booking rules | 12/12 |
| Project 1 | 31/31 |
| Recruitment | 7/7 |
| Analytics | 9/9 |
| Scheduled reporting | 12/12 |
| Schedule Import | 10/10 |
| Security and activation gates | 10/10 |

Prior phase verification records retain the controlled transactional evidence
for intake, booking/Calendar/Meet/reconciliation, Project 1, recruitment,
analytics, scheduled reporting, and Schedule Import. This readiness phase did
not repeat operational writes because its code changes were limited to access,
trigger, setup, validation, and audit controls.

Additional final checks:

- Legacy manual reconciliation delegated to the canonical workflow and returned
  `BOOKING_WORKFLOW_DISABLED`, with 0 records read and 0 written.
- The forged webhook secret check was rejected.
- A direct/forged trigger callback was rejected while automation was disabled.
- Calendar access and all three timezones remained aligned to Asia/Manila.
- Existing web-app service detection returned HTTP 200 HTML, but the deployed
  version could not be verified.

## Production blockers

1. Environment remains TEST.
2. `DEPLOYMENT_ID` is not recorded.
3. Existing deployed version is not verified.
4. `BOOKING_MANAGEMENT_BASE_URL` is not configured.
5. Public portal remains a disabled placeholder.
6. Internal/public deployment access and execute-as identities are not recorded.
7. `WEBHOOK_SECRET_NEXT` is not configured (recommended for rotation).
8. The mandatory Codex Security preflight could not run without Python; the
   accompanying security review is manual, not exhaustive.

