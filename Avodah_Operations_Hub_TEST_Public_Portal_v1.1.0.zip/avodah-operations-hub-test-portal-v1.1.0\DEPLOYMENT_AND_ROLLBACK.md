# Avodah Operations Hub — Deployment and Rollback Gate

## Current deployment state

- A web-app service URL is detectable and returns HTTP 200 HTML.
- `DEPLOYMENT_ID` is blank, so the deployment is not recorded in configuration.
- The deployed version could not be verified from the anonymous probe.
- This phase did not create, replace, update, or delete a deployment.
- This phase did not create or delete a trigger; final trigger count is zero.

Do not overwrite the detectable deployment until its exact deployment ID,
version, description, owner, execute-as identity, and access policy have been
recorded from **Deploy → Manage deployments**.

## Approved next sequence

1. Record the existing deployment inventory and take screenshots/export notes.
2. Confirm whether the existing deployment is internal, public, test-only, or
   obsolete. Do not infer its purpose from the URL.
3. Decide separate access models:
   - restricted authenticated internal deployment for staff;
   - anonymous public deployment only for the intentionally implemented public
     portal.
4. Finish and independently test `PublicPortal.html`; keep
   `PUBLIC_PORTAL_ENABLED=FALSE` until then.
5. Create a new versioned TEST deployment. Do not edit an unrecorded deployment
   in place.
6. Record the new ID in `DEPLOYMENT_ID` and, only after the management route is
   verified, set `BOOKING_MANAGEMENT_BASE_URL`.
7. Reauthorize with the intended owner/admin account and record trigger owner.
8. Test internal identity/USER_ROLE behavior and anonymous public behavior as
   separate cases.
9. Run the full booking lifecycle, cancellation, reschedule, reconciliation,
   public intake, and negative authorization tests against the deployed URL.
10. Enable automation last, verify five de-duplicated managed triggers, and
    monitor Apps Script Executions plus Automation Log.
11. Promote to production only through a separately reviewed, versioned change.

## Activation order

Keep all gates false at baseline. In TEST, enable only the module under test and
turn it off immediately after verification. The Calendar gate must never be
enabled merely to satisfy a non-Calendar test. Enable
`ENABLE_AUTOMATION_TRIGGERS` only when the reviewed triggers are intentionally
installed and expected to run.

## Rollback

### Source rollback before a new deployment

Restore the affected files from the verified v0.9.0 package
`avodah-operations-hub-test-schedule-import-v0.9.0`, save, and rerun the v0.9
verification checklist. The v0.9 package is the pre-readiness source snapshot.

The ten appended setting rows may remain: v0.9 ignores the additional controlled
groups. If a rollback requires disabling them, set their `Active` values to
`FALSE` after review; do not delete or reorder Settings rows.

### Deployment rollback

Leave the previous versioned deployment available. If a new TEST deployment
fails, route users back to the recorded prior deployment or deploy a new version
from the rollback source. Do not overwrite an unrecorded deployment.

### Data recovery

This phase did not modify operational source rows or Calendar events. It added
controlled Settings rows, applied validations where missing, and wrote normal
setup/audit records. No destructive data recovery is expected for this phase.

## First-live monitoring

Monitor Apps Script Executions, Automation Log, Activity Audit Log, Booking Audit,
and Booking Reconciliation after every first live transaction. Investigate any
`FAILED`, `PENDING`, `EVENT_MISSING`, `CALENDAR_*_FAILED`, or formula-view-change
status before continuing activation.

