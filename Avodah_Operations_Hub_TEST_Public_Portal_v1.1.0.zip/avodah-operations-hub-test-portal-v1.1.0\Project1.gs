/** Project 1 controlled mappings, validation, submission, and summaries. */

var AVODAH_PROJECT1_FIELD_DEFINITIONS = Object.freeze({
  prospectRecruitName: {label: 'Prospect Recruit Name', inputType: 'text'},
  interviewDate: {label: 'Interview Date', inputType: 'date'},
  interviewTime: {label: 'Interview Time', inputType: 'time'},
  interviewStatus: {label: 'Interview Status', inputType: 'text'},
  interviewResult: {label: 'Interview Result', inputType: 'text'},
  orientationDate: {label: 'Orientation Date', inputType: 'date'},
  contractDate: {label: 'Contract Date', inputType: 'date'},
  codingDate: {label: 'Coding Date', inputType: 'date'},
  examDate: {label: 'Exam Date', inputType: 'date'},
  examResult: {label: 'Exam Result', inputType: 'text'},
  licenseDate: {label: 'License Date', inputType: 'date'},
  clientName: {label: 'Client Name', inputType: 'text'},
  contactDate: {label: 'Contact Date', inputType: 'date'},
  contactResult: {label: 'Contact Result', inputType: 'text'},
  activityDate: {label: 'Activity Date', inputType: 'date'},
  proofUrl: {label: 'Proof URL', inputType: 'url'},
  issueDate: {label: 'Issue Date', inputType: 'date'},
  policyNumber: {label: 'Policy Number', inputType: 'text'},
  advisorAssisted: {label: 'Advisor Assisted', inputType: 'text'}
});

function project1MappingKey_(activityType, subActivity) {
  return String(activityType || '').trim().toLowerCase() + '|' +
    String(subActivity || '').trim().toLowerCase();
}

function getProject1PointMapping_() {
  var seen = {};
  return getActiveSettingsByGroupSafe_('PROJECT1_ACTIVITY').map(function(row) {
    var item = safeJsonParse_(row.value, null);
    if (!item || !item.activityType || !item.subActivity ||
        !Number.isFinite(Number(item.points)) || Number(item.points) < 0 ||
        !Array.isArray(item.requiredFields)) {
      throw avodahError_('PROJECT1_MAPPING_INVALID',
        'Invalid PROJECT1_ACTIVITY configuration row: ' + row.key);
    }
    var key = project1MappingKey_(item.activityType, item.subActivity);
    if (seen[key]) {
      throw avodahError_('PROJECT1_MAPPING_DUPLICATE',
        'More than one active mapping exists for ' + item.activityType +
        ' / ' + item.subActivity + '.');
    }
    item.requiredFields.forEach(function(fieldKey) {
      if (!AVODAH_PROJECT1_FIELD_DEFINITIONS[fieldKey]) {
        throw avodahError_('PROJECT1_FIELD_UNKNOWN',
          'Unknown Project 1 required field: ' + fieldKey);
      }
    });
    seen[key] = true;
    return {
      activityType: String(item.activityType).trim(),
      subActivity: String(item.subActivity).trim(),
      points: Number(item.points),
      requiredFields: item.requiredFields.slice(),
      settingRow: row.rowNumber
    };
  });
}

function project1ActivityTypes_() {
  return getProject1PointMapping_().map(function(item) {
    return item.activityType;
  }).filter(function(value, index, all) {
    return all.indexOf(value) === index;
  });
}

function project1SubActivities_() {
  return getProject1PointMapping_().map(function(item) {
    return item.subActivity;
  }).filter(function(value, index, all) {
    return all.indexOf(value) === index;
  });
}

function project1TeamMemberOptions_() {
  return getActiveSettingsByGroupSafe_('TEAM_MEMBER').map(function(row) {
    return String(row.value || row.key || '').trim();
  }).filter(function(value, index, all) {
    return value && all.indexOf(value) === index;
  });
}

function findProject1Mapping_(activityType, subActivity) {
  var key = project1MappingKey_(activityType, subActivity);
  return getProject1PointMapping_().filter(function(item) {
    return project1MappingKey_(item.activityType, item.subActivity) === key;
  })[0] || null;
}

function assertProject1WritesEnabled_() {
  if (getEnvironment_() !== 'TEST') {
    throw avodahError_('TEST_ONLY',
      'This Project 1 package is restricted to the copied TEST environment.');
  }
  var spreadsheet = getHubSpreadsheet_();
  if (!/^TEST(?:\s|-)/i.test(spreadsheet.getName())) {
    throw avodahError_('TEST_ONLY',
      'Project 1 writes require a spreadsheet whose title begins with TEST.');
  }
  var enabled = String(PropertiesService.getScriptProperties()
    .getProperty('ENABLE_PROJECT1_WRITES') || '').trim().toUpperCase();
  if (enabled !== 'TRUE') {
    throw avodahError_('PROJECT1_WRITES_DISABLED',
      'Set ENABLE_PROJECT1_WRITES=TRUE only for an approved TEST transaction.');
  }
}

function project1Date_(value, fieldName) {
  var date;
  if (value instanceof Date) {
    date = new Date(value.getTime());
  } else {
    var text = String(value == null ? '' : value).trim();
    var match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(text);
    if (match) {
      date = new Date(Number(match[1]), Number(match[2]) - 1,
        Number(match[3]), 12, 0, 0, 0);
      if (Utilities.formatDate(date, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM-dd') !== text) {
        date = new Date('invalid');
      }
    } else {
      date = new Date(value);
    }
  }
  if (!date || isNaN(date.getTime())) {
    throw avodahError_('INVALID_PROJECT1_DATE',
      String(fieldName || 'Date') + ' must be a valid date.');
  }
  return date;
}

function project1DateKey_(value) {
  return Utilities.formatDate(project1Date_(value, 'Activity Date'),
    AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM-dd');
}

function project1ReportingWeek_(value) {
  var day = Number(Utilities.formatDate(project1Date_(value, 'Activity Date'),
    AVODAH_CONFIG.TIME_ZONE, 'd'));
  if (day <= 7) return 'Week 1';
  if (day <= 14) return 'Week 2';
  if (day <= 21) return 'Week 3';
  return 'Week 4';
}

function project1ReportingMonth_(value) {
  return Utilities.formatDate(project1Date_(value, 'Activity Date'),
    AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
}

function project1MonthValue_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
  }
  var text = String(value == null ? '' : value).trim();
  if (/^\d{4}-\d{2}$/.test(text)) return text;
  var parsed = new Date(value);
  return isNaN(parsed.getTime()) ? text :
    Utilities.formatDate(parsed, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
}

function project1NormalizeField_(fieldKey, value) {
  var definition = AVODAH_PROJECT1_FIELD_DEFINITIONS[fieldKey];
  if (!definition) {
    throw avodahError_('PROJECT1_FIELD_UNKNOWN',
      'Unknown Project 1 field: ' + fieldKey);
  }
  var text = String(value == null ? '' : value).trim();
  if (!text) return '';
  if (definition.inputType === 'date') {
    return project1DateKey_(value);
  }
  if (definition.inputType === 'time') {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(text)) {
      throw avodahError_('INVALID_PROJECT1_TIME',
        definition.label + ' must use HH:mm.');
    }
    return text;
  }
  if (definition.inputType === 'url') {
    if (!/^https:\/\/[^\s]+$/i.test(text)) {
      throw avodahError_('INVALID_PROOF_URL',
        definition.label + ' must be a valid HTTPS URL.');
    }
    return text;
  }
  return text;
}

function project1RequiredData_(mapping, payload) {
  var supplied = payload && (payload.fields || payload.required_data) || {};
  if (Object.prototype.toString.call(supplied) !== '[object Object]') {
    throw avodahError_('INVALID_PROJECT1_FIELDS',
      'Project 1 fields must be provided as an object.');
  }
  var data = {};
  var proofUrl = '';
  mapping.requiredFields.forEach(function(fieldKey) {
    var value = fieldKey === 'proofUrl'
      ? (payload.proof_url || supplied.proofUrl) : supplied[fieldKey];
    var normalized = project1NormalizeField_(fieldKey, value);
    if (!normalized) {
      throw avodahError_(fieldKey === 'proofUrl' ? 'PROOF_REQUIRED' :
        'PROJECT1_FIELD_REQUIRED',
        AVODAH_PROJECT1_FIELD_DEFINITIONS[fieldKey].label + ' is required.',
        {field: fieldKey});
    }
    if (fieldKey === 'proofUrl') proofUrl = normalized;
    else data[fieldKey] = normalized;
  });
  return {data: data, proofUrl: proofUrl};
}

function project1StatusSummary_(mapping, data) {
  if (data.interviewStatus) return data.interviewStatus;
  if (data.interviewResult) return data.interviewResult;
  if (data.examResult) return data.examResult;
  var statuses = {
    'Listing of Prospect Recruit Name': 'Listed',
    'Call Out for Initial Interview': 'Interview Scheduled',
    'Orientation Attendance': 'Orientation Attended',
    'Contract Signing': 'Contract Signed',
    'Coding': 'Coding Completed',
    'Licensing': 'Licensed',
    'Prospect Listing': 'Listed',
    'Initial Contact / Call Out': 'Contacted',
    'FNA Conducted': 'FNA Completed',
    'Proposal Presented': 'Proposal Presented',
    'Application Submitted': 'Application Submitted',
    'Issued Policy': 'Policy Issued',
    'Shadowing / Observation': 'Completed',
    'Co-Presentation': 'Completed',
    'Assisted Closing': 'Completed'
  };
  return statuses[mapping.subActivity] || 'Completed';
}

function project1Fingerprint_(payload, mapping, requiredData, activityDate) {
  var ordered = {};
  mapping.requiredFields.forEach(function(fieldKey) {
    if (fieldKey !== 'proofUrl') ordered[fieldKey] = requiredData[fieldKey] || '';
  });
  var source = [
    String(payload.agent_code || '').trim().toUpperCase(),
    project1DateKey_(activityDate),
    mapping.activityType.toLowerCase(),
    mapping.subActivity.toLowerCase(),
    safeJsonStringify_(ordered)
  ].join('|');
  var digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    source, Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '').substring(0, 32);
}

function findActiveProject1Duplicate_(fingerprint) {
  return getObjectRows_('Project 1 Activity Database').filter(function(item) {
    return String(item.record['Duplicate Fingerprint'] || '') === fingerprint &&
      String(item.record['Record Status'] || 'ACTIVE').toUpperCase() === 'ACTIVE';
  })[0] || null;
}

function validateProject1Submission_(payload) {
  var input = payload || {};
  var activityDate = project1Date_(input.activity_date, 'Activity Date');
  var agentCode = String(input.agent_code || '').trim();
  var teamMember = String(input.team_member || '').trim();
  if (!agentCode) throw avodahError_('AGENT_CODE_REQUIRED', 'Agent Code is required.');
  if (!teamMember) throw avodahError_('TEAM_MEMBER_REQUIRED', 'Team Member is required.');
  var teamOptions = project1TeamMemberOptions_();
  if (teamOptions.length && teamOptions.map(function(value) {
    return value.toLowerCase();
  }).indexOf(teamMember.toLowerCase()) === -1) {
    throw avodahError_('TEAM_MEMBER_NOT_CONFIGURED',
      'Team Member must match an active TEAM_MEMBER setting.');
  }
  var mapping = findProject1Mapping_(input.activity_type, input.sub_activity);
  if (!mapping) {
    throw avodahError_('PROJECT1_MAPPING_NOT_FOUND',
      'Activity Type and Sub-Activity must match one active controlled mapping.');
  }
  var required = project1RequiredData_(mapping, input);
  return {
    activityDate: activityDate,
    agentCode: agentCode,
    teamMember: teamMember,
    mapping: mapping,
    requiredData: required.data,
    proofUrl: required.proofUrl,
    notes: String(input.notes || '').trim()
  };
}

function project1AuditSafe_(event) {
  try {
    logAuditEvent_(event);
    return true;
  } catch (error) {
    logAutomationSafe_({
      handler: 'project1AuditSafe_',
      status: 'WARNING',
      errorCode: error.code || 'AUDIT_WRITE_FAILED',
      errorMessage: String(error.message || error),
      details: {entityId: event.entityId || ''}
    });
    return false;
  }
}

function formatProject1ActivityRow_(rowNumber) {
  var context = getTableContext_('Project 1 Activity Database');
  var activityDateColumn = context.headerMap[normalizeHeader_('Activity Date')];
  if (activityDateColumn) {
    context.sheet.getRange(rowNumber, activityDateColumn).setNumberFormat('yyyy-mm-dd');
  }
}

function submitProject1Activity(payload) {
  var user = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
  return submitProject1Activity_(payload, {
    user: user,
    source: 'INTERNAL_HUB',
    requestId: Utilities.getUuid()
  });
}

function submitProject1Activity_(payload, options) {
  assertProject1WritesEnabled_();
  var settings = options || {};
  var user = settings.user || requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
  return withScriptLock_('submitProject1Activity', function() {
    var validated = validateProject1Submission_(payload);
    var mapping = validated.mapping;
    var fingerprint = project1Fingerprint_(payload, mapping,
      validated.requiredData, validated.activityDate);
    var duplicate = findActiveProject1Duplicate_(fingerprint);
    if (duplicate && !truthy_(payload && payload.confirm_duplicate)) {
      return {
        ok: false,
        code: 'DUPLICATE_CONFIRMATION_REQUIRED',
        message: 'A matching Project 1 activity already exists.',
        existing_activity_id: duplicate.record['Activity ID'] || '',
        duplicate_status: 'POSSIBLE_DUPLICATE'
      };
    }

    var now = new Date();
    var activityId = generateUniqueId_('PROJECT1');
    var duplicateStatus = duplicate ? 'CONFIRMED_DUPLICATE' : 'UNIQUE';
    var rowNumber = appendObjectRow_('Project 1 Activity Database', {
      'Activity ID': activityId,
      'Submission Timestamp': now,
      'Activity Date': validated.activityDate,
      'Agent Code': validated.agentCode,
      'Team Member': validated.teamMember,
      'Activity Type': mapping.activityType,
      'Sub-Activity': mapping.subActivity,
      'Points': mapping.points,
      'Required Data JSON': safeJsonStringify_(validated.requiredData),
      'Proof URL': validated.proofUrl,
      'Duplicate Fingerprint': fingerprint,
      'Duplicate Status': duplicateStatus,
      'Status Summary': project1StatusSummary_(mapping, validated.requiredData),
      'Reporting Week': project1ReportingWeek_(validated.activityDate),
      'Reporting Month': project1ReportingMonth_(validated.activityDate),
      'Record Status': 'ACTIVE',
      'Created By': user.email || '',
      'Created At': now,
      'Updated At': now
    });
    formatProject1ActivityRow_(rowNumber);
    SpreadsheetApp.flush();
    var auditWritten = project1AuditSafe_({
      actorEmail: user.email || '',
      actorRole: user.role || '',
      action: 'PROJECT1_ACTIVITY_SUBMITTED',
      entityType: 'PROJECT1_ACTIVITY',
      entityId: activityId,
      result: 'SUCCESS',
      requestId: settings.requestId || '',
      details: {
        activityType: mapping.activityType,
        subActivity: mapping.subActivity,
        points: mapping.points,
        duplicateStatus: duplicateStatus,
        source: settings.source || ''
      }
    });
    return {
      ok: true,
      code: duplicate ? 'PROJECT1_CONFIRMED_DUPLICATE_CREATED' :
        'PROJECT1_ACTIVITY_CREATED',
      activity_id: activityId,
      row_number: rowNumber,
      points: mapping.points,
      reporting_week: project1ReportingWeek_(validated.activityDate),
      reporting_month: project1ReportingMonth_(validated.activityDate),
      duplicate_status: duplicateStatus,
      audit_written: auditWritten
    };
  });
}

function getProject1FormDefinition() {
  var user = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
  var activities = [];
  getProject1PointMapping_().forEach(function(mapping) {
    var activity = activities.filter(function(item) {
      return item.activityType === mapping.activityType;
    })[0];
    if (!activity) {
      activity = {activityType: mapping.activityType, subActivities: []};
      activities.push(activity);
    }
    activity.subActivities.push({
      subActivity: mapping.subActivity,
      points: mapping.points,
      fields: mapping.requiredFields.map(function(fieldKey) {
        var definition = AVODAH_PROJECT1_FIELD_DEFINITIONS[fieldKey];
        return {key: fieldKey, label: definition.label,
          inputType: definition.inputType, required: true};
      })
    });
  });
  return {
    version: AVODAH_CONFIG.VERSION,
    writeEnabled: String(PropertiesService.getScriptProperties()
      .getProperty('ENABLE_PROJECT1_WRITES') || '').trim().toUpperCase() === 'TRUE',
    defaultTeamMember: user.displayName || '',
    teamMembers: project1TeamMemberOptions_(),
    activities: activities
  };
}

function project1MonthlySummaryCore_(rows, month, options) {
  var monthKey = String(month || '').trim();
  if (!/^\d{4}-\d{2}$/.test(monthKey)) {
    throw avodahError_('INVALID_REPORTING_MONTH',
      'Reporting month must use YYYY-MM.');
  }
  var filterAgent = String(options && options.agentCode || '').trim().toUpperCase();
  var selected = (rows || []).filter(function(item) {
    var record = item.record || item;
    return project1MonthValue_(record['Reporting Month']) === monthKey &&
      String(record['Record Status'] || 'ACTIVE').toUpperCase() === 'ACTIVE' &&
      (!filterAgent || String(record['Agent Code'] || '').trim().toUpperCase() === filterAgent);
  });
  var typeTotals = {};
  var subActivityTotals = {};
  var teamTotals = {};
  var totalPoints = 0;
  selected.forEach(function(item) {
    var record = item.record || item;
    var points = Number(record.Points || 0);
    totalPoints += points;
    var type = String(record['Activity Type'] || 'Unspecified');
    var sub = type + ' | ' + String(record['Sub-Activity'] || 'Unspecified');
    var team = String(record['Team Member'] || 'Unassigned');
    typeTotals[type] = (typeTotals[type] || 0) + points;
    subActivityTotals[sub] = (subActivityTotals[sub] || 0) + points;
    teamTotals[team] = (teamTotals[team] || 0) + points;
  });
  function toRows_(object) {
    return Object.keys(object).sort().map(function(key) {
      return {name: key, points: object[key]};
    });
  }
  return {
    month: monthKey,
    records: selected.length,
    totalPoints: totalPoints,
    byActivityType: toRows_(typeTotals),
    bySubActivity: toRows_(subActivityTotals),
    byTeamMember: toRows_(teamTotals)
  };
}

function getProject1MonthlySummary(month) {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var monthKey = month || Utilities.formatDate(new Date(),
    AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
  return project1MonthlySummaryCore_(
    getObjectRows_('Project 1 Activity Database'), monthKey, {});
}

function project1TestPayload_(mapping, index, agentCode, activityDate) {
  var fields = {};
  mapping.requiredFields.forEach(function(fieldKey) {
    var definition = AVODAH_PROJECT1_FIELD_DEFINITIONS[fieldKey];
    if (definition.inputType === 'date') fields[fieldKey] = project1DateKey_(activityDate);
    else if (definition.inputType === 'time') fields[fieldKey] = '09:00';
    else if (definition.inputType === 'url') {
      fields[fieldKey] = 'https://example.com/avodah-test-proof/' + index;
    } else if (fieldKey === 'examResult') fields[fieldKey] = 'Passed';
    else if (fieldKey === 'interviewStatus') fields[fieldKey] = 'Completed';
    else if (fieldKey === 'interviewResult') fields[fieldKey] = 'Proceed';
    else if (fieldKey === 'contactResult') fields[fieldKey] = 'Reached';
    else fields[fieldKey] = 'TEST ' + definition.label + ' ' + index;
  });
  return {
    activity_date: project1DateKey_(activityDate),
    agent_code: agentCode,
    team_member: project1TeamMemberOptions_()[0] || 'TEST Project 1 Agent',
    activity_type: mapping.activityType,
    sub_activity: mapping.subActivity,
    fields: fields,
    proof_url: fields.proofUrl || '',
    notes: 'Automated TEST Project 1 lifecycle fixture'
  };
}

function runProject1ValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var mappings = getProject1PointMapping_();
  testAssert_(tests, '18 active Project 1 mappings', mappings.length === 18);
  testAssert_(tests, 'Project 1 point total is 41', mappings.reduce(function(sum, item) {
    return sum + item.points;
  }, 0) === 41);
  AVODAH_PROJECT1_ACTIVITY_SEEDS.forEach(function(seed) {
    var mapping = mappings.filter(function(item) {
      return project1MappingKey_(item.activityType, item.subActivity) ===
        project1MappingKey_(seed[0], seed[1]);
    })[0];
    testAssert_(tests, seed[0] + ' / ' + seed[1] + ' points',
      Boolean(mapping) && mapping.points === Number(seed[2]));
  });
  var uniqueKeys = mappings.map(function(item) {
    return project1MappingKey_(item.activityType, item.subActivity);
  });
  testAssert_(tests, 'mapping keys are unique', uniqueKeys.length ===
    uniqueKeys.filter(function(key, index) { return uniqueKeys.indexOf(key) === index; }).length);
  testAssert_(tests, 'Week 1 bucket', project1ReportingWeek_('2026-07-07') === 'Week 1');
  testAssert_(tests, 'Week 2 bucket', project1ReportingWeek_('2026-07-08') === 'Week 2');
  testAssert_(tests, 'Week 3 bucket', project1ReportingWeek_('2026-07-15') === 'Week 3');
  testAssert_(tests, 'Week 4 bucket', project1ReportingWeek_('2026-07-22') === 'Week 4');
  var proofMapping = mappings.filter(function(item) {
    return item.requiredFields.indexOf('proofUrl') !== -1;
  })[0];
  var missingProof = project1TestPayload_(proofMapping, 900, 'TEST-VALIDATION',
    '2026-07-22');
  missingProof.proof_url = '';
  delete missingProof.fields.proofUrl;
  testAssert_(tests, 'proof-required activity rejects missing proof',
    testErrorCode_(function() { validateProject1Submission_(missingProof); }) ===
      'PROOF_REQUIRED');
  var invalidPair = project1TestPayload_(mappings[0], 901, 'TEST-VALIDATION',
    '2026-07-22');
  invalidPair.activity_type = 'Sales';
  testAssert_(tests, 'type and sub-activity relationship enforced',
    testErrorCode_(function() { validateProject1Submission_(invalidPair); }) ===
      'PROJECT1_MAPPING_NOT_FOUND');
  var synthetic = mappings.map(function(item, index) {
    return {record: {
      'Reporting Month': '2026-07',
      'Record Status': 'ACTIVE',
      'Agent Code': 'TEST-SUMMARY',
      'Team Member': 'TEST Project 1 Agent',
      'Activity Type': item.activityType,
      'Sub-Activity': item.subActivity,
      'Points': item.points
    }};
  });
  var summary = project1MonthlySummaryCore_(synthetic, '2026-07',
    {agentCode: 'TEST-SUMMARY'});
  testAssert_(tests, 'monthly summary counts all mappings', summary.records === 18);
  testAssert_(tests, 'monthly total equals 41', summary.totalPoints === 41);
  testAssert_(tests, 'analytics groups three activity types',
    summary.byActivityType.length === 3);
  testAssert_(tests, 'P1 ID prefix available',
    generateUniqueId_('PROJECT1').indexOf('P1-') === 0);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(result));
  return result;
}

function runProject1LifecycleIntegrationTest() {
  var user = requireUserRole_(['ADMIN']);
  assertProject1WritesEnabled_();
  var mappings = getProject1PointMapping_();
  var suffix = Utilities.formatDate(new Date(), AVODAH_CONFIG.TIME_ZONE,
    'yyyyMMddHHmmss');
  var agentCode = 'TEST-P1-' + suffix;
  var activityDate = new Date();
  var tests = [];
  var created = [];
  mappings.forEach(function(mapping, index) {
    var payload = project1TestPayload_(mapping, index + 1, agentCode, activityDate);
    var result = submitProject1Activity_(payload, {
      user: user,
      source: 'PROJECT1_INTEGRATION_TEST',
      requestId: Utilities.getUuid()
    });
    created.push({payload: payload, result: result, mapping: mapping});
    testAssert_(tests, mapping.activityType + ' / ' + mapping.subActivity,
      result.ok && result.points === mapping.points &&
      String(result.activity_id || '').indexOf('P1-') === 0);
  });
  var duplicate = submitProject1Activity_(created[0].payload, {
    user: user,
    source: 'PROJECT1_INTEGRATION_TEST',
    requestId: Utilities.getUuid()
  });
  testAssert_(tests, 'duplicate warning blocks unconfirmed repeat',
    !duplicate.ok && duplicate.code === 'DUPLICATE_CONFIRMATION_REQUIRED');
  var proofMapping = mappings.filter(function(item) {
    return item.requiredFields.indexOf('proofUrl') !== -1;
  })[0];
  var missingProof = project1TestPayload_(proofMapping, 999,
    agentCode + '-MISSING-PROOF', activityDate);
  missingProof.proof_url = '';
  delete missingProof.fields.proofUrl;
  testAssert_(tests, 'live proof validation rejects missing proof',
    testErrorCode_(function() {
      submitProject1Activity_(missingProof, {user: user,
        source: 'PROJECT1_INTEGRATION_TEST'});
    }) === 'PROOF_REQUIRED');
  var rows = getObjectRows_('Project 1 Activity Database').filter(function(item) {
    return String(item.record['Agent Code'] || '') === agentCode;
  });
  testAssert_(tests, 'one row written for every mapping', rows.length === 18);
  testAssert_(tests, 'all rows use the expected reporting week', rows.every(function(item) {
    return item.record['Reporting Week'] === project1ReportingWeek_(activityDate);
  }));
  var summary = project1MonthlySummaryCore_(rows,
    project1ReportingMonth_(activityDate), {agentCode: agentCode});
  testAssert_(tests, 'live monthly total is 41', summary.totalPoints === 41);
  testAssert_(tests, 'live analytics groups all three activity types',
    summary.byActivityType.length === 3);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {
    passed: failures.length === 0,
    tests: tests,
    failures: failures,
    agentCode: agentCode,
    activityIds: created.map(function(item) { return item.result.activity_id; }),
    rowsWritten: rows.length,
    totalPoints: summary.totalPoints
  };
  console.log(JSON.stringify(result));
  return result;
}
