/**
 * Management Dashboard derived view.
 *
 * The legacy dashboard and its floating chart are preserved. Avodah owns only
 * A45:L69 and
 * refuses to overwrite that block unless it is blank or carries the expected
 * ownership marker.
 */

var AVODAH_DASHBOARD_RANGE = 'A45:L69';
var AVODAH_PREVIOUS_DASHBOARD_RANGE = 'A20:L44';
var AVODAH_DASHBOARD_MARKER = 'AVODAH DERIVED OPERATIONS SNAPSHOT';

function refreshDashboard_(snapshot) {
  assertAnalyticsWritesEnabled_();
  var data = snapshot || buildAnalyticsSnapshot_(new Date());
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_('Management Dashboard');
  var sheet = findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) {
    throw avodahError_('MISSING_DASHBOARD', 'Management Dashboard is missing.');
  }
  migratePreviousDashboardRange_(sheet);
  assertDashboardOwnedRange_(sheet);
  writeDashboardOwnedRange_(sheet, data);
  ensureDashboardWarning_(sheet);
  return {range: sheet.getName() + '!' + AVODAH_DASHBOARD_RANGE, cellsWritten: 74};
}

function migratePreviousDashboardRange_(sheet) {
  var previous = sheet.getRange(AVODAH_PREVIOUS_DASHBOARD_RANGE);
  var marker = String(previous.getCell(1, 1).getDisplayValue() || '').trim();
  if (marker !== AVODAH_DASHBOARD_MARKER) return;
  previous.breakApart();
  previous.clearContent();
  previous.clearFormat();
  previous.clearNote();
  sheet.setRowHeights(20, 25, 21);
}

function assertDashboardOwnedRange_(sheet) {
  var range = sheet.getRange(AVODAH_DASHBOARD_RANGE);
  var values = range.getDisplayValues();
  var populated = values.some(function(row) {
    return row.some(function(value) { return String(value || '').trim() !== ''; });
  });
  var marker = String(values[0][0] || '').trim();
  if (populated && marker !== AVODAH_DASHBOARD_MARKER) {
    throw avodahError_('DASHBOARD_RANGE_OCCUPIED',
      sheet.getName() + '!' + AVODAH_DASHBOARD_RANGE +
      ' contains content not owned by the Avodah derived dashboard.');
  }
}

function writeDashboardOwnedRange_(sheet, snapshot) {
  var owned = sheet.getRange(AVODAH_DASHBOARD_RANGE);
  owned.breakApart();
  owned.clearContent();
  owned.clearFormat();

  var green = '#05542A';
  var lightGreen = '#F4F9F7';
  var paleBlue = '#E8F4FE';
  var white = '#FFFFFF';
  var gray = '#5F6368';

  sheet.getRange('A45:L45').merge().setValue(AVODAH_DASHBOARD_MARKER)
    .setBackground(green).setFontColor(white).setFontWeight('bold')
    .setFontSize(16).setHorizontalAlignment('left').setVerticalAlignment('middle');
  sheet.setRowHeight(45, 36);

  var freshness = 'As of ' + snapshot.asOfIso +
    ' | Sources: Lead Database, Applicant Tracking, Booking Registry, ' +
    'Calendar Log, Project 1 Activity Database';
  sheet.getRange('A46:L46').merge().setValue(freshness)
    .setBackground(paleBlue).setFontColor(gray).setFontSize(9)
    .setWrap(true).setVerticalAlignment('middle');
  sheet.setRowHeight(46, 32);

  var cards = [
    {range: 'A48:C48', valueRange: 'A49:C50', label: 'TOTAL LEADS',
      value: snapshot.leads.cards.totalLeads,
      note: 'Count of Lead Database rows with a Lead ID.'},
    {range: 'D48:F48', valueRange: 'D49:F50', label: 'ACTIVE APPLICANTS',
      value: snapshot.recruitment.cards.activeApplicants,
      note: 'Applicant Tracking rows excluding inactive, archived, void, or deleted records.'},
    {range: 'G48:I48', valueRange: 'G49:I50', label: 'ACTIVE BOOKINGS',
      value: snapshot.bookings.cards.activeBookings,
      note: 'Scheduled, confirmed, or rescheduled Booking Registry rows.'},
    {range: 'J48:L48', valueRange: 'J49:L50',
      label: 'PROJECT 1 POINTS - ' + snapshot.monthKey,
      value: snapshot.project1.cards.currentMonthPoints,
      note: 'Active Project 1 points whose activity date falls in the displayed month.'}
  ];
  cards.forEach(function(card) {
    sheet.getRange(card.range).merge().setValue(card.label)
      .setBackground(green).setFontColor(white).setFontWeight('bold')
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
    sheet.getRange(card.valueRange).merge().setValue(card.value)
      .setBackground(lightGreen).setFontColor(green).setFontWeight('bold')
      .setFontSize(22).setHorizontalAlignment('center').setVerticalAlignment('middle')
      .setNote(card.note).setNumberFormat('0');
  });
  sheet.setRowHeights(49, 2, 28);

  var sections = [
    {header: 'A53:C53', label: 'LEAD STATUS', startColumn: 1,
      rows: snapshot.leads.breakdowns.status},
    {header: 'D53:F53', label: 'RECRUITMENT STAGE', startColumn: 4,
      rows: snapshot.recruitment.breakdowns.stage},
    {header: 'G53:I53', label: 'BOOKING STATUS', startColumn: 7,
      rows: snapshot.bookings.breakdowns.status},
    {header: 'J53:L53', label: 'PROJECT 1 POINTS BY TYPE', startColumn: 10,
      rows: snapshot.project1.breakdowns.pointsByType}
  ];
  sections.forEach(function(section) {
    sheet.getRange(section.header).merge().setValue(section.label)
      .setBackground(green).setFontColor(white).setFontWeight('bold')
      .setHorizontalAlignment('center');
    writeDashboardBreakdown_(sheet, section.startColumn, section.rows, lightGreen,
      green);
  });
  sheet.setRowHeight(53, 26);
  sheet.setRowHeights(54, 10, 22);

  sheet.getRange('A67:L67').merge()
    .setValue('DERIVED VIEW - update operational source databases, not this dashboard block.')
    .setBackground(paleBlue).setFontColor(gray).setFontStyle('italic')
    .setHorizontalAlignment('center').setVerticalAlignment('middle');
  sheet.setRowHeight(67, 28);

  owned.setBorder(true, true, true, true, false, false, '#DADCE0',
    SpreadsheetApp.BorderStyle.SOLID);
}

function writeDashboardBreakdown_(sheet, startColumn, rows, background, color) {
  var limited = (rows || []).slice(0, 10);
  for (var index = 0; index < 10; index += 1) {
    var rowNumber = 54 + index;
    var labelRange = sheet.getRange(rowNumber, startColumn, 1, 2).merge();
    var valueCell = sheet.getRange(rowNumber, startColumn + 2);
    if (limited[index]) {
      labelRange.setValue(limited[index].dimension);
      valueCell.setValue(limited[index].value).setNumberFormat('0');
    }
    labelRange.setBackground(background).setFontColor(color)
      .setHorizontalAlignment('left').setVerticalAlignment('middle');
    valueCell.setBackground(background).setFontColor(color).setFontWeight('bold')
      .setHorizontalAlignment('center').setVerticalAlignment('middle');
  }
}

function ensureDashboardWarning_(sheet) {
  try {
    var description = 'AVODAH_DERIVED_DASHBOARD_RANGE';
    var protections = sheet.getProtections(SpreadsheetApp.ProtectionType.RANGE);
    var existing = protections.filter(function(protection) {
      return protection.getDescription() === description;
    })[0];
    if (existing) {
      existing.setRange(sheet.getRange(AVODAH_DASHBOARD_RANGE));
      existing.setWarningOnly(true);
    } else {
      var protection = sheet.getRange(AVODAH_DASHBOARD_RANGE).protect();
      protection.setDescription(description);
      protection.setWarningOnly(true);
    }
  } catch (error) {
    console.warn('Dashboard warning protection unavailable: ' + String(error));
  }
}
