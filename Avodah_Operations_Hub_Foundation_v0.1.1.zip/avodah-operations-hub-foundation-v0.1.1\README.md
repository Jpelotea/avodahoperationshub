# Avodah Operations Hub — Foundation Gate 0.1.1

This package is the first safe implementation stage of the Avodah Operations
Hub README. It is intentionally not a complete replacement for the current
production system.

## What this stage implements

- Modular Apps Script file layout and manifest.
- Script Property validation without embedded IDs, secrets, or user emails.
- Idempotent sheet detection with legacy aliases.
- Missing-header append behavior; no existing column is deleted or reordered.
- A compatibility settings table appended to the existing `Targets & Settings`
  sheet instead of replacing its current layout.
- README Project 1 point mappings in controlled settings rows.
- Unique ID, email, phone, date, and JSON helpers.
- Lock-protected `masterSetup()`.
- Data-validation installation that preserves existing rules.
- Safe, duplicate-resistant trigger installation behind an explicit property.
- `USER_ROLE` bootstrap and authorization.
- Separate transitional audit logging so the current operational `Activity Log`
  is not polluted by audit rows.
- An internal status shell and disabled public portal.
- Read-only schema-gap inspection and Foundation helper tests.

## Deliberately inactive

The intake-to-lead, booking/calendar, Project 1, recruitment, analytics,
dashboard-refresh, notification workflow, and schedule-import mutations remain
inactive. Their current implementations stay authoritative until each migration
is inspected and tested in the required sequence.

This revision does not declare `doGet`, `doPost`, or the legacy
`jsonResponse_`, so the latest known V3 booking web routes can remain
authoritative during Foundation. The actual copied project must still be
inventoried before files are added because additional, unobserved collisions may
exist.

## Phase 1 activation order

1. Open the dated test copy, not the live spreadsheet.
2. In Extensions → Apps Script, inventory and export every current file.
3. Record the current deployments, Script Properties, enabled services, and
   installed triggers. A copied spreadsheet does not prove these runtime items
   copied or remained authorized.
4. Merge the manifest scopes and Advanced Calendar service entry carefully.
5. Add the modular files only after checking every global function against the
   copied project. The three collisions known from the local V3 snapshot are
   already avoided by this revision.
6. Set real Script Properties in Project Settings or by passing real values to
   `setInitialScriptProperties(...)`.
7. Keep `PUBLIC_PORTAL_ENABLED` and `ENABLE_AUTOMATION_TRIGGERS` false.
8. Run `verifyConfiguration_()` and `inspectFoundationGap_()`.
9. Run `masterSetup()` in `TEST`.
10. Inspect appended columns and the settings table before any further action.
11. Run `bootstrapInitialUserRoles(...)` with the authenticated administrator's
    real email and approved assignments.
12. Enable/confirm the Advanced Calendar service, then run
    `verifyCalendarAccess_()`.
13. Run `runFoundationTests()` and `verifyConfiguration_()` again.

No trigger or deployment should be enabled until the verification report is
clean and the module-specific workflow tests have passed.

## Required Script Properties

| Property | Foundation expectation |
|---|---|
| `AVODAH_SPREADSHEET_ID` | ID of the dated test Hub copy |
| `CHRISTINE_CALENDAR_ID` | Verified authoritative consultation calendar |
| `ENVIRONMENT` | `TEST` for this stage |
| `WEBHOOK_SECRET` | Real secret stored only in Script Properties |
| `ADMIN_NOTIFICATION_EMAIL` | Optional verified internal recipient |
| `DEPLOYMENT_ID` | Optional recorded deployment metadata |
| `PUBLIC_PORTAL_ENABLED` | Keep false in Foundation |
| `ENABLE_AUTOMATION_TRIGGERS` | Keep false until workflow handlers pass |

## Production boundary

`masterSetup()` refuses an unconfirmed production run. Even with explicit
confirmation, this Foundation package does not make the Hub production-ready;
all configuration gates and subsequent phase tests still apply.
