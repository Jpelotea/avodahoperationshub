/**
 * Source-backed analytics for the Avodah Operations Hub.
 *
 * These functions read operational source databases and write only the derived
 * analytics/reporting tabs created by Foundation. Operational rows are never
 * changed by an analytics refresh.
 */

var AVODAH_ANALYTICS_SHEETS = Object.freeze([
  'Lead Analytics',
  'Recruitment Analytics',
  'Calendar and Booking Analytics',
  'Project 1 Performance Analytics'
]);

function assertAnalyticsWritesEnabled_() {
  var environment = getEnvironment_();
  if (AVODAH_CONFIG.ALLOWED_ENVIRONMENTS.indexOf(environment) === -1) {
    throw avodahError_('ENVIRONMENT_NOT_CONFIGURED',
      'Set ENVIRONMENT before refreshing analytics.');
  }
  var enabled = PropertiesService.getScriptProperties()
    .getProperty('ENABLE_ANALYTICS_WRITES');
  if (!truthy_(enabled)) {
    throw avodahError_('ANALYTICS_WRITES_DISABLED',
      'Set ENABLE_ANALYTICS_WRITES=TRUE only for a controlled refresh.');
  }
  return environment;
}

function refreshAnalyticsDashboard() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  return refreshAllAnalytics_();
}

function refreshAllAnalytics_() {
  var environment = assertAnalyticsWritesEnabled_();
  return withScriptLock_('analytics-refresh', function() {
    var startedAt = new Date();
    var snapshot = buildAnalyticsSnapshot_(startedAt);
    var written = 0;

    written += replaceDerivedRows_('Lead Analytics', snapshot.leads.metricRows, 4);
    written += replaceDerivedRows_('Recruitment Analytics',
      snapshot.recruitment.metricRows, 4);
    written += replaceDerivedRows_('Calendar and Booking Analytics',
      snapshot.bookings.metricRows, 4);
    written += replaceDerivedRows_('Project 1 Performance Analytics',
      snapshot.project1.metricRows, 4);
    written += upsertMonthlySnapshot_(snapshot);
    written += writeReportsRegistry_(snapshot);

    var dashboard = refreshDashboard_(snapshot);
    written += Number(dashboard.cellsWritten || 0);

    var result = {
      code: 'ANALYTICS_REFRESHED',
      environment: environment,
      asOf: snapshot.asOfIso,
      recordsRead: snapshot.recordsRead,
      recordsWritten: written,
      analyticsRows: {
        leads: snapshot.leads.metricRows.length,
        recruitment: snapshot.recruitment.metricRows.length,
        bookings: snapshot.bookings.metricRows.length,
        project1: snapshot.project1.metricRows.length
      },
      dashboardRange: dashboard.range
    };
    logAuditEvent_({
      action: 'ANALYTICS_REFRESH',
      entityType: 'DERIVED_REPORTING',
      entityId: snapshot.monthKey,
      result: 'SUCCESS',
      details: result
    });
    return result;
  });
}

function getManagementDashboardData() {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var snapshot = buildAnalyticsSnapshot_(new Date());
  return {
    asOf: snapshot.asOfIso,
    month: snapshot.monthKey,
    cards: {
      totalLeads: snapshot.leads.cards.totalLeads,
      activeApplicants: snapshot.recruitment.cards.activeApplicants,
      activeBookings: snapshot.bookings.cards.activeBookings,
      project1PointsThisMonth: snapshot.project1.cards.currentMonthPoints
    },
    breakdowns: {
      leadStatus: snapshot.leads.breakdowns.status,
      recruitmentStage: snapshot.recruitment.breakdowns.stage,
      bookingStatus: snapshot.bookings.breakdowns.status,
      project1PointsByType: snapshot.project1.breakdowns.pointsByType
    }
  };
}

function buildAnalyticsSnapshot_(asOf) {
  var generatedAt = asOf instanceof Date ? new Date(asOf.getTime()) : new Date();
  var source = {
    leads: analyticsSourceRecords_('Lead Database', ['Lead ID']),
    applicants: analyticsSourceRecords_('Applicant Tracking', ['Applicant ID']),
    bookings: analyticsSourceRecords_('Booking Database', ['Booking ID']),
    calendar: analyticsSourceRecords_('Calendar Log', ['Calendar Log ID', 'Event ID']),
    project1: analyticsSourceRecords_('Project 1 Activity Database', ['Activity ID'])
  };
  var snapshot = {
    asOf: generatedAt,
    asOfIso: Utilities.formatDate(generatedAt, AVODAH_CONFIG.TIME_ZONE,
      "yyyy-MM-dd'T'HH:mm:ssXXX"),
    monthKey: Utilities.formatDate(generatedAt, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM'),
    leads: buildLeadAnalyticsCore_(source.leads, generatedAt),
    recruitment: buildRecruitmentAnalyticsCore_(source.applicants, generatedAt),
    bookings: buildBookingAnalyticsCore_(source.bookings, source.calendar, generatedAt),
    project1: buildProject1AnalyticsCore_(source.project1, generatedAt)
  };
  snapshot.recordsRead = source.leads.length + source.applicants.length +
    source.bookings.length + source.calendar.length + source.project1.length;
  return snapshot;
}

function analyticsSourceRecords_(logicalName, idHeaders) {
  return getObjectRows_(logicalName).map(function(item) {
    return item.record;
  }).filter(function(record) {
    return (idHeaders || []).some(function(header) {
      return analyticsText_(analyticsValue_(record, [header])) !== '';
    });
  });
}

function buildLeadAnalyticsCore_(rows, asOf) {
  var records = (rows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record, ['Lead ID'])) !== '';
  });
  var active = records.filter(function(record) {
    return !analyticsIsInactiveRecord_(record);
  });
  var inquiries = records.reduce(function(total, record) {
    var count = analyticsNumber_(analyticsValue_(record, ['Inquiry Count']));
    return total + Math.max(count || 1, 1);
  }, 0);
  var repeat = records.filter(function(record) {
    return analyticsNumber_(analyticsValue_(record, ['Inquiry Count'])) > 1;
  }).length;
  var booked = records.filter(function(record) {
    return analyticsText_(analyticsValue_(record, ['Booking ID'])) !== '';
  }).length;
  var status = analyticsCountBy_(active, ['Lead Status'], 'Unspecified');
  var needs = analyticsCountBy_(active, ['Primary Need'], 'Unspecified');
  var metricRows = [
    analyticsMetricRow_('Lead Count', 'All', records.length, asOf),
    analyticsMetricRow_('Lead Count', 'Active', active.length, asOf),
    analyticsMetricRow_('Inquiry Count', 'All', inquiries, asOf),
    analyticsMetricRow_('Lead Count', 'Repeat Inquiry', repeat, asOf),
    analyticsMetricRow_('Lead Count', 'With Booking', booked, asOf),
    analyticsMetricRow_('Booking Coverage Rate', 'All Leads',
      analyticsRate_(booked, records.length), asOf),
    analyticsMetricRow_('Repeat Inquiry Rate', 'All Leads',
      analyticsRate_(repeat, records.length), asOf)
  ];
  analyticsAppendBreakdownRows_(metricRows, 'Lead Status Count', status, asOf);
  analyticsAppendBreakdownRows_(metricRows, 'Primary Need Count', needs, asOf);
  return {
    metricRows: metricRows,
    cards: {
      totalLeads: records.length,
      activeLeads: active.length,
      repeatInquiryLeads: repeat,
      bookedLeads: booked
    },
    breakdowns: {status: status, primaryNeed: needs}
  };
}

function buildRecruitmentAnalyticsCore_(rows, asOf) {
  var records = (rows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record, ['Applicant ID'])) !== '';
  });
  var active = records.filter(function(record) {
    return !analyticsIsInactiveRecord_(record);
  });
  var hired = analyticsCountMatching_(records, ['Current Status'], ['HIRED']);
  var noShow = analyticsCountMatching_(records, ['Current Status'], ['NO SHOW', 'NO_SHOW']);
  var requirementsComplete = analyticsCountMatching_(records,
    ['Requirements Status'], ['COMPLETE', 'COMPLETED']);
  var onboardingComplete = analyticsCountMatching_(records,
    ['Onboarding Status'], ['COMPLETE', 'COMPLETED']);
  var stage = analyticsCountBy_(active, ['Current Stage'], 'Unspecified');
  var status = analyticsCountBy_(active, ['Current Status'], 'Unspecified');
  var metricRows = [
    analyticsMetricRow_('Applicant Count', 'All', records.length, asOf),
    analyticsMetricRow_('Applicant Count', 'Active', active.length, asOf),
    analyticsMetricRow_('Applicant Count', 'Hired', hired, asOf),
    analyticsMetricRow_('Applicant Count', 'No Show', noShow, asOf),
    analyticsMetricRow_('Applicant Count', 'Requirements Complete',
      requirementsComplete, asOf),
    analyticsMetricRow_('Applicant Count', 'Onboarding Complete',
      onboardingComplete, asOf),
    analyticsMetricRow_('Requirements Completion Rate', 'All Applicants',
      analyticsRate_(requirementsComplete, records.length), asOf),
    analyticsMetricRow_('Onboarding Completion Rate', 'All Applicants',
      analyticsRate_(onboardingComplete, records.length), asOf)
  ];
  analyticsAppendBreakdownRows_(metricRows, 'Pipeline Stage Count', stage, asOf);
  analyticsAppendBreakdownRows_(metricRows, 'Recruitment Status Count', status, asOf);
  return {
    metricRows: metricRows,
    cards: {
      totalApplicants: records.length,
      activeApplicants: active.length,
      hiredApplicants: hired,
      noShowApplicants: noShow
    },
    breakdowns: {stage: stage, status: status}
  };
}

function buildBookingAnalyticsCore_(bookingRows, calendarRows, asOf) {
  var bookings = (bookingRows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record, ['Booking ID'])) !== '';
  });
  var activeStatuses = ['SCHEDULED', 'CONFIRMED', 'RESCHEDULED'];
  var activeBookings = bookings.filter(function(record) {
    return !analyticsIsInactiveRecord_(record) &&
      activeStatuses.indexOf(analyticsKey_(analyticsValue_(record, ['Status']))) !== -1;
  }).length;
  var cancelled = analyticsCountMatching_(bookings, ['Status'], ['CANCELLED']);
  var completed = analyticsCountMatching_(bookings, ['Status'], ['COMPLETED']);
  var withEvent = analyticsCountPresent_(bookings, ['Google Event ID']);
  var withMeet = analyticsCountPresent_(bookings, ['Meet Link']);
  var reconciliationIssues = bookings.filter(function(record) {
    var value = analyticsKey_(analyticsValue_(record, ['Reconciliation Status']));
    return value && ['OK', 'MATCHED', 'SYNCED'].indexOf(value) === -1;
  }).length;
  var bookingStatus = analyticsCountBy_(bookings, ['Status'], 'Unspecified');

  var calendar = (calendarRows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record,
      ['Calendar Log ID', 'Event ID', 'Google Event ID'])) !== '';
  });
  var activeCalendar = calendar.filter(function(record) {
    return !analyticsIsInactiveRecord_(record) &&
      analyticsKey_(analyticsValue_(record, ['Status'])) !== 'CANCELLED';
  }).length;
  var syncIssues = calendar.filter(function(record) {
    var value = analyticsKey_(analyticsValue_(record, ['Sync Status']));
    return value && ['OK', 'SYNCED', 'MATCHED'].indexOf(value) === -1;
  }).length;

  var metricRows = [
    analyticsMetricRow_('Booking Count', 'All', bookings.length, asOf),
    analyticsMetricRow_('Booking Count', 'Active', activeBookings, asOf),
    analyticsMetricRow_('Booking Count', 'Cancelled', cancelled, asOf),
    analyticsMetricRow_('Booking Count', 'Completed', completed, asOf),
    analyticsMetricRow_('Booking Count', 'With Calendar Event', withEvent, asOf),
    analyticsMetricRow_('Booking Count', 'With Google Meet', withMeet, asOf),
    analyticsMetricRow_('Calendar Event Coverage Rate', 'All Bookings',
      analyticsRate_(withEvent, bookings.length), asOf),
    analyticsMetricRow_('Google Meet Coverage Rate', 'All Bookings',
      analyticsRate_(withMeet, bookings.length), asOf),
    analyticsMetricRow_('Reconciliation Issue Count', 'All Bookings',
      reconciliationIssues, asOf),
    analyticsMetricRow_('Calendar Log Record Count', 'All', calendar.length, asOf),
    analyticsMetricRow_('Calendar Log Record Count', 'Active', activeCalendar, asOf),
    analyticsMetricRow_('Calendar Sync Issue Count', 'All', syncIssues, asOf)
  ];
  analyticsAppendBreakdownRows_(metricRows, 'Booking Status Count', bookingStatus, asOf);
  return {
    metricRows: metricRows,
    cards: {
      totalBookings: bookings.length,
      activeBookings: activeBookings,
      reconciliationIssues: reconciliationIssues,
      calendarRecords: calendar.length
    },
    breakdowns: {status: bookingStatus}
  };
}

function buildProject1AnalyticsCore_(rows, asOf) {
  var records = (rows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record, ['Activity ID'])) !== '';
  });
  var active = records.filter(function(record) {
    var status = analyticsKey_(analyticsValue_(record, ['Record Status']));
    return ['VOID', 'INACTIVE', 'ARCHIVED'].indexOf(status) === -1;
  });
  var monthKey = Utilities.formatDate(asOf, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
  var currentMonth = active.filter(function(record) {
    return analyticsRecordMonth_(record) === monthKey;
  });
  var duplicateWarnings = active.filter(function(record) {
    var value = analyticsKey_(analyticsValue_(record, ['Duplicate Status']));
    return value && value !== 'UNIQUE' && value.indexOf('DUPLICATE') !== -1;
  }).length;
  var totalPoints = analyticsSum_(active, ['Points']);
  var currentMonthPoints = analyticsSum_(currentMonth, ['Points']);
  var typeCount = analyticsCountBy_(active, ['Activity Type'], 'Unspecified');
  var pointsByType = analyticsSumBy_(active, ['Activity Type'], ['Points'],
    'Unspecified');
  var statusSummary = analyticsCountBy_(active, ['Status Summary'], 'Unspecified');
  var metricRows = [
    analyticsMetricRow_('Activity Count', 'All Active', active.length, asOf),
    analyticsMetricRow_('Points', 'All Active', totalPoints, asOf),
    analyticsMetricRow_('Activity Count', monthKey, currentMonth.length, asOf),
    analyticsMetricRow_('Points', monthKey, currentMonthPoints, asOf),
    analyticsMetricRow_('Duplicate Warning Count', 'All Active',
      duplicateWarnings, asOf)
  ];
  analyticsAppendBreakdownRows_(metricRows, 'Activity Type Count', typeCount, asOf);
  analyticsAppendBreakdownRows_(metricRows, 'Activity Type Points', pointsByType, asOf);
  analyticsAppendBreakdownRows_(metricRows, 'Activity Status Count', statusSummary, asOf);
  return {
    metricRows: metricRows,
    cards: {
      totalActivities: active.length,
      totalPoints: totalPoints,
      currentMonthActivities: currentMonth.length,
      currentMonthPoints: currentMonthPoints,
      duplicateWarnings: duplicateWarnings
    },
    breakdowns: {
      activityType: typeCount,
      pointsByType: pointsByType,
      status: statusSummary
    }
  };
}

function replaceDerivedRows_(logicalName, rows, width) {
  var context = getTableContext_(logicalName);
  var sheet = context.sheet;
  var columns = Number(width || context.headers.length);
  if (sheet.getLastRow() > 1) {
    sheet.getRange(2, 1, sheet.getLastRow() - 1, columns).clearContent();
  }
  if (rows.length) {
    sheet.getRange(2, 1, rows.length, columns).setValues(rows);
    sheet.getRange(2, columns, rows.length, 1)
      .setNumberFormat('yyyy-mm-dd hh:mm:ss');
  }
  formatDerivedRows_(logicalName, sheet, rows, columns);
  ensureDerivedSheetWarning_(sheet, 'AVODAH_DERIVED_' + logicalName);
  return rows.length;
}

function upsertMonthlySnapshot_(snapshot) {
  var context = getTableContext_('Monthly Reports');
  var existing = getObjectRows_('Monthly Reports').map(function(item) {
    return item.record;
  }).filter(function(record) {
    return analyticsMonthCellKey_(record['Snapshot Month']) !== snapshot.monthKey;
  }).map(function(record) {
    return [record['Snapshot Month'], record['Metric'], record['Dimension'],
      record['Value'], record['Generated At']];
  });
  var current = [];
  [
    ['Leads', snapshot.leads.metricRows],
    ['Recruitment', snapshot.recruitment.metricRows],
    ['Calendar and Booking', snapshot.bookings.metricRows],
    ['Project 1', snapshot.project1.metricRows]
  ].forEach(function(module) {
    module[1].forEach(function(row) {
      current.push([snapshot.monthKey, module[0] + ' / ' + row[0], row[1], row[2],
        snapshot.asOf]);
    });
  });
  var rows = existing.concat(current);
  var sheet = context.sheet;
  if (sheet.getLastRow() > 1) {
    sheet.getRange(2, 1, sheet.getLastRow() - 1, 5).clearContent();
  }
  if (rows.length) {
    sheet.getRange(2, 1, rows.length, 5).setValues(rows);
    sheet.getRange(2, 5, rows.length, 1).setNumberFormat('yyyy-mm-dd hh:mm:ss');
  }
  formatMonthlyRows_(sheet, rows);
  ensureDerivedSheetWarning_(sheet, 'AVODAH_DERIVED_MONTHLY_REPORTS');
  return rows.length;
}

function writeReportsRegistry_(snapshot) {
  var rows = [
    ['DAILY_REPORT', 'Daily Report',
      Utilities.formatDate(snapshot.asOf, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM-dd'),
      'PRESERVED - LIVE FORMULAS', snapshot.asOf],
    ['WEEKLY_REPORT', 'Weekly Report',
      Utilities.formatDate(reportingWeekStart_(snapshot.asOf),
        AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM-dd'),
      'PRESERVED - LIVE FORMULAS', snapshot.asOf],
    ['MONTHLY_REPORT', 'Monthly Reports', snapshot.monthKey, 'REFRESHED', snapshot.asOf],
    ['LEAD_ANALYTICS', 'Lead Analytics', 'CURRENT', 'REFRESHED', snapshot.asOf],
    ['RECRUITMENT_ANALYTICS', 'Recruitment Analytics', 'CURRENT', 'REFRESHED',
      snapshot.asOf],
    ['BOOKING_ANALYTICS', 'Calendar and Booking Analytics', 'CURRENT', 'REFRESHED',
      snapshot.asOf],
    ['PROJECT1_ANALYTICS', 'Project 1 Performance Analytics', 'CURRENT',
      'REFRESHED', snapshot.asOf],
    ['MANAGEMENT_DASHBOARD', 'Management Dashboard', 'CURRENT', 'REFRESHED',
      snapshot.asOf]
  ];
  return replaceDerivedRows_('Reports and Analytics', rows, 5);
}

function ensureDerivedSheetWarning_(sheet, description) {
  try {
    var existing = sheet.getProtections(SpreadsheetApp.ProtectionType.SHEET)
      .some(function(protection) {
        return protection.getDescription() === description;
      });
    if (!existing) {
      var protection = sheet.protect();
      protection.setDescription(description);
      protection.setWarningOnly(true);
    }
  } catch (error) {
    console.warn('Derived-sheet warning protection unavailable: ' + String(error));
  }
}

function formatDerivedRows_(logicalName, sheet, rows, columns) {
  if (!rows.length) return;
  var data = sheet.getRange(2, 1, rows.length, columns);
  data.setWrap(true).setVerticalAlignment('middle');
  if (columns === 4) {
    sheet.setColumnWidth(1, 230);
    sheet.setColumnWidth(2, 300);
    sheet.setColumnWidth(3, 110);
    sheet.setColumnWidth(4, 170);
    sheet.getRange(2, 3, rows.length, 1).setNumberFormat('0.##');
    rows.forEach(function(row, index) {
      if (/rate$/i.test(analyticsText_(row[0]))) {
        sheet.getRange(index + 2, 3).setNumberFormat('0.0%');
      }
    });
  } else if (logicalName === 'Reports and Analytics') {
    [170, 250, 150, 220, 170].forEach(function(width, index) {
      sheet.setColumnWidth(index + 1, width);
    });
  }
  sheet.autoResizeRows(2, rows.length);
}

function formatMonthlyRows_(sheet, rows) {
  if (!rows.length) return;
  sheet.getRange(2, 1, rows.length, 5).setWrap(true)
    .setVerticalAlignment('middle');
  [110, 320, 260, 110, 170].forEach(function(width, index) {
    sheet.setColumnWidth(index + 1, width);
  });
  sheet.getRange(2, 4, rows.length, 1).setNumberFormat('0.##');
  rows.forEach(function(row, index) {
    if (/rate$/i.test(analyticsText_(row[1]))) {
      sheet.getRange(index + 2, 4).setNumberFormat('0.0%');
    }
  });
  sheet.autoResizeRows(2, rows.length);
}

function analyticsValue_(record, headers) {
  var source = record || {};
  for (var i = 0; i < (headers || []).length; i += 1) {
    var wanted = normalizeHeader_(headers[i]);
    var keys = Object.keys(source);
    for (var j = 0; j < keys.length; j += 1) {
      if (normalizeHeader_(keys[j]) === wanted) return source[keys[j]];
    }
  }
  return '';
}

function analyticsText_(value) {
  return String(value == null ? '' : value).trim();
}

function analyticsKey_(value) {
  return analyticsText_(value).replace(/[_-]+/g, ' ').replace(/\s+/g, ' ')
    .toUpperCase();
}

function analyticsNumber_(value) {
  if (typeof value === 'number' && isFinite(value)) return value;
  var parsed = Number(String(value == null ? '' : value).replace(/,/g, ''));
  return isFinite(parsed) ? parsed : 0;
}

function analyticsRate_(numerator, denominator) {
  return denominator ? Number(numerator || 0) / Number(denominator) : 0;
}

function analyticsIsInactiveRecord_(record) {
  var value = analyticsKey_(analyticsValue_(record, ['Record Status']));
  return ['INACTIVE', 'ARCHIVED', 'VOID', 'DELETED'].indexOf(value) !== -1;
}

function analyticsCountPresent_(rows, headers) {
  return (rows || []).filter(function(record) {
    return analyticsText_(analyticsValue_(record, headers)) !== '';
  }).length;
}

function analyticsCountMatching_(rows, headers, allowed) {
  var wanted = (allowed || []).map(analyticsKey_);
  return (rows || []).filter(function(record) {
    return wanted.indexOf(analyticsKey_(analyticsValue_(record, headers))) !== -1;
  }).length;
}

function analyticsCountBy_(rows, headers, blankLabel) {
  var counts = {};
  (rows || []).forEach(function(record) {
    var label = analyticsText_(analyticsValue_(record, headers)) || blankLabel || 'Unspecified';
    counts[label] = Number(counts[label] || 0) + 1;
  });
  return analyticsMapToRows_(counts);
}

function analyticsSumBy_(rows, groupHeaders, valueHeaders, blankLabel) {
  var totals = {};
  (rows || []).forEach(function(record) {
    var label = analyticsText_(analyticsValue_(record, groupHeaders)) ||
      blankLabel || 'Unspecified';
    totals[label] = Number(totals[label] || 0) +
      analyticsNumber_(analyticsValue_(record, valueHeaders));
  });
  return analyticsMapToRows_(totals);
}

function analyticsMapToRows_(map) {
  return Object.keys(map || {}).sort(function(a, b) {
    return a.localeCompare(b);
  }).map(function(key) {
    return {dimension: key, value: map[key]};
  });
}

function analyticsSum_(rows, headers) {
  return (rows || []).reduce(function(total, record) {
    return total + analyticsNumber_(analyticsValue_(record, headers));
  }, 0);
}

function analyticsMetricRow_(metric, dimension, value, asOf) {
  return [metric, dimension, value, asOf];
}

function analyticsAppendBreakdownRows_(destination, metric, breakdown, asOf) {
  (breakdown || []).forEach(function(item) {
    destination.push(analyticsMetricRow_(metric, item.dimension, item.value, asOf));
  });
}

function analyticsRecordMonth_(record) {
  var reportingMonth = analyticsValue_(record, ['Reporting Month']);
  var key = analyticsMonthCellKey_(reportingMonth);
  if (key) return key;
  var date = analyticsValue_(record, ['Activity Date']);
  if (!(date instanceof Date) || isNaN(date.getTime())) {
    date = new Date(date);
  }
  return date instanceof Date && !isNaN(date.getTime())
    ? Utilities.formatDate(date, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM') : '';
}

function analyticsMonthCellKey_(value) {
  if (value instanceof Date && !isNaN(value.getTime())) {
    return Utilities.formatDate(value, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM');
  }
  var text = analyticsText_(value);
  var match = text.match(/^(\d{4})[-\/]?(\d{2})/);
  return match ? match[1] + '-' + match[2] : '';
}

function runAnalyticsValidationTests() {
  var tests = [];
  var now = new Date('2026-07-22T10:00:00+08:00');
  var leads = buildLeadAnalyticsCore_([
    {'Lead ID': 'L1', 'Inquiry Count': 1, 'Lead Status': 'New',
      'Record Status': 'ACTIVE'},
    {'Lead ID': 'L2', 'Inquiry Count': 3, 'Lead Status': 'Booked',
      'Booking ID': 'B1', 'Record Status': 'ACTIVE'},
    {'Lead ID': 'L3', 'Inquiry Count': 1, 'Lead Status': 'Closed',
      'Record Status': 'ARCHIVED'}
  ], now);
  analyticsTestAssert_(tests, 'lead totals include historical records',
    leads.cards.totalLeads === 3);
  analyticsTestAssert_(tests, 'active lead count excludes archived records',
    leads.cards.activeLeads === 2);
  analyticsTestAssert_(tests, 'repeat inquiry count uses Inquiry Count',
    leads.cards.repeatInquiryLeads === 1);

  var recruitment = buildRecruitmentAnalyticsCore_([
    {'Applicant ID': 'A1', 'Current Stage': 'Screening', 'Current Status': 'New',
      'Record Status': 'ACTIVE'},
    {'Applicant ID': 'A2', 'Current Stage': 'Closed', 'Current Status': 'Hired',
      'Requirements Status': 'Complete', 'Onboarding Status': 'Completed',
      'Record Status': 'ACTIVE'}
  ], now);
  analyticsTestAssert_(tests, 'recruitment keeps stage and status separate',
    recruitment.breakdowns.stage.length === 2 &&
      recruitment.breakdowns.status.length === 2);
  analyticsTestAssert_(tests, 'hired applicant count is status-based',
    recruitment.cards.hiredApplicants === 1);

  var bookings = buildBookingAnalyticsCore_([
    {'Booking ID': 'B1', 'Status': 'Scheduled', 'Google Event ID': 'E1',
      'Meet Link': 'https://meet.google.com/test', 'Reconciliation Status': 'OK'},
    {'Booking ID': 'B2', 'Status': 'Cancelled', 'Reconciliation Status': 'ERROR'}
  ], [{'Event ID': 'E1', 'Status': 'Scheduled'}], now);
  analyticsTestAssert_(tests, 'active booking rules exclude cancelled records',
    bookings.cards.activeBookings === 1);
  analyticsTestAssert_(tests, 'booking reconciliation issues are surfaced',
    bookings.cards.reconciliationIssues === 1);

  var project1 = buildProject1AnalyticsCore_([
    {'Activity ID': 'P1', 'Activity Date': now, 'Activity Type': 'Sales',
      'Points': 2, 'Duplicate Status': 'UNIQUE', 'Record Status': 'ACTIVE'},
    {'Activity ID': 'P2', 'Activity Date': now, 'Activity Type': 'Recruitment',
      'Points': 3, 'Duplicate Status': 'POSSIBLE DUPLICATE', 'Record Status': 'ACTIVE'},
    {'Activity ID': 'P3', 'Activity Date': now, 'Activity Type': 'Sales',
      'Points': 100, 'Record Status': 'VOID'}
  ], now);
  analyticsTestAssert_(tests, 'Project 1 totals exclude void activities',
    project1.cards.totalActivities === 2 && project1.cards.totalPoints === 5);
  analyticsTestAssert_(tests, 'Project 1 current-month points are grouped',
    project1.cards.currentMonthPoints === 5 &&
      project1.breakdowns.pointsByType.length === 2);

  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(result));
  return result;
}

function analyticsTestAssert_(tests, name, condition) {
  tests.push({name: name, passed: condition === true});
}

function runAnalyticsTestTransaction() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  if (getEnvironment_() !== 'TEST') {
    throw avodahError_('TEST_ENVIRONMENT_REQUIRED',
      'Analytics transaction tests run only in TEST.');
  }
  assertAnalyticsWritesEnabled_();
  var tests = [];
  var sourceBefore = analyticsSourceFingerprint_();
  var legacyBefore = analyticsLegacyFingerprint_();
  var first = refreshAllAnalytics_();
  var firstSignature = analyticsDerivedSignature_();
  var second = refreshAllAnalytics_();
  var secondSignature = analyticsDerivedSignature_();
  var sourceAfter = analyticsSourceFingerprint_();
  var legacyAfter = analyticsLegacyFingerprint_();
  var snapshot = buildAnalyticsSnapshot_(new Date());

  analyticsTestAssert_(tests, 'operational source values remain unchanged',
    sourceBefore === sourceAfter);
  analyticsTestAssert_(tests, 'legacy Dashboard and report formulas remain unchanged',
    legacyBefore === legacyAfter);
  analyticsTestAssert_(tests, 'repeat refresh is idempotent excluding freshness timestamps',
    firstSignature === secondSignature);
  analyticsTestAssert_(tests, 'lead analytics rows match the source-backed model',
    first.analyticsRows.leads === snapshot.leads.metricRows.length);
  analyticsTestAssert_(tests, 'recruitment analytics rows match the source-backed model',
    first.analyticsRows.recruitment === snapshot.recruitment.metricRows.length);
  analyticsTestAssert_(tests, 'booking analytics rows match the source-backed model',
    first.analyticsRows.bookings === snapshot.bookings.metricRows.length);
  analyticsTestAssert_(tests, 'Project 1 analytics rows match the source-backed model',
    first.analyticsRows.project1 === snapshot.project1.metricRows.length);
  analyticsTestAssert_(tests, 'second refresh completed in TEST',
    second.code === 'ANALYTICS_REFRESHED' && second.environment === 'TEST');
  analyticsTestAssert_(tests, 'monthly snapshot has no duplicate metric keys',
    analyticsMonthlySnapshotKeysAreUnique_(snapshot.monthKey));

  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {
    passed: failures.length === 0,
    tests: tests,
    failures: failures,
    refresh: second
  };
  logAuditEvent_({
    action: 'ANALYTICS_TEST_TRANSACTION',
    entityType: 'DERIVED_REPORTING',
    entityId: snapshot.monthKey,
    result: result.passed ? 'SUCCESS' : 'FAILED',
    details: {tests: tests}
  });
  console.log(JSON.stringify(result));
  return result;
}

function analyticsSourceFingerprint_() {
  return analyticsFingerprintRanges_([
    ['Lead Database', null],
    ['Applicant Tracking', null],
    ['Booking Database', null],
    ['Calendar Log', null],
    ['Project 1 Activity Database', null]
  ]);
}

function analyticsLegacyFingerprint_() {
  return analyticsFingerprintRanges_([
    ['Management Dashboard', 'A1:K17'],
    ['Daily Report', 'A1:I20'],
    ['Weekly Report', 'A1:I20']
  ]);
}

function analyticsFingerprintRanges_(definitions) {
  var spreadsheet = getHubSpreadsheet_();
  var values = (definitions || []).map(function(item) {
    var definition = getSheetDefinition_(item[0]);
    var sheet = definition ? findSheetForDefinition_(spreadsheet, definition) :
      spreadsheet.getSheetByName(item[0]);
    if (!sheet) return {name: item[0], missing: true};
    var range = item[1] ? sheet.getRange(item[1]) : sheet.getDataRange();
    return {
      name: sheet.getName(),
      formulas: range.getFormulas(),
      values: range.getDisplayValues()
    };
  });
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    JSON.stringify(values), Utilities.Charset.UTF_8);
  return bytes.map(function(value) {
    var unsigned = value < 0 ? value + 256 : value;
    return ('0' + unsigned.toString(16)).slice(-2);
  }).join('');
}

function analyticsDerivedSignature_() {
  var definitions = AVODAH_ANALYTICS_SHEETS.map(function(name) {
    return [name, 'A2:C200'];
  }).concat([
    ['Monthly Reports', 'A2:D500'],
    ['Reports and Analytics', 'A2:D20'],
    ['Management Dashboard', 'A48:L69']
  ]);
  return analyticsFingerprintRanges_(definitions);
}

function analyticsMonthlySnapshotKeysAreUnique_(monthKey) {
  var seen = {};
  var rows = getObjectRows_('Monthly Reports').map(function(item) {
    return item.record;
  }).filter(function(record) {
    return analyticsMonthCellKey_(record['Snapshot Month']) === monthKey;
  });
  return rows.every(function(record) {
    var key = analyticsText_(record['Metric']) + '|' +
      analyticsText_(record['Dimension']);
    if (seen[key]) return false;
    seen[key] = true;
    return true;
  });
}
