# TEST Script Properties

Add these under Apps Script **Project Settings → Script Properties** before
running any function. Values marked `USER INPUT` must be confirmed; do not copy
sample identities, secrets, or calendar IDs into the project.

| Property | Initial TEST value | Purpose |
|---|---|---|
| `ENVIRONMENT` | `TEST` | Required by the TEST-only safety gate. |
| `AVODAH_SPREADSHEET_ID` | `1f8rZ8hVxMnrrFwnfezMhG1CklxDizdtC2IRvEnbC13s` | Copied TEST spreadsheet verified on 2026-07-22. |
| `CHRISTINE_CALENDAR_ID` | `USER INPUT` | Authoritative calendar. Confirm a safe TEST calendar before any write test. |
| `WEBHOOK_SECRET` | `USER INPUT` | Required shared secret for every existing V3 `doPost` action. |
| `WEBHOOK_SECRET_NEXT` | blank initially | Optional secret rotation slot. |
| `ADMIN_NOTIFICATION_EMAIL` | `USER INPUT` | General Foundation/admin notifications. |
| `BOOKING_ADMIN_ALERT_EMAIL` | blank or `USER INPUT` | Optional booking-specific override. |
| `BOOKING_MANAGEMENT_BASE_URL` | `USER INPUT` | Management page URL used in booking links. |
| `DEPLOYMENT_ID` | blank | Record only after a reviewed TEST deployment exists. |
| `PUBLIC_PORTAL_ENABLED` | `FALSE` | Foundation public UI remains inactive. |
| `ENABLE_AUTOMATION_TRIGGERS` | `FALSE` | Prevents Foundation trigger installation. |
| `ENABLE_CALENDAR_WRITES` | `FALSE` | Blocks calendar create/update/delete operations. |
| `ENABLE_BOOKING_WORKFLOW` | `FALSE` | Blocks Booking Registry and source-link writes. |
| `ENABLE_PROJECT1_WRITES` | `FALSE` | Blocks Project 1 activity submissions. |
| `ENABLE_RECRUITMENT_WRITES` | `FALSE` | Blocks applicant, interview, requirements, and onboarding writes. |
| `ENABLE_ANALYTICS_WRITES` | `FALSE` | Blocks derived analytics, monthly snapshot, registry, and dashboard writes. |

## Required confirmations before enabling writes

1. `CHRISTINE_CALENDAR_ID` points to the intended TEST calendar.
2. The deploying account can read and write that calendar.
3. No production calendar is being used for destructive test cases.
4. The spreadsheet name still begins with `TEST`.
5. `productionHealthCheck()` returns the expected spreadsheet, time zone, and
   calendar identity.
6. Enable only the module-specific gate required for the approved TEST case and
   restore it to `FALSE` immediately afterward.

Do not store the webhook secret in a sheet, source file, email, or this document.
