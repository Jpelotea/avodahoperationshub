/**
 * Avodah Operations Hub — Foundation configuration.
 *
 * This file contains no environment IDs, secrets, deployment IDs, or user
 * email assignments. Those values belong in Apps Script Properties and the
 * USER_ROLE settings rows created during activation.
 */
var AVODAH_CONFIG = Object.freeze({
  VERSION: '0.9.0-test-schedule-import',
  TIME_ZONE: 'Asia/Manila',
  SETTINGS_LOGICAL_NAME: 'Targets and Settings',
  SETTINGS_ALIASES: ['Targets & Settings'],
  SETTINGS_HEADERS: [
    'Group', 'Key', 'Value', 'Value Type', 'Active', 'Sort Order', 'Description'
  ],
  REQUIRED_SCRIPT_PROPERTIES: [
    'AVODAH_SPREADSHEET_ID',
    'CHRISTINE_CALENDAR_ID',
    'ENVIRONMENT',
    'WEBHOOK_SECRET'
  ],
  OPTIONAL_SCRIPT_PROPERTIES: [
    'ADMIN_NOTIFICATION_EMAIL',
    'BOOKING_ADMIN_ALERT_EMAIL',
    'BOOKING_MANAGEMENT_BASE_URL',
    'DEPLOYMENT_ID',
    'ENABLE_BOOKING_WORKFLOW',
    'ENABLE_PROJECT1_WRITES',
    'ENABLE_RECRUITMENT_WRITES',
    'ENABLE_ANALYTICS_WRITES',
    'ENABLE_SCHEDULE_IMPORT_WRITES',
    'ENABLE_CALENDAR_WRITES',
    'PUBLIC_PORTAL_ENABLED',
    'ENABLE_AUTOMATION_TRIGGERS',
    'WEBHOOK_SECRET_NEXT'
  ],
  ALLOWED_ENVIRONMENTS: ['TEST', 'STAGING', 'PRODUCTION'],
  ID_PREFIXES: Object.freeze({
    INTAKE: 'INT',
    LEAD: 'LEAD',
    BOOKING: 'BOOK',
    CALENDAR: 'CAL',
    APPLICANT: 'APP',
    PROJECT1: 'P1',
    ACTIVITY_LOG: 'LOG',
    AUTOMATION_LOG: 'AUTO',
    INTERVIEW: 'INTV',
    TIMELINE: 'TL'
  }),
  TRANSITIONAL_AUDIT_SHEET: 'Activity Audit Log',
  SHEET_DEFINITIONS: Object.freeze([
    {
      name: 'Intake Submissions',
      mode: 'TABLE',
      headers: [
        'Submission ID', 'Submitted At', 'Primary Need',
        'Recommended Service Path', 'Follow-up Question 1', 'Answer 1',
        'Follow-up Question 2', 'Answer 2', 'Consultation Requested',
        'Full Name', 'Mobile Number', 'Email Address', 'Location',
        'Preferred Contact Method', 'Preferred Schedule', 'Additional Notes',
        'Consent', 'Follow-up Status', 'Assigned To', 'Last Contacted',
        'Next Follow-up', 'Appointment Date', 'Outcome',
        'Submission Metadata', 'Form Source', 'Source Page', 'UTM Source',
        'UTM Medium', 'UTM Campaign', 'UTM Content', 'UTM Term',
        'Facebook Campaign ID', 'Facebook Ad Set ID', 'Facebook Ad ID',
        'FBCLID', 'Landing Page', 'Referrer', 'Intake ID',
        'Normalized Email', 'Normalized Phone', 'Lead ID', 'Duplicate Status',
        'Booking ID', 'Calendar Event ID', 'Processing Status',
        'Last Processed At'
      ]
    },
    {
      name: 'Lead Database',
      mode: 'TABLE',
      headers: [
        'Lead ID', 'Primary Intake ID', 'First Inquiry At', 'Latest Inquiry At',
        'Full Name', 'Email Address', 'Normalized Email', 'Mobile Number',
        'Normalized Phone', 'Location', 'Primary Need',
        'Recommended Service Path', 'Lead Source', 'Assigned To', 'Lead Status',
        'Follow-up Status', 'Last Contacted', 'Next Follow-up',
        'Appointment Date', 'Booking ID', 'Calendar Event ID',
        'Duplicate Status', 'Inquiry Count', 'Record Status', 'Created At',
        'Updated At', 'Created By', 'Updated By'
      ]
    },
    {
      name: 'Applicant Tracking',
      mode: 'TABLE',
      headers: [
        'Applicant ID', 'Applicant Name', 'Email', 'Normalized Email', 'Phone',
        'Normalized Phone', 'Location', 'Application Date', 'Source',
        'Resume File / Link', 'Current Stage', 'Current Status',
        'Screening Status', 'Recruiter Rating', 'Interview Status',
        'Initial Interview Date', 'Final Interview Date', 'Final Decision',
        'Requirements Status', 'Onboarding Status', 'Assigned Recruiter',
        'Recruiter Notes', 'Record Status', 'Created At', 'Updated At'
      ]
    },
    {
      name: 'Applicant Timeline',
      mode: 'TABLE',
      headers: [
        'Timeline ID', 'Applicant ID', 'Occurred At', 'Previous Stage',
        'New Stage', 'Previous Status', 'New Status', 'Reason', 'Notes',
        'Changed By'
      ]
    },
    {
      name: 'Interview Records',
      mode: 'TABLE',
      headers: [
        'Interview ID', 'Applicant ID', 'Interview Type', 'Scheduled Start',
        'Scheduled End', 'Interviewer', 'Calendar Event ID', 'Meet Link',
        'Interview Status', 'Communication Score', 'Customer Service Score',
        'Selling Background Score', 'Quota Experience Score',
        'Handling Objections Score', 'Appointment Strategy Score',
        'Overall Score', 'Interview Result', 'Interview Notes', 'Created At',
        'Updated At'
      ]
    },
    {
      name: 'Requirements Tracker',
      mode: 'TABLE',
      headers: [
        'Applicant ID', 'Requirement Key', 'Requirement Name', 'Status',
        'Submitted At', 'Verified At', 'Verified By', 'File / Link', 'Notes',
        'Updated At'
      ]
    },
    {
      name: 'Onboarding Tracker',
      mode: 'TABLE',
      headers: [
        'Applicant ID', 'Step Key', 'Step Name', 'Status', 'Due Date',
        'Completed At', 'Completed By', 'Evidence / Link', 'Notes', 'Updated At'
      ]
    },
    {
      name: 'Calendar Log',
      mode: 'TABLE',
      headers: [
        'Event ID', 'Owner', 'Date', 'Start Time', 'End Time', 'Activity Type',
        'Location / Link', 'Status', 'Notes', 'Reminder', 'Category',
        'Start DateTime', 'End DateTime', 'Google Event ID', 'Sync Status',
        'Last Synced', 'Sync Error', 'Record Status', 'Calendar Log ID',
        'Source Record Type', 'Source Record ID', 'Booking ID',
        'Idempotency Key', 'Created At', 'Updated At'
      ]
    },
    {
      name: 'Booking Database',
      aliases: ['Booking Registry'],
      mode: 'TABLE',
      headers: [
        'Booking ID', 'Lead ID', 'Intake ID', 'Management Token Hash',
        'Google Event ID', 'Status', 'Start', 'End', 'Meet Link',
        'Idempotency Key', 'Fingerprint', 'Client Name', 'Client Email',
        'Normalized Email', 'Client Phone', 'Normalized Phone',
        'Cancellation Reason', 'Created At', 'Updated At', 'Last Reconciled',
        'Reconciliation Status', 'Last Error', 'Calendar Binding',
        'Environment', 'Record Status', 'Source Version'
      ]
    },
    {
      name: 'Project 1 Activity Database',
      mode: 'TABLE',
      headers: [
        'Activity ID', 'Submission Timestamp', 'Activity Date', 'Agent Code',
        'Team Member', 'Activity Type', 'Sub-Activity', 'Points',
        'Required Data JSON', 'Proof URL', 'Duplicate Fingerprint',
        'Duplicate Status', 'Status Summary', 'Reporting Week',
        'Reporting Month', 'Record Status', 'Created By', 'Created At',
        'Updated At'
      ]
    },
    {name: 'Activity Log', mode: 'PRESERVE'},
    {
      name: 'Activity Audit Log',
      mode: 'TABLE',
      headers: [
        'Log ID', 'Occurred At', 'Actor Email', 'Actor Role', 'Action',
        'Entity Type', 'Entity ID', 'Result', 'Details JSON', 'Request ID'
      ]
    },
    {
      name: 'Automation Log',
      mode: 'TABLE',
      headers: [
        'Automation Log ID', 'Started At', 'Finished At', 'Handler',
        'Trigger UID', 'Environment', 'Status', 'Records Read',
        'Records Written', 'Error Code', 'Error Message', 'Details JSON'
      ]
    },
    {name: 'Daily Report', mode: 'PRESERVE_OR_DERIVED'},
    {name: 'Weekly Report', mode: 'PRESERVE_OR_DERIVED'},
    {
      name: 'Monthly Reports',
      mode: 'DERIVED',
      headers: ['Snapshot Month', 'Metric', 'Dimension', 'Value', 'Generated At']
    },
    {
      name: 'Lead Analytics',
      mode: 'DERIVED',
      headers: ['Metric', 'Dimension', 'Value', 'As Of']
    },
    {
      name: 'Recruitment Analytics',
      mode: 'DERIVED',
      headers: ['Metric', 'Dimension', 'Value', 'As Of']
    },
    {
      name: 'Calendar and Booking Analytics',
      mode: 'DERIVED',
      headers: ['Metric', 'Dimension', 'Value', 'As Of']
    },
    {
      name: 'Project 1 Performance Analytics',
      mode: 'DERIVED',
      headers: ['Metric', 'Dimension', 'Value', 'As Of']
    },
    {
      name: 'Reports and Analytics',
      mode: 'DERIVED',
      headers: ['Report Key', 'Report Name', 'Period', 'Status', 'Last Refreshed']
    },
    {name: 'Targets and Settings', aliases: ['Targets & Settings'], mode: 'SETTINGS'},
    {
      name: 'Schedule Import Preview',
      mode: 'TABLE',
      headers: [
        'Include?', 'Import Key', 'Date', 'Period', 'Start Time', 'End Time',
        'Activity Type', 'Title', 'Location / Link', 'Status', 'Reminder',
        'Category', 'Owner', 'Source Cell', 'Raw Text', 'Import Status',
        'Validation Errors', 'Committed At', 'Calendar Log ID'
      ]
    },
    {
      name: 'Management Dashboard',
      aliases: ['Dashboard'],
      mode: 'PRESERVE_OR_DERIVED'
    }
  ]),
  TRIGGER_DEFINITIONS: Object.freeze([
    {handler: 'runHourlyFollowUpChecks', type: 'HOURLY'},
    {handler: 'reconcileBookingRecords', type: 'HOURLY'},
    {handler: 'scheduledDashboardRefresh', type: 'EVERY_6_HOURS'},
    {handler: 'scheduledWeeklyReport', type: 'WEEKLY_MONDAY_7'},
    {handler: 'scheduledMonthlyReport', type: 'MONTHLY_DAY_1_7'}
  ])
});

var AVODAH_SETTING_SEEDS = Object.freeze([
  ['SYSTEM', 'TIME_ZONE', 'Asia/Manila', 'text', true, 10,
    'Authoritative script and spreadsheet timezone.'],
  ['SYSTEM', 'FOUNDATION_VERSION', '0.9.0-test-schedule-import', 'text', true, 20,
    'Last foundation schema version applied.'],
  ['BOOKING', 'MINIMUM_NOTICE_HOURS', '24', 'number', true, 10,
    'Minimum lead time before a consultation. Confirm before production.'],
  ['BOOKING', 'BOOKING_HORIZON_DAYS', '30', 'number', true, 20,
    'Maximum days into the future that can be booked.'],
  ['BOOKING', 'APPOINTMENT_MINUTES', '30', 'number', true, 30,
    'Default consultation duration.'],
  ['BOOKING', 'BUFFER_MINUTES', '30', 'number', true, 40,
    'Busy-slot buffer before and after a consultation.'],
  ['BOOKING', 'START_HOUR', '9', 'number', true, 50,
    'Earliest consultation start hour in the configured timezone.'],
  ['BOOKING', 'END_HOUR', '17', 'number', true, 60,
    'Latest consultation end hour in the configured timezone.'],
  ['BOOKING', 'DAYS_AVAILABLE', 'Mon,Tue,Wed,Thu,Fri,Sat,Sun', 'text', true, 70,
    'Allowed consultation weekdays. Migrated from the existing booking settings block.'],
  ['BOOKING', 'SLOT_INTERVAL_MINUTES', '60', 'number', true, 80,
    'Minutes between offered consultation start times.'],
  ['BOOKING', 'BUFFER_BEFORE_MINUTES', '30', 'number', true, 90,
    'Required free time before a consultation.'],
  ['BOOKING', 'BUFFER_AFTER_MINUTES', '30', 'number', true, 100,
    'Required free time after a consultation.'],
  ['BOOKING', 'EMAIL_REMINDER_MINUTES', '1440', 'number', true, 110,
    'Calendar email reminder lead time.'],
  ['BOOKING', 'POPUP_REMINDER_MINUTES', '60', 'number', true, 120,
    'Calendar popup reminder lead time.'],
  ['BOOKING', 'CREATE_GOOGLE_MEET', 'TRUE', 'boolean', true, 130,
    'Create a unique Google Meet conference for each consultation.'],
  ['BOOKING', 'SEND_GUEST_INVITES', 'FALSE', 'boolean', true, 140,
    'Disabled in TEST. Review explicitly before production guest notifications.'],
  ['REPORTING_WEEK', 'START_DAY', 'MONDAY', 'text', true, 10,
    'Reporting week start.'],
  ['ROLE', 'ADMIN', 'Operations Administrator', 'text', true, 10,
    'Full configuration, setup, reporting, and operational access.'],
  ['ROLE', 'MANAGER', 'Operations Manager', 'text', true, 20,
    'Operational and reporting access without secret configuration access.'],
  ['ROLE', 'STAFF', 'Operations Staff', 'text', true, 30,
    'Operational entry and assigned workflow access.'],
  ['ROLE', 'VIEWER', 'Read-only Viewer', 'text', true, 40,
    'Read-only internal reporting access.'],
  ['CALENDAR_STATUS', 'SCHEDULED', 'Scheduled', 'text', true, 10, ''],
  ['CALENDAR_STATUS', 'CONFIRMED', 'Confirmed', 'text', true, 20, ''],
  ['CALENDAR_STATUS', 'COMPLETED', 'Completed', 'text', true, 30, ''],
  ['CALENDAR_STATUS', 'RESCHEDULED', 'Rescheduled', 'text', true, 40, ''],
  ['CALENDAR_STATUS', 'CANCELLED', 'Cancelled', 'text', true, 50, ''],
  ['RECRUITMENT_STAGE', 'SCREENING', 'Screening', 'text', true, 10,
    'Derived from the current applicant screening workflow.'],
  ['RECRUITMENT_STAGE', 'INITIAL_INTERVIEW', 'Initial Interview', 'text', true, 20, ''],
  ['RECRUITMENT_STAGE', 'FINAL_INTERVIEW', 'Final Interview', 'text', true, 30, ''],
  ['RECRUITMENT_STAGE', 'REQUIREMENTS', 'Requirements', 'text', true, 40, ''],
  ['RECRUITMENT_STAGE', 'ONBOARDING', 'Onboarding', 'text', true, 50, ''],
  ['RECRUITMENT_STAGE', 'CLOSED', 'Closed', 'text', true, 60, ''],
  ['RECRUITMENT_STATUS', 'NEW', 'New', 'text', true, 10, ''],
  ['RECRUITMENT_STATUS', 'FOR_REVIEW', 'For Review', 'text', true, 20, ''],
  ['RECRUITMENT_STATUS', 'SHORTLISTED', 'Shortlisted', 'text', true, 30, ''],
  ['RECRUITMENT_STATUS', 'SCHEDULED', 'Scheduled', 'text', true, 40, ''],
  ['RECRUITMENT_STATUS', 'COMPLETED', 'Completed', 'text', true, 50, ''],
  ['RECRUITMENT_STATUS', 'NO_SHOW', 'No Show', 'text', true, 60,
    'Status only; never a duplicate pipeline stage.'],
  ['RECRUITMENT_STATUS', 'RESCHEDULED', 'Rescheduled', 'text', true, 70, ''],
  ['RECRUITMENT_STATUS', 'ON_HOLD', 'On Hold', 'text', true, 80, ''],
  ['RECRUITMENT_STATUS', 'REJECTED', 'Rejected', 'text', true, 90, ''],
  ['RECRUITMENT_STATUS', 'WITHDRAWN', 'Withdrawn', 'text', true, 100, ''],
  ['RECRUITMENT_STATUS', 'HIRED', 'Hired', 'text', true, 110, '']
  ,['INTERVIEW_TYPE', 'INITIAL', 'Initial Interview', 'text', true, 10,
    'Controlled interview type used by the recruitment workflow.']
  ,['INTERVIEW_TYPE', 'FINAL', 'Final Interview', 'text', true, 20,
    'Controlled interview type used by the recruitment workflow.']
  ,['INTERVIEW_STATUS', 'SCHEDULED', 'Scheduled', 'text', true, 10, '']
  ,['INTERVIEW_STATUS', 'COMPLETED', 'Completed', 'text', true, 20, '']
  ,['INTERVIEW_STATUS', 'NO_SHOW', 'No Show', 'text', true, 30,
    'Status only; the applicant remains in the same pipeline stage.']
  ,['INTERVIEW_STATUS', 'CANCELLED', 'Cancelled', 'text', true, 40, '']
  ,['INTERVIEW_RESULT', 'PROCEED', 'Proceed', 'text', true, 10, '']
  ,['INTERVIEW_RESULT', 'HOLD', 'Hold', 'text', true, 20, '']
  ,['INTERVIEW_RESULT', 'REJECT', 'Reject', 'text', true, 30, '']
  ,['REQUIREMENT_STATUS', 'NOT_STARTED', 'Not Started', 'text', true, 10, '']
  ,['REQUIREMENT_STATUS', 'SUBMITTED', 'Submitted', 'text', true, 20, '']
  ,['REQUIREMENT_STATUS', 'VERIFIED', 'Verified', 'text', true, 30, '']
  ,['REQUIREMENT_STATUS', 'REJECTED', 'Rejected', 'text', true, 40, '']
  ,['ONBOARDING_STATUS', 'NOT_STARTED', 'Not Started', 'text', true, 10, '']
  ,['ONBOARDING_STATUS', 'IN_PROGRESS', 'In Progress', 'text', true, 20, '']
  ,['ONBOARDING_STATUS', 'COMPLETED', 'Completed', 'text', true, 30, '']
  ,['ONBOARDING_STATUS', 'BLOCKED', 'Blocked', 'text', true, 40, '']
]);

var AVODAH_PROJECT1_ACTIVITY_SEEDS = Object.freeze([
  ['Recruitment', 'Listing of Prospect Recruit Name', 1, ['prospectRecruitName']],
  ['Recruitment', 'Call Out for Initial Interview', 1,
    ['prospectRecruitName', 'interviewDate', 'interviewTime']],
  ['Recruitment', 'Initial Interview Update', 2,
    ['prospectRecruitName', 'interviewDate', 'interviewStatus']],
  ['Recruitment', 'Interview Result Update', 2,
    ['prospectRecruitName', 'interviewResult']],
  ['Recruitment', 'Orientation Attendance', 2,
    ['prospectRecruitName', 'orientationDate', 'proofUrl']],
  ['Recruitment', 'Contract Signing', 2,
    ['prospectRecruitName', 'contractDate', 'proofUrl']],
  ['Recruitment', 'Coding', 3,
    ['prospectRecruitName', 'codingDate', 'proofUrl']],
  ['Recruitment', 'Licensing Exam', 3,
    ['prospectRecruitName', 'examDate', 'examResult']],
  ['Recruitment', 'Licensing', 5,
    ['prospectRecruitName', 'licenseDate', 'proofUrl']],
  ['Sales', 'Prospect Listing', 1, ['clientName']],
  ['Sales', 'Initial Contact / Call Out', 1,
    ['clientName', 'contactDate', 'contactResult']],
  ['Sales', 'FNA Conducted', 2, ['clientName', 'activityDate', 'proofUrl']],
  ['Sales', 'Proposal Presented', 2, ['clientName', 'activityDate', 'proofUrl']],
  ['Sales', 'Application Submitted', 3, ['clientName', 'activityDate', 'proofUrl']],
  ['Sales', 'Issued Policy', 5,
    ['clientName', 'issueDate', 'policyNumber', 'proofUrl']],
  ['Joint Field Coaching', 'Shadowing / Observation', 1,
    ['activityDate', 'advisorAssisted', 'proofUrl']],
  ['Joint Field Coaching', 'Co-Presentation', 2,
    ['activityDate', 'advisorAssisted', 'proofUrl']],
  ['Joint Field Coaching', 'Assisted Closing', 3,
    ['activityDate', 'advisorAssisted', 'proofUrl']]
]);
