# Avodah Operations Hub - TEST Schedule Import 0.9.0

This is the verified TEST package for the compatibility-first Avodah Operations
Hub foundation and the stabilized intake, lead, booking, Calendar, booking
reconciliation, Project 1, Recruitment, Analytics, and derived Management
Dashboard workflows, verified daily/weekly/monthly scheduled-reporting
callbacks, and the hardened Schedule Import preview/commit workflow.

## Current status

- Phase 1 foundation: verified.
- Phase 2 structure comparison: complete.
- Phase 3.1 Intake to Lead: complete and verified.
- Phase 3.2 Booking, Calendar, and reconciliation: complete and verified.
- Phase 3.3 Project 1 activity submission and points: complete and verified.
- Phase 3.4 Recruitment pipeline and interview workflows: complete and verified.
- Phase 3.5 Analytics and derived Management Dashboard: complete and verified.
- Phase 3.6 scheduled daily/weekly/monthly operations: callbacks complete and
  verified; clock triggers intentionally not installed.
- Phase 3.7 Schedule Import preview/commit: complete and verified in TEST;
  Calendar synchronization remains a separate later activation decision.
- Production spreadsheet: untouched.
- All operational and analytics write gates: disabled after testing.
- Automation triggers: disabled; none installed.
- Public/internal web-app deployment: not created.

## Schedule Import source-of-truth decision

- `Schedule Import` remains preserved pasted source material.
- `Schedule Import Preview` is a derived, replaceable review layer.
- `Calendar Log` remains the operational destination and is written by header,
  not by fragile column position.
- Google Calendar is not written directly by Schedule Import.
- Existing preview/commit menu entry points are preserved and delegate to the
  hardened modular workflow.

## Implemented Schedule Import behavior

- Expands actual merged ranges in memory without unmerging or changing source.
- Parses explicit ranges, single times, Google Meet links, and untimed items.
- Preserves broad AM/PM blocks as unchecked `Needs Review - Exact Time` rows
  without inventing exact times.
- Uses stable Import Keys plus normalized owner/date/start/title signatures.
- Rechecks duplicates under `LockService` immediately before Calendar Log write.
- Uses a separate `ENABLE_SCHEDULE_IMPORT_WRITES` gate; commit also requires
  `ENABLE_CALENDAR_WRITES` and ADMIN/MANAGER authorization.
- Writes complete Calendar Log identity, lineage, synchronization, and timestamp
  fields, then writes commit status back to preview.
- Rolls back new Calendar Log rows and preview status changes if commit fails.
- Keeps source, operational, audit, and derived layers distinct.

## Scheduled reporting source-of-truth decision

- `Daily Report` remains a live formula view anchored by `=TODAY()`.
- `Weekly Report` remains a live Monday-through-Friday formula view.
- `Monthly Reports`, the analytics tabs, `Reports and Analytics`, and the
  derived Dashboard block remain the only scheduled reporting write targets.
- `scheduledDashboardRefresh` is the documented six-hour refresh; no
  undocumented daily clock trigger was added.
- Weekly and monthly callbacks use the same locked, gated, source-backed
  analytics refresh and verify that legacy formulas did not change.
- Trigger definitions are validated before installation and remain
  de-duplicated. Installation still requires deliberate activation through
  `ENABLE_AUTOMATION_TRIGGERS=TRUE`.

## Analytics and Management Dashboard source-of-truth decision

- `Lead Database`, `Applicant Tracking`, `Booking Registry`, `Calendar Log`, and
  `Project 1 Activity Database` remain authoritative operational sources.
- `Lead Analytics`, `Recruitment Analytics`, `Calendar and Booking Analytics`,
  and `Project 1 Performance Analytics` are deterministic derived tables.
- `Monthly Reports` upserts the current `YYYY-MM` snapshot and preserves prior
  months.
- `Reports and Analytics` is a reporting registry, not an operational database.
- `Dashboard!A1:K17`, `Daily Report`, and `Weekly Report` remain preserved legacy
  formula views.
- The new Management Dashboard owns only `Dashboard!A45:L69`, below the legacy
  floating chart. It refuses to overwrite unrelated content.
- No production target was invented. Target comparisons remain absent until
  Avodah configures an authoritative target model.

## Implemented Analytics behavior

- Uses header-driven source reads so appended columns do not break metrics.
- Produces lead volume, inquiry, booking coverage, and status/need breakdowns.
- Produces recruitment counts, stage/status breakdowns, and completion rates
  while keeping Stage and Status separate.
- Produces booking status, Calendar/Meet coverage, reconciliation issues, and
  Calendar Log synchronization metrics.
- Produces Project 1 activity/point totals, current-month totals, duplicate
  warnings, and type/status breakdowns.
- Uses `LockService`, an independent `ENABLE_ANALYTICS_WRITES` gate, role checks,
  deterministic row replacement, current-month upsert keys, audit logging, and
  warning-only protection on derived views.
- Preserves operational sources and legacy report formulas across refreshes.
- Exposes a role-protected, PII-free `getManagementDashboardData()` read API.
- Formats rates as percentages and wraps/fits only the derived analytics tabs.

## Recruitment source-of-truth decision

- `Applicant Tracking` remains the single current applicant source.
- `Applicant Timeline` is append-only stage/status history.
- `Interview Records` stores interview scheduling, Calendar Event ID, Meet link,
  scores, and result.
- `Requirements Tracker` and `Onboarding Tracker` store item-level progress and
  roll summary states into `Applicant Tracking`.
- `Recruitment Analytics` and the Management Dashboard remain derived layers.
- `No Show` remains a status and is never treated as a duplicate stage.

No existing sheet or column was renamed, deleted, reordered, or recreated. The
five recruitment sheets already matched the required schemas and were expanded
only with validation and controlled TEST data.

## Implemented Recruitment behavior

- Creates normalized `APP-` applicant records with duplicate detection.
- Keeps Current Stage and Current Status separate and controlled by settings.
- Appends `TL-` timeline records for every pipeline movement.
- Creates `INTV-` interview records and isolated TEST Calendar events with a
  unique Google Meet link and no guest invitations.
- Records six 1-to-5 interview scores and a calculated overall score.
- Enforces initial/final interview progression and preserves No Show as status.
- Upserts requirement and onboarding items without inventing a production item
  catalog, then rolls summary status into `Applicant Tracking`.
- Uses role checks, Script Properties, `LockService`, idempotent duplicate
  handling, structured errors, audit logging, and compensating event cleanup.
- Provides internal forms for applicant creation, pipeline updates, interview
  scheduling/results, and requirement/onboarding updates.
- Uses independent `ENABLE_RECRUITMENT_WRITES` and
  `ENABLE_CALENDAR_WRITES` gates.
- Stores normalized phone values as text so `+63` numbers cannot become formulas.

## Project 1 source-of-truth decision

- `Targets & Settings` is the only runtime source for Project 1 point and
  required-field mappings.
- `Project 1 Activity Database` is the operational source database.
- `Project 1 Performance Analytics`, reports, and Dashboard remain derived.
- The older standalone Daily Entry script is preserved as an external legacy
  snapshot. It contains a different activity/points model and was not installed
  into the Hub or treated as authoritative.

No existing sheet or column was renamed, deleted, or reordered. The Project 1
database already had the required 19-column schema, so no headers were added.

## Implemented Project 1 behavior

- Reads all 18 active mappings from controlled JSON settings rows.
- Enforces Activity Type to Sub-Activity relationships at runtime.
- Validates every mapping-specific required field.
- Requires a valid HTTPS proof URL for proof-required activities.
- Assigns `P1-` IDs and controlled points.
- Uses `LockService` for concurrent submissions.
- Generates stable duplicate fingerprints.
- Blocks an exact repeat until the user explicitly confirms the duplicate.
- Calculates `Week 1` through `Week 4` and `YYYY-MM` reporting buckets.
- Stores source data in header-driven rows without formula dependencies.
- Records successful submissions in `Activity Audit Log`.
- Provides monthly totals grouped by Activity Type, Sub-Activity, and Team
  Member.
- Provides the four documented internal UI states: no type, type selected,
  sub-activity selected with dynamic fields, and successful submission.
- Uses an independent `ENABLE_PROJECT1_WRITES` Script Property gate.

## Verified point matrix

| Activity Type | Sub-Activity | Points |
|---|---|---:|
| Recruitment | Listing of Prospect Recruit Name | 1 |
| Recruitment | Call Out for Initial Interview | 1 |
| Recruitment | Initial Interview Update | 2 |
| Recruitment | Interview Result Update | 2 |
| Recruitment | Orientation Attendance | 2 |
| Recruitment | Contract Signing | 2 |
| Recruitment | Coding | 3 |
| Recruitment | Licensing Exam | 3 |
| Recruitment | Licensing | 5 |
| Sales | Prospect Listing | 1 |
| Sales | Initial Contact / Call Out | 1 |
| Sales | FNA Conducted | 2 |
| Sales | Proposal Presented | 2 |
| Sales | Application Submitted | 3 |
| Sales | Issued Policy | 5 |
| Joint Field Coaching | Shadowing / Observation | 1 |
| Joint Field Coaching | Co-Presentation | 2 |
| Joint Field Coaching | Assisted Closing | 3 |

Total for one complete matrix: 41 points.

## Files changed for 0.9.0

- `Config.gs`
- `ScheduleImport.gs`
- `LegacyV3.gs` (installed as existing `Code.gs`)
- `SCRIPT_PROPERTIES.md`
- `README.md`
- `SCHEDULE_IMPORT_VERIFICATION.md`

## Verification summary

- 21 Apps Script files parsed successfully with the V8 parser.
- 410 declared global functions; 0 duplicate names.
- Client-side JavaScript parsed successfully.
- 0 production spreadsheet ID occurrences.
- 0 implementation-placeholder occurrences.
- 31 local mapping, validation, bucketing, and summary checks passed.
- 4 local transaction-boundary scenarios passed.
- 13 live foundation checks passed.
- 31 live Project 1 validation checks passed.
- Final live lifecycle: 24/24 checks passed.
- Two complete TEST batches contain 18 rows and 41 points each.
- 36 successful Project 1 audit entries were verified.
- 7/7 live Recruitment validation checks passed.
- 10/10 live Recruitment lifecycle checks passed.
- Two TEST applicants produced 18 timeline entries, 6 interview records,
  4 requirement rows, and 4 onboarding rows.
- All 6 TEST interview events are cancelled/non-active; 0 remain active.
- Phone storage was verified as text with the `+63` prefix preserved and no
  formula value.
- `masterSetup()` preserved every sheet and installed no trigger.
- Spreadsheet read-back, native validation checks, and visual QA passed.
- 9/9 local and live analytics unit checks passed.
- 9/9 live analytics transaction checks passed before the visual-layout
  refinement: operational sources and legacy formulas were unchanged, both
  refreshes reconciled, output was idempotent, and monthly keys were unique.
- Two bounded final refreshes produced identical derived values after moving the
  dashboard below the legacy chart.
- Final derived row counts are 10 Lead, 10 Recruitment, 14 Calendar/Booking, 25
  Project 1, 59 current-month snapshot, and 8 reporting-registry rows.
- Final Management Dashboard cards show 6 leads, 2 active applicants, 4 active
  bookings, and 82 Project 1 points for `2026-07` from TEST fixtures.
- Visual QA confirmed the legacy chart is unobstructed, dashboard cards and
  breakdowns are readable, rates are percentages, and long dimensions fit.
- 12/12 scheduled-reporting validation checks passed.
- Each bounded dashboard, weekly, and monthly callback transaction passed 9/9
  invariants after the assertion harness correction.
- Callback periods resolved to `2026-07-22`, `2026-07-20/2026-07-24`, and
  `2026-07` in `Asia/Manila`.
- Daily, Weekly, and legacy Dashboard formula counts remained 25, 26, and 30.
- The current monthly snapshot contains 59 unique metric/dimension keys and no
  duplicates; the reporting registry contains 8 current rows.
- `Automation Log` contains successful rows for all three callbacks and the
  expected `ANALYTICS_WRITES_DISABLED` negative-gate test.
- Final source verification found 21 parsed `.gs` files, 375 unique global
  functions, no V8 syntax failures, no duplicate function names, and no
  production spreadsheet ID occurrence.
- Native visual QA passed for Daily Report, Weekly Report, Dashboard, Monthly
  Reports, and Reports and Analytics.
- 10/10 final Schedule Import parser and safety checks passed.
- 8/8 final live preview invariants passed. The source fingerprint and Calendar
  Log row count were unchanged.
- The final preview contains 194 July rows: 26 review-required, 168 existing
  Calendar Log duplicates, 0 invalid, and 0 ready duplicates.
- 4/4 bounded commit checks passed: one TEST row written, commit identity stored,
  second write blocked, and all TEST fixtures removed.
- Five native merged ranges were observed and expanded only in memory.
- Visual QA confirmed frozen headers, checkboxes, date/time formats, controlled
  dropdowns, wrapped text, review/duplicate states, and blank post-test commit
  metadata.

The first lifecycle run proved all 18 point assignments but exposed that Google
Sheets can return the displayed month bucket as a Date object. The summary read
path was normalized for both Date and text cells, then the full lifecycle was
repeated and passed all 24 checks.

## Final safety state

- `ENVIRONMENT=TEST`
- `ENABLE_ANALYTICS_WRITES=FALSE`
- `ENABLE_PROJECT1_WRITES=FALSE`
- `ENABLE_RECRUITMENT_WRITES=FALSE`
- `ENABLE_SCHEDULE_IMPORT_WRITES=FALSE`
- `ENABLE_CALENDAR_WRITES=FALSE`
- `ENABLE_BOOKING_WORKFLOW=FALSE`
- `ENABLE_AUTOMATION_TRIGGERS=FALSE`
- `PUBLIC_PORTAL_ENABLED=FALSE`
- No trigger or deployment was created.
- Sensitive Script Properties are excluded from source and reports.

## Remaining configuration gates

No active `TEAM_MEMBER` settings exist. The TEST-only interface can accept a
typed team-member name, but real `TEAM_MEMBER` rows must be populated before a
future production promotion. The README does not define Avodah's real
requirement catalog or onboarding checklist, so those production items remain
external configuration and were not invented. The internal interface is
installed in source but remains inaccessible to end users until a reviewed,
restricted deployment is intentionally created.

## Next blueprint stage

The eight prioritized stabilization workflows are now implemented and verified
in the copied TEST environment. The next major stage is a full-system regression,
security, role, deployment-readiness, monitoring, and rollback review. Trigger
installation, public/internal deployment, Google Calendar synchronization of
schedule-imported Calendar Log rows, and production promotion remain later
reviewed activation decisions.

See `SCHEDULE_IMPORT_VERIFICATION.md` and the dated Phase 3.7 report for detailed
test evidence. Earlier module verification records remain unchanged.
