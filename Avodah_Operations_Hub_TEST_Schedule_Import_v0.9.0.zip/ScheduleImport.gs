/**
 * Hardened Schedule Import orchestration.
 *
 * The pasted Schedule Import matrix remains read-only source material. Preview
 * is a replaceable derived view. Calendar Log is the operational destination;
 * this module never creates a Google Calendar event directly.
 */

var AVODAH_SCHEDULE_IMPORT = Object.freeze({
  SOURCE_SHEET: 'Schedule Import',
  PREVIEW_SHEET: 'Schedule Import Preview',
  CALENDAR_SHEET: 'Calendar Log',
  PREVIEW_COLUMNS: 19,
  SOURCE_RECORD_TYPE: 'SCHEDULE_IMPORT',
  DEFAULT_STATUS: 'Scheduled',
  READY_STATUS: 'Ready',
  REVIEW_STATUS: 'Needs Review - Exact Time',
  INVALID_STATUS: 'Invalid',
  DUPLICATE_CALENDAR_STATUS: 'Duplicate - Calendar Log',
  DUPLICATE_PREVIEW_STATUS: 'Duplicate - Preview'
});

function assertScheduleImportEnvironment_() {
  var environment = getEnvironment_();
  if (AVODAH_CONFIG.ALLOWED_ENVIRONMENTS.indexOf(environment) === -1) {
    throw avodahError_('INVALID_ENVIRONMENT',
      'ENVIRONMENT must be TEST, STAGING, or PRODUCTION before Schedule Import is used.');
  }
  return environment;
}

function assertScheduleImportWritesEnabled_() {
  var environment = assertScheduleImportEnvironment_();
  var enabled = PropertiesService.getScriptProperties()
    .getProperty('ENABLE_SCHEDULE_IMPORT_WRITES');
  if (!truthy_(enabled)) {
    throw avodahError_('SCHEDULE_IMPORT_WRITES_DISABLED',
      'Set ENABLE_SCHEDULE_IMPORT_WRITES=TRUE only for an approved preview or commit window.');
  }
  return environment;
}

function assertScheduleImportCommitEnabled_() {
  var environment = assertScheduleImportWritesEnabled_();
  var calendarEnabled = PropertiesService.getScriptProperties()
    .getProperty('ENABLE_CALENDAR_WRITES');
  if (!truthy_(calendarEnabled)) {
    throw avodahError_('CALENDAR_WRITES_DISABLED',
      'Schedule Import commit also requires ENABLE_CALENDAR_WRITES=TRUE.');
  }
  return environment;
}

function scheduleImportRequiredHeaders_() {
  return getSheetDefinition_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET).headers.slice();
}

function scheduleImportAssertHeaders_(context, requiredHeaders) {
  (requiredHeaders || []).forEach(function(header) {
    if (!context.headerMap[normalizeHeader_(header)]) {
      throw avodahError_('MISSING_HEADER', context.logicalName +
        ' is missing required header: ' + header);
    }
  });
}

function scheduleImportDigest_(value) {
  var bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    String(value == null ? '' : value), Utilities.Charset.UTF_8);
  return Utilities.base64EncodeWebSafe(bytes).replace(/=+$/g, '');
}

function scheduleImportSourceFingerprint_(sheet) {
  var range = sheet.getDataRange();
  var values = range.getDisplayValues();
  var merges = range.getMergedRanges().map(function(item) {
    return item.getA1Notation();
  }).sort();
  return scheduleImportDigest_(safeJsonStringify_({values: values, merges: merges}));
}

function scheduleImportExpandMergedGrid_(values, mergeDefinitions, originRow, originColumn) {
  var output = (values || []).map(function(row) { return row.slice(); });
  var baseRow = Number(originRow || 1);
  var baseColumn = Number(originColumn || 1);
  (mergeDefinitions || []).forEach(function(merge) {
    var rowOffset = Number(merge.row) - baseRow;
    var columnOffset = Number(merge.column) - baseColumn;
    if (rowOffset < 0 || columnOffset < 0 || !output[rowOffset]) return;
    var anchor = output[rowOffset][columnOffset];
    for (var r = 0; r < Number(merge.numRows || 1); r += 1) {
      for (var c = 0; c < Number(merge.numColumns || 1); c += 1) {
        if (output[rowOffset + r] &&
            columnOffset + c < output[rowOffset + r].length) {
          output[rowOffset + r][columnOffset + c] = anchor;
        }
      }
    }
  });
  return output;
}

function scheduleImportSourceGrid_(sheet) {
  var range = sheet.getDataRange();
  var mergeDefinitions = range.getMergedRanges().map(function(merge) {
    return {
      row: merge.getRow(),
      column: merge.getColumn(),
      numRows: merge.getNumRows(),
      numColumns: merge.getNumColumns(),
      a1: merge.getA1Notation()
    };
  });
  return {
    values: scheduleImportExpandMergedGrid_(range.getDisplayValues(),
      mergeDefinitions, range.getRow(), range.getColumn()),
    mergeDefinitions: mergeDefinitions,
    mergedRangeCount: mergeDefinitions.length,
    fingerprint: scheduleImportSourceFingerprint_(sheet)
  };
}

function scheduleImportDateKey_(value) {
  if (!(value instanceof Date) || isNaN(value.getTime())) return '';
  return Utilities.formatDate(value, AVODAH_CONFIG.TIME_ZONE, 'yyyy-MM-dd');
}

function scheduleImportTimeKey_(value) {
  if (!(value instanceof Date) || isNaN(value.getTime())) return '';
  return Utilities.formatDate(value, AVODAH_CONFIG.TIME_ZONE, 'HH:mm');
}

function scheduleImportSignatureSafe_(owner, date, startTime, title) {
  return [String(owner || '').trim(), scheduleImportDateKey_(date),
    scheduleImportTimeKey_(startTime), normalizeKeyText_(title)].join('|');
}

function scheduleImportTitleFromNotes_(notes) {
  var match = String(notes || '').match(/(?:^|\n)Title:\s*([^\n]+)/i);
  return match ? String(match[1]).trim() : '';
}

function scheduleImportDuplicateIndex_() {
  var index = {importKeys: {}, signatures: {}};
  getObjectRows_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET).forEach(function(item) {
    var record = item.record;
    var importKey = String(record['Idempotency Key'] ||
      record['Source Record ID'] || '').trim();
    if (!importKey) {
      var match = String(record.Notes || '').match(/(?:^|\n)Import Key:\s*([^\n]+)/i);
      importKey = match ? String(match[1]).trim() : '';
    }
    if (importKey) index.importKeys[importKey] = item.rowNumber;
    var owner = String(record.Owner || '').trim();
    var date = record.Date;
    var title = scheduleImportTitleFromNotes_(record.Notes) ||
      String(record['Activity Type'] || '').trim();
    if (owner && date instanceof Date && title) {
      index.signatures[scheduleImportSignatureSafe_(owner, date,
        record['Start Time'], title)] = item.rowNumber;
    }
  });
  return index;
}

function scheduleImportEventErrors_(event, owner, requireExactTimes) {
  var errors = [];
  if (!String(owner || '').trim()) errors.push('Owner is required.');
  if (!String(event.importKey || '').trim()) errors.push('Import Key is required.');
  if (!(event.date instanceof Date) || isNaN(event.date.getTime())) {
    errors.push('Date is invalid.');
  }
  if (!String(event.title || '').trim()) errors.push('Title is required.');
  var hasStart = event.startTime instanceof Date && !isNaN(event.startTime.getTime());
  var hasEnd = event.endTime instanceof Date && !isNaN(event.endTime.getTime());
  if (requireExactTimes === true && (!hasStart || !hasEnd)) {
    errors.push('Both Start Time and End Time are required before commit.');
  }
  if (hasStart && hasEnd && event.endTime.getTime() <= event.startTime.getTime()) {
    errors.push('End Time must be after Start Time.');
  }
  var link = String(event.link || '').trim();
  if (link && !/^https:\/\//i.test(link)) errors.push('Location / Link must use HTTPS.');
  return errors;
}

function scheduleImportClassifyCandidate_(event, owner, duplicateIndex, seen) {
  var errors = scheduleImportEventErrors_(event, owner, false);
  var hasExactTimes = event.startTime instanceof Date && event.endTime instanceof Date;
  var importKey = String(event.importKey || '').trim();
  var signature = scheduleImportSignatureSafe_(owner, event.date,
    event.startTime, event.title);
  var status = AVODAH_SCHEDULE_IMPORT.READY_STATUS;
  if (errors.length) status = AVODAH_SCHEDULE_IMPORT.INVALID_STATUS;
  else if (!hasExactTimes) {
    status = AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS;
  } else if (duplicateIndex.importKeys[importKey] ||
      duplicateIndex.signatures[signature]) {
    status = AVODAH_SCHEDULE_IMPORT.DUPLICATE_CALENDAR_STATUS;
  } else if (seen.importKeys[importKey] || seen.signatures[signature]) {
    status = AVODAH_SCHEDULE_IMPORT.DUPLICATE_PREVIEW_STATUS;
  }
  if (importKey) seen.importKeys[importKey] = true;
  if (signature) seen.signatures[signature] = true;
  return {include: status === AVODAH_SCHEDULE_IMPORT.READY_STATUS,
    status: status, errors: errors, signature: signature};
}

function scheduleImportBuildPreviewRows_(values, owner, duplicateIndex) {
  var monthYear = detectImportMonthYear_(values);
  if (!monthYear.month || !monthYear.year) {
    throw avodahError_('SCHEDULE_MONTH_YEAR_NOT_FOUND',
      'Could not detect CALENDAR MONTH and YEAR from Schedule Import.');
  }
  var events = parseMonthlyMatrix_(values, monthYear.month, monthYear.year);
  var seen = {importKeys: {}, signatures: {}};
  var summary = {total: events.length, ready: 0, review: 0,
    invalid: 0, duplicateCalendar: 0, duplicatePreview: 0};
  var rows = events.map(function(event) {
    var classification = scheduleImportClassifyCandidate_(event, owner,
      duplicateIndex, seen);
    if (classification.status === AVODAH_SCHEDULE_IMPORT.READY_STATUS) summary.ready += 1;
    else if (classification.status === AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS) summary.review += 1;
    else if (classification.status === AVODAH_SCHEDULE_IMPORT.INVALID_STATUS) summary.invalid += 1;
    else if (classification.status === AVODAH_SCHEDULE_IMPORT.DUPLICATE_CALENDAR_STATUS) {
      summary.duplicateCalendar += 1;
    } else if (classification.status === AVODAH_SCHEDULE_IMPORT.DUPLICATE_PREVIEW_STATUS) {
      summary.duplicatePreview += 1;
    }
    return [classification.include, event.importKey, event.date, event.period,
      event.startTime || '', event.endTime || '', event.activityType, event.title,
      event.link || '', AVODAH_SCHEDULE_IMPORT.DEFAULT_STATUS, event.reminder,
      event.category, owner, event.sourceCell, event.rawText, classification.status,
      classification.errors.join(' '), '', ''];
  });
  return {rows: rows, summary: summary, month: monthYear.month,
    year: Number(monthYear.year)};
}

function scheduleImportEnsureRowCapacity_(sheet, requiredLastRow) {
  if (requiredLastRow > sheet.getMaxRows()) {
    sheet.insertRowsAfter(sheet.getMaxRows(),
      Math.max(50, requiredLastRow - sheet.getMaxRows()));
  }
}

function scheduleImportCopyValidation_(calendarContext, calendarHeader,
    previewSheet, previewColumn, rowCount) {
  var sourceColumn = calendarContext.headerMap[normalizeHeader_(calendarHeader)];
  if (!sourceColumn || rowCount < 1) return false;
  var rule = calendarContext.sheet.getRange(2, sourceColumn).getDataValidation();
  if (!rule) return false;
  previewSheet.getRange(2, previewColumn, rowCount, 1).setDataValidation(rule);
  return true;
}

function scheduleImportFormatPreview_(previewSheet, rowCount, calendarContext) {
  previewSheet.setFrozenRows(1);
  if (rowCount < 1) return;
  previewSheet.getRange(2, 1, rowCount, 1).insertCheckboxes();
  previewSheet.getRange(2, 3, rowCount, 1).setNumberFormat('yyyy-mm-dd');
  previewSheet.getRange(2, 5, rowCount, 2).setNumberFormat('h:mm AM/PM');
  previewSheet.getRange(2, 18, rowCount, 1)
    .setNumberFormat('yyyy-mm-dd h:mm:ss AM/PM');
  previewSheet.getRange(2, 8, rowCount, 9).setWrap(true);
  scheduleImportCopyValidation_(calendarContext, 'Activity Type', previewSheet, 7, rowCount);
  scheduleImportCopyValidation_(calendarContext, 'Status', previewSheet, 10, rowCount);
  scheduleImportCopyValidation_(calendarContext, 'Reminder', previewSheet, 11, rowCount);
  scheduleImportCopyValidation_(calendarContext, 'Category', previewSheet, 12, rowCount);
  scheduleImportCopyValidation_(calendarContext, 'Owner', previewSheet, 13, rowCount);
}

function previewScheduleImport_() {
  var actor = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF']);
  var environment = assertScheduleImportWritesEnabled_();
  return withScriptLock_('preview schedule import', function() {
    var spreadsheet = getHubSpreadsheet_();
    var sourceSheet = spreadsheet.getSheetByName(AVODAH_SCHEDULE_IMPORT.SOURCE_SHEET);
    if (!sourceSheet) throw avodahError_('MISSING_SHEET',
      AVODAH_SCHEDULE_IMPORT.SOURCE_SHEET + ' is missing.');
    var previewContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
    var calendarContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET);
    scheduleImportAssertHeaders_(previewContext, scheduleImportRequiredHeaders_());
    scheduleImportAssertHeaders_(calendarContext,
      getSheetDefinition_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET).headers);
    var sourceGrid = scheduleImportSourceGrid_(sourceSheet);
    var owner = String(sourceSheet.getRange('B3').getDisplayValue() || '').trim();
    if (!owner) throw avodahError_('SCHEDULE_OWNER_REQUIRED',
      'Schedule Import!B3 must contain the schedule owner.');
    var built = scheduleImportBuildPreviewRows_(sourceGrid.values, owner,
      scheduleImportDuplicateIndex_());
    var previewSheet = previewContext.sheet;
    if (previewSheet.getMaxRows() > 1) {
      previewSheet.getRange(2, 1, previewSheet.getMaxRows() - 1,
        AVODAH_SCHEDULE_IMPORT.PREVIEW_COLUMNS).clearContent();
    }
    if (built.rows.length) {
      scheduleImportEnsureRowCapacity_(previewSheet, built.rows.length + 1);
      previewSheet.getRange(2, 1, built.rows.length,
        AVODAH_SCHEDULE_IMPORT.PREVIEW_COLUMNS).setValues(built.rows);
      scheduleImportFormatPreview_(previewSheet, built.rows.length, calendarContext);
    }
    SpreadsheetApp.flush();
    var response = {ok: true, environment: environment,
      month: String(built.month), year: built.year,
      merged_ranges_observed: sourceGrid.mergedRangeCount,
      source_fingerprint: sourceGrid.fingerprint, summary: built.summary};
    logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
      action: 'SCHEDULE_IMPORT_PREVIEW_REFRESHED', entityType: 'SCHEDULE_IMPORT',
      entityId: String(built.month) + '-' + built.year,
      details: {summary: built.summary,
        mergedRangesObserved: sourceGrid.mergedRangeCount,
        sourceFingerprint: sourceGrid.fingerprint}});
    console.log(JSON.stringify(response));
    return response;
  });
}

function scheduleImportPreviewRecordToEvent_(record) {
  return {
    importKey: String(record['Import Key'] || '').trim(),
    date: record.Date,
    period: String(record.Period || '').trim(),
    startTime: record['Start Time'],
    endTime: record['End Time'],
    activityType: String(record['Activity Type'] || '').trim(),
    title: String(record.Title || '').trim(),
    link: String(record['Location / Link'] || '').trim(),
    reminder: String(record.Reminder || '').trim(),
    category: String(record.Category || '').trim(),
    sourceCell: String(record['Source Cell'] || '').trim(),
    rawText: String(record['Raw Text'] || '').trim()
  };
}

function scheduleImportDateTime_(date, time) {
  var dateParts = getDatePartsInTimezone_(date, AVODAH_CONFIG.TIME_ZONE);
  var hour = Number(Utilities.formatDate(time, AVODAH_CONFIG.TIME_ZONE, 'H'));
  var minute = Number(Utilities.formatDate(time, AVODAH_CONFIG.TIME_ZONE, 'm'));
  return makeDateInTimezone_(dateParts.year, dateParts.month - 1, dateParts.day,
    hour, minute, AVODAH_CONFIG.TIME_ZONE);
}

function scheduleImportCalendarRecord_(record, event, calendarLogId, now) {
  var dateParts = getDatePartsInTimezone_(event.date, AVODAH_CONFIG.TIME_ZONE);
  var dateOnly = makeDateInTimezone_(dateParts.year, dateParts.month - 1,
    dateParts.day, 0, 0, AVODAH_CONFIG.TIME_ZONE);
  var notes = ['Imported monthly schedule', 'Title: ' + event.title,
    'Import Key: ' + event.importKey, event.rawText].filter(Boolean).join('\n');
  return {
    'Event ID': calendarLogId,
    'Owner': String(record.Owner || '').trim(),
    'Date': dateOnly,
    'Start Time': timeFractionFromDate_(event.startTime),
    'End Time': timeFractionFromDate_(event.endTime),
    'Activity Type': event.activityType || 'Other',
    'Location / Link': event.link,
    'Status': String(record.Status || AVODAH_SCHEDULE_IMPORT.DEFAULT_STATUS),
    'Notes': notes,
    'Reminder': event.reminder,
    'Category': event.category,
    'Start DateTime': scheduleImportDateTime_(event.date, event.startTime),
    'End DateTime': scheduleImportDateTime_(event.date, event.endTime),
    'Google Event ID': '',
    'Sync Status': 'Pending',
    'Last Synced': '',
    'Sync Error': '',
    'Record Status': 'Active',
    'Calendar Log ID': calendarLogId,
    'Source Record Type': AVODAH_SCHEDULE_IMPORT.SOURCE_RECORD_TYPE,
    'Source Record ID': event.importKey,
    'Booking ID': '',
    'Idempotency Key': event.importKey,
    'Created At': now,
    'Updated At': now
  };
}

function scheduleImportNextCalendarRow_(calendarContext) {
  var sheet = calendarContext.sheet;
  var keyHeaders = ['Event ID', 'Owner', 'Calendar Log ID', 'Idempotency Key'];
  var columns = keyHeaders.map(function(header) {
    return calendarContext.headerMap[normalizeHeader_(header)];
  }).filter(Boolean);
  var last = 1;
  columns.forEach(function(column) {
    var values = sheet.getRange(2, column, Math.max(sheet.getMaxRows() - 1, 1), 1)
      .getDisplayValues();
    for (var index = values.length - 1; index >= 0; index -= 1) {
      if (String(values[index][0] || '').trim()) {
        last = Math.max(last, index + 2);
        break;
      }
    }
  });
  var next = last + 1;
  scheduleImportEnsureRowCapacity_(sheet, next);
  return next;
}

function scheduleImportPreviewFieldSnapshot_(record) {
  return {'Include?': record['Include?'],
    'Import Status': record['Import Status'],
    'Validation Errors': record['Validation Errors'],
    'Committed At': record['Committed At'],
    'Calendar Log ID': record['Calendar Log ID']};
}

function scheduleImportApplyPreviewUpdate_(rowNumber, update) {
  return updateObjectRow_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET, rowNumber, update);
}

function scheduleImportRollback_(calendarRows, previewSnapshots) {
  var calendarContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET);
  (calendarRows || []).forEach(function(rowNumber) {
    if (rowNumber >= 2 && rowNumber <= calendarContext.sheet.getMaxRows()) {
      calendarContext.sheet.getRange(rowNumber, 1, 1,
        calendarContext.headers.length).clearContent();
    }
  });
  (previewSnapshots || []).forEach(function(item) {
    try { scheduleImportApplyPreviewUpdate_(item.rowNumber, item.snapshot); }
    catch (ignored) {}
  });
  SpreadsheetApp.flush();
}

function commitScheduleImport_(options) {
  var actor = requireUserRole_(['ADMIN', 'MANAGER']);
  var environment = assertScheduleImportCommitEnabled_();
  var settings = options || {};
  var onlyImportKey = String(settings.onlyImportKey || '').trim();
  return withScriptLock_('commit schedule import', function() {
    var previewContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
    var calendarContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET);
    scheduleImportAssertHeaders_(previewContext, scheduleImportRequiredHeaders_());
    scheduleImportAssertHeaders_(calendarContext,
      getSheetDefinition_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET).headers);
    var duplicateIndex = scheduleImportDuplicateIndex_();
    var previewRows = getObjectRows_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
    var createdCalendarRows = [];
    var pendingPreviewUpdates = [];
    var previewSnapshots = [];
    var summary = {read: previewRows.length, selected: 0, imported: 0,
      duplicates: 0, invalid: 0, skipped: 0};
    try {
      previewRows.forEach(function(item) {
        var record = item.record;
        var importKey = String(record['Import Key'] || '').trim();
        if (onlyImportKey && importKey !== onlyImportKey) return;
        if (record['Include?'] !== true) {
          summary.skipped += 1;
          return;
        }
        summary.selected += 1;
        var event = scheduleImportPreviewRecordToEvent_(record);
        var errors = scheduleImportEventErrors_(event, record.Owner, true);
        var signature = scheduleImportSignatureSafe_(record.Owner, event.date,
          event.startTime, event.title);
        previewSnapshots.push({rowNumber: item.rowNumber,
          snapshot: scheduleImportPreviewFieldSnapshot_(record)});
        if (errors.length) {
          summary.invalid += 1;
          pendingPreviewUpdates.push({rowNumber: item.rowNumber, update: {
            'Include?': false,
            'Import Status': AVODAH_SCHEDULE_IMPORT.INVALID_STATUS,
            'Validation Errors': errors.join(' '),
            'Committed At': '', 'Calendar Log ID': ''
          }});
          return;
        }
        if (duplicateIndex.importKeys[importKey] || duplicateIndex.signatures[signature]) {
          summary.duplicates += 1;
          pendingPreviewUpdates.push({rowNumber: item.rowNumber, update: {
            'Include?': false,
            'Import Status': 'Duplicate - Final Recheck',
            'Validation Errors': 'A matching Calendar Log record already exists.',
            'Committed At': '', 'Calendar Log ID': ''
          }});
          return;
        }
        var calendarLogId = generateUniqueId_('CALENDAR');
        var now = new Date();
        var destinationRow = scheduleImportNextCalendarRow_(calendarContext);
        updateObjectRow_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET, destinationRow,
          scheduleImportCalendarRecord_(record, event, calendarLogId, now));
        createdCalendarRows.push(destinationRow);
        duplicateIndex.importKeys[importKey] = destinationRow;
        duplicateIndex.signatures[signature] = destinationRow;
        summary.imported += 1;
        pendingPreviewUpdates.push({rowNumber: item.rowNumber, update: {
          'Include?': false,
          'Import Status': 'Imported',
          'Validation Errors': '',
          'Committed At': now,
          'Calendar Log ID': calendarLogId
        }});
      });
      pendingPreviewUpdates.forEach(function(item) {
        scheduleImportApplyPreviewUpdate_(item.rowNumber, item.update);
      });
      SpreadsheetApp.flush();
      logAuditEvent_({actorEmail: actor.email, actorRole: actor.role,
        action: 'SCHEDULE_IMPORT_COMMITTED', entityType: 'SCHEDULE_IMPORT',
        entityId: onlyImportKey || 'BATCH', details: summary});
    } catch (error) {
      scheduleImportRollback_(createdCalendarRows, previewSnapshots);
      console.error('Schedule Import rollback cause: ' +
        String(error && error.message || error));
      throw avodahError_('SCHEDULE_IMPORT_COMMIT_ROLLED_BACK',
        'Schedule Import commit failed and its Calendar Log writes were rolled back.',
        {cause: String(error && error.message || error),
          rowsRolledBack: createdCalendarRows.length});
    }
    var response = {ok: true, environment: environment, summary: summary};
    console.log(JSON.stringify(response));
    return response;
  });
}

function getScheduleImportStatus() {
  requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var rows = getObjectRows_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
  var counts = {};
  rows.forEach(function(item) {
    var status = String(item.record['Import Status'] || 'Unclassified');
    counts[status] = (counts[status] || 0) + 1;
  });
  return {environment: getEnvironment_(),
    schedule_import_writes_enabled: truthy_(PropertiesService.getScriptProperties()
      .getProperty('ENABLE_SCHEDULE_IMPORT_WRITES')),
    calendar_writes_enabled: truthy_(PropertiesService.getScriptProperties()
      .getProperty('ENABLE_CALENDAR_WRITES')),
    preview_rows: rows.length, by_status: counts};
}

function runScheduleImportValidationTests() {
  requireUserRole_(['ADMIN', 'MANAGER']);
  var tests = [];
  var date = makeDateInTimezone_(2026, 6, 22, 0, 0, AVODAH_CONFIG.TIME_ZONE);
  var expanded = scheduleImportExpandMergedGrid_([
    ['DAY', '22', '23', '24'],
    ['AM', '', '', ''],
    ['PM', '', '', ''],
    ['OBJECTIVE', 'Shared objective', '', '']
  ], [{row: 4, column: 2, numRows: 1, numColumns: 3}], 1, 1);
  testAssert_(tests, 'merged-cell context expands across covered dates',
    expanded[3][1] === 'Shared objective' && expanded[3][2] === 'Shared objective' &&
    expanded[3][3] === 'Shared objective');

  var range = parseScheduleCell_('9:00 AM - 10:30 AM Client Meeting',
    date, 'AM', 'B9');
  testAssert_(tests, 'explicit time range preserves both exact times',
    range.length === 1 && scheduleImportTimeKey_(range[0].startTime) === '09:00' &&
    scheduleImportTimeKey_(range[0].endTime) === '10:30');

  var single = parseScheduleCell_('1pm Client Call', date, 'PM', 'B10');
  testAssert_(tests, 'single time is parsed with controlled default duration',
    single.length === 1 && scheduleImportTimeKey_(single[0].startTime) === '13:00' &&
    scheduleImportTimeKey_(single[0].endTime) === '13:30');

  var broad = parseScheduleCell_('Team planning whole morning',
    date, 'AM', 'B9');
  var broadClass = scheduleImportClassifyCandidate_(broad[0], 'TEST Owner',
    {importKeys: {}, signatures: {}}, {importKeys: {}, signatures: {}});
  testAssert_(tests, 'AM block does not invent exact clock times',
    !(broad[0].startTime instanceof Date) && !(broad[0].endTime instanceof Date));
  testAssert_(tests, 'AM block remains review-required and unchecked',
    broadClass.status === AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS && !broadClass.include);
  var broadDuplicate = {importKeys: {}, signatures: {}};
  broadDuplicate.importKeys[broad[0].importKey] = 9;
  var broadDuplicateClass = scheduleImportClassifyCandidate_(broad[0],
    'TEST Owner', broadDuplicate, {importKeys: {}, signatures: {}});
  testAssert_(tests, 'incomplete AM block stays review-required before duplicate status',
    broadDuplicateClass.status === AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS);

  var interview = parseScheduleCell_(
    'Final Interview - TEST Candidate\n2:00pm-2:30pm\nMeet link: https://meet.google.com/abc-defg-hij',
    date, 'PM', 'C10');
  testAssert_(tests, 'Google Meet link is preserved', interview.length === 1 &&
    interview[0].link === 'https://meet.google.com/abc-defg-hij');

  var untimed = parseScheduleCell_('Prepare monthly report', date, 'OBJECTIVE', 'D11');
  var untimedClass = scheduleImportClassifyCandidate_(untimed[0], 'TEST Owner',
    {importKeys: {}, signatures: {}}, {importKeys: {}, signatures: {}});
  testAssert_(tests, 'untimed activity is preserved for review', untimed.length === 1 &&
    untimedClass.status === AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS);
  testAssert_(tests, 'untimed activity is rejected if manually selected for commit',
    scheduleImportEventErrors_(untimed[0], 'TEST Owner', true).length > 0);

  var duplicateIndex = {importKeys: {}, signatures: {}};
  duplicateIndex.importKeys[range[0].importKey] = 22;
  var duplicateClass = scheduleImportClassifyCandidate_(range[0], 'TEST Owner',
    duplicateIndex, {importKeys: {}, signatures: {}});
  testAssert_(tests, 'duplicate fingerprint is detected before preview selection',
    duplicateClass.status === AVODAH_SCHEDULE_IMPORT.DUPLICATE_CALENDAR_STATUS &&
    !duplicateClass.include);

  var failures = tests.filter(function(test) { return !test.passed; });
  var response = {passed: failures.length === 0, tests: tests, failures: failures};
  console.log(JSON.stringify(response));
  return response;
}

function runScheduleImportPreviewTestTransaction() {
  requireUserRole_(['ADMIN']);
  assertScheduleImportWritesEnabled_();
  var spreadsheet = getHubSpreadsheet_();
  var source = spreadsheet.getSheetByName(AVODAH_SCHEDULE_IMPORT.SOURCE_SHEET);
  var calendarBefore = getObjectRows_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET).length;
  var sourceBefore = scheduleImportSourceFingerprint_(source);
  var response = previewScheduleImport_();
  var sourceAfter = scheduleImportSourceFingerprint_(source);
  var calendarAfter = getObjectRows_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET).length;
  var previewRows = getObjectRows_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
  var tests = [];
  testAssert_(tests, 'source fingerprint is unchanged', sourceBefore === sourceAfter);
  testAssert_(tests, 'preview does not write Calendar Log', calendarBefore === calendarAfter);
  testAssert_(tests, 'live source includes merged ranges', response.merged_ranges_observed > 0);
  testAssert_(tests, 'live preview contains parsed rows', previewRows.length > 0);
  testAssert_(tests, 'live preview includes exact parsed time ranges',
    previewRows.some(function(item) {
    return item.record['Start Time'] instanceof Date &&
      item.record['End Time'] instanceof Date;
  }));
  testAssert_(tests, 'live preview preserves review-required rows', previewRows.some(function(item) {
    return item.record['Import Status'] === AVODAH_SCHEDULE_IMPORT.REVIEW_STATUS;
  }));
  testAssert_(tests, 'live preview preserves a Google Meet link', previewRows.some(function(item) {
    return /^https:\/\/meet\.google\.com\//i.test(String(item.record['Location / Link'] || ''));
  }));
  testAssert_(tests, 'Calendar commit gate remains independently enforced',
    testErrorCode_(function() { assertScheduleImportCommitEnabled_(); }) ===
      'CALENDAR_WRITES_DISABLED');
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures,
    previewSummary: response.summary};
  console.log(JSON.stringify(result));
  return result;
}

function scheduleImportTestTime_(date, hour, minute) {
  var parts = getDatePartsInTimezone_(date, AVODAH_CONFIG.TIME_ZONE);
  return makeDateInTimezone_(parts.year, parts.month - 1, parts.day,
    hour, minute, AVODAH_CONFIG.TIME_ZONE);
}

function runScheduleImportCommitTestTransaction() {
  requireUserRole_(['ADMIN']);
  assertScheduleImportCommitEnabled_();
  var previewContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET);
  var key = 'TEST-SCHEDULE-IMPORT-' + Utilities.getUuid();
  var date = makeDateInTimezone_(2099, 0, 15, 0, 0, AVODAH_CONFIG.TIME_ZONE);
  var testOwner = String(getHubSpreadsheet_()
    .getSheetByName(AVODAH_SCHEDULE_IMPORT.SOURCE_SHEET)
    .getRange('B3').getDisplayValue() || '').trim();
  if (!testOwner) throw avodahError_('SCHEDULE_OWNER_REQUIRED',
    'Schedule Import!B3 must contain the schedule owner for the commit test.');
  var fixtureRow = Math.max(previewContext.sheet.getLastRow() + 1, 2);
  scheduleImportEnsureRowCapacity_(previewContext.sheet, fixtureRow);
  var tests = [];
  var firstResult = null;
  var secondResult = null;
  try {
    updateObjectRow_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET, fixtureRow, {
      'Include?': true, 'Import Key': key, 'Date': date, 'Period': 'AM',
      'Start Time': scheduleImportTestTime_(date, 9, 0),
      'End Time': scheduleImportTestTime_(date, 9, 30),
      'Activity Type': 'Meeting', 'Title': 'TEST Schedule Import Commit',
      'Location / Link': '', 'Status': 'Scheduled', 'Reminder': '30 minutes',
      'Category': 'Avodah', 'Owner': testOwner,
      'Source Cell': 'TEST', 'Raw Text': 'Automated TEST commit fixture',
      'Import Status': 'Ready', 'Validation Errors': '',
      'Committed At': '', 'Calendar Log ID': ''
    });
    firstResult = commitScheduleImport_({onlyImportKey: key});
    var afterFirst = findRowsByHeaderValue_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET,
      'Source Record ID', key);
    testAssert_(tests, 'bounded commit writes exactly one Calendar Log row',
      firstResult.summary.imported === 1 && afterFirst.length === 1);
    var committedPreview = getObjectRow_(AVODAH_SCHEDULE_IMPORT.PREVIEW_SHEET,
      fixtureRow).record;
    testAssert_(tests, 'commit stores Calendar Log ID and timestamp in preview',
      String(committedPreview['Calendar Log ID'] || '').indexOf('CAL-') === 0 &&
      committedPreview['Committed At'] instanceof Date);

    scheduleImportApplyPreviewUpdate_(fixtureRow, {'Include?': true,
      'Import Status': 'Ready', 'Validation Errors': '',
      'Committed At': '', 'Calendar Log ID': ''});
    secondResult = commitScheduleImport_({onlyImportKey: key});
    var afterSecond = findRowsByHeaderValue_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET,
      'Source Record ID', key);
    testAssert_(tests, 'final duplicate recheck prevents a second write',
      secondResult.summary.duplicates === 1 && secondResult.summary.imported === 0 &&
      afterSecond.length === 1);
  } finally {
    var calendarContext = getTableContext_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET);
    findRowsByHeaderValue_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET,
      'Source Record ID', key).forEach(function(rowNumber) {
      calendarContext.sheet.getRange(rowNumber, 1, 1,
        calendarContext.headers.length).clearContent();
    });
    previewContext.sheet.getRange(fixtureRow, 1, 1,
      AVODAH_SCHEDULE_IMPORT.PREVIEW_COLUMNS).clearContent();
    SpreadsheetApp.flush();
  }
  testAssert_(tests, 'TEST Calendar Log fixture is removed',
    findRowsByHeaderValue_(AVODAH_SCHEDULE_IMPORT.CALENDAR_SHEET,
      'Source Record ID', key).length === 0);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures,
    firstCommit: firstResult && firstResult.summary,
    secondCommit: secondResult && secondResult.summary,
    fixturesRemoved: true};
  console.log(JSON.stringify(result));
  return result;
}
