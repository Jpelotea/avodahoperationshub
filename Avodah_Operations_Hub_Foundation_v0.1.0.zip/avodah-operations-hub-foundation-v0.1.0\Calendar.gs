/**
 * Calendar workflow status: existing calendar behavior remains authoritative.
 * Advanced Calendar integration is gated until calendar ID and access checks pass.
 */

