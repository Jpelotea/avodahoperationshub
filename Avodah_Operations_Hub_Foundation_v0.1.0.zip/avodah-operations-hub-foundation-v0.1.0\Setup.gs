/** One-time, idempotent foundation setup and configuration verification. */

function setInitialScriptProperties(values) {
  if (!values || Object.prototype.toString.call(values) !== '[object Object]') {
    throw avodahError_('INVALID_PROPERTIES',
      'Pass an object containing only real environment-specific property values.');
  }
  var allowed = AVODAH_CONFIG.REQUIRED_SCRIPT_PROPERTIES
    .concat(AVODAH_CONFIG.OPTIONAL_SCRIPT_PROPERTIES);
  var accepted = {};
  Object.keys(values).forEach(function(key) {
    if (allowed.indexOf(key) === -1) {
      throw avodahError_('UNKNOWN_PROPERTY', 'Unsupported Script Property: ' + key);
    }
    var text = String(values[key] == null ? '' : values[key]).trim();
    if (!text) return;
    if (/example|replace[-_ ]?me|your[-_ ]/i.test(text)) {
      throw avodahError_('SAMPLE_VALUE_REJECTED',
        'Sample or placeholder values cannot be saved: ' + key);
    }
    accepted[key] = text;
  });
  if (accepted.ENVIRONMENT) {
    accepted.ENVIRONMENT = accepted.ENVIRONMENT.toUpperCase();
    if (AVODAH_CONFIG.ALLOWED_ENVIRONMENTS.indexOf(accepted.ENVIRONMENT) === -1) {
      throw avodahError_('INVALID_ENVIRONMENT',
        'ENVIRONMENT must be TEST, STAGING, or PRODUCTION.');
    }
  }
  PropertiesService.getScriptProperties().setProperties(accepted, false);
  return {
    updated: Object.keys(accepted),
    status: getScriptPropertyStatus_()
  };
}

function masterSetup(options) {
  var config = options || {};
  return withScriptLock_('masterSetup', function() {
    var environment = getEnvironment_();
    if (AVODAH_CONFIG.ALLOWED_ENVIRONMENTS.indexOf(environment) === -1) {
      throw avodahError_('ENVIRONMENT_NOT_CONFIGURED',
        'Set ENVIRONMENT to TEST, STAGING, or PRODUCTION before masterSetup().');
    }
    if (environment === 'PRODUCTION' && config.confirmProduction !== true) {
      throw avodahError_('PRODUCTION_CONFIRMATION_REQUIRED',
        'Run and verify setup in TEST first. Production requires ' +
        'masterSetup({confirmProduction:true}).');
    }

    var spreadsheet = getHubSpreadsheet_();
    var report = {
      version: AVODAH_CONFIG.VERSION,
      environment: environment,
      spreadsheetId: spreadsheet.getId(),
      spreadsheetName: spreadsheet.getName(),
      spreadsheetTimeZone: spreadsheet.getSpreadsheetTimeZone(),
      createdSheets: [],
      preservedSheets: [],
      appendedHeaders: {},
      settingsSeeded: 0,
      validations: [],
      triggers: {status: 'NOT_REQUESTED', created: []},
      warnings: []
    };

    AVODAH_CONFIG.SHEET_DEFINITIONS.forEach(function(definition) {
      var resolved = ensureSheetForDefinition_(spreadsheet, definition);
      if (resolved.created) report.createdSheets.push(definition.name);
      else report.preservedSheets.push(resolved.sheet.getName());

      if (definition.mode === 'TABLE' || definition.mode === 'DERIVED') {
        var appended = initializeTableSheet_(resolved.sheet, definition, resolved.created);
        if (appended.length) report.appendedHeaders[resolved.sheet.getName()] = appended;
      } else if (definition.mode === 'SETTINGS') {
        ensureSettingsTable_(resolved.sheet);
      }
    });

    report.settingsSeeded = seedDefaultSettings_();
    report.validations = applyFoundationValidations_();

    var triggerFlag = PropertiesService.getScriptProperties()
      .getProperty('ENABLE_AUTOMATION_TRIGGERS');
    if (truthy_(triggerFlag)) {
      report.triggers = installRequiredTriggers_();
    } else {
      report.triggers.status = 'SKIPPED_DISABLED';
      report.warnings.push('Automation triggers remain disabled until explicitly enabled.');
    }

    if (spreadsheet.getSpreadsheetTimeZone() !== AVODAH_CONFIG.TIME_ZONE) {
      report.warnings.push('Spreadsheet timezone must be reviewed before activation.');
    }
    if (!getActiveSettingsByGroup_('USER_ROLE').length) {
      report.warnings.push('No USER_ROLE entries exist. Internal APIs remain locked.');
    }
    logAutomationSafe_({
      handler: 'masterSetup',
      status: 'SUCCESS',
      recordsWritten: report.createdSheets.length + report.settingsSeeded,
      details: report
    });
    return report;
  });
}

function seedDefaultSettings_() {
  var existingRows = readSettingsRows_();
  var existingKeys = {};
  existingRows.forEach(function(row) {
    existingKeys[row.group.toUpperCase() + '|' + row.key.toUpperCase()] = true;
  });
  var seeded = 0;
  AVODAH_SETTING_SEEDS.forEach(function(seed) {
    var composite = String(seed[0]).toUpperCase() + '|' + String(seed[1]).toUpperCase();
    if (existingKeys[composite]) return;
    upsertSettingRow_(seed[0], seed[1], seed[2], seed[3], seed[4], seed[5], seed[6]);
    existingKeys[composite] = true;
    seeded += 1;
  });
  AVODAH_PROJECT1_ACTIVITY_SEEDS.forEach(function(activity, index) {
    var key = activity[0] + ' | ' + activity[1];
    var composite = 'PROJECT1_ACTIVITY|' + key.toUpperCase();
    if (existingKeys[composite]) return;
    var payload = {
      activityType: activity[0],
      subActivity: activity[1],
      points: activity[2],
      requiredFields: activity[3]
    };
    upsertSettingRow_('PROJECT1_ACTIVITY', key, safeJsonStringify_(payload),
      'json', true, (index + 1) * 10,
      'README point mapping. Required fields must be re-confirmed before production.');
    existingKeys[composite] = true;
    seeded += 1;
  });
  return seeded;
}

function verifyConfiguration_() {
  var result = {
    version: AVODAH_CONFIG.VERSION,
    environment: getEnvironment_(),
    scriptProperties: getScriptPropertyStatus_(),
    spreadsheet: null,
    sheets: [],
    userRoleCount: 0,
    advancedCalendarService: false,
    configurationGates: [],
    readyForFoundationSetup: false,
    readyForProduction: false
  };
  try {
    var spreadsheet = getHubSpreadsheet_();
    result.spreadsheet = {
      id: spreadsheet.getId(),
      name: spreadsheet.getName(),
      timeZone: spreadsheet.getSpreadsheetTimeZone()
    };
    result.sheets = AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(definition) {
      var sheet = findSheetForDefinition_(spreadsheet, definition);
      return {
        logicalName: definition.name,
        physicalName: sheet ? sheet.getName() : '',
        exists: Boolean(sheet)
      };
    });
  } catch (error) {
    result.configurationGates.push(error.code || 'SPREADSHEET_UNAVAILABLE');
  }
  try {
    result.userRoleCount = getActiveSettingsByGroup_('USER_ROLE').length;
  } catch (error) {
    result.configurationGates.push('SETTINGS_UNAVAILABLE');
  }
  result.advancedCalendarService = Boolean(typeof Calendar !== 'undefined' &&
    Calendar && Calendar.Events && Calendar.Freebusy);

  if (AVODAH_CONFIG.ALLOWED_ENVIRONMENTS.indexOf(result.environment) === -1) {
    result.configurationGates.push('ENVIRONMENT_NOT_CONFIGURED');
  }
  if (!result.scriptProperties.CHRISTINE_CALENDAR_ID.present) {
    result.configurationGates.push('CHRISTINE_CALENDAR_ID_MISSING');
  }
  if (!result.scriptProperties.WEBHOOK_SECRET.present) {
    result.configurationGates.push('WEBHOOK_SECRET_MISSING');
  }
  if (!result.advancedCalendarService) {
    result.configurationGates.push('ADVANCED_CALENDAR_SERVICE_NOT_ENABLED');
  }
  if (!result.userRoleCount) result.configurationGates.push('USER_ROLE_MISSING');
  if (!getActiveSettingsByGroupSafe_('LEAD_STATUS').length) {
    result.configurationGates.push('LEAD_STATUS_CONFIRMATION_REQUIRED');
  }
  if (!getActiveSettingsByGroupSafe_('FOLLOW_UP_STATUS').length) {
    result.configurationGates.push('FOLLOW_UP_STATUS_CONFIRMATION_REQUIRED');
  }
  result.readyForFoundationSetup = result.environment === 'TEST' &&
    Boolean(result.spreadsheet);
  result.readyForProduction = result.configurationGates.length === 0 &&
    result.environment === 'PRODUCTION';
  return result;
}

function getScriptPropertyStatus_() {
  var properties = PropertiesService.getScriptProperties().getProperties();
  var names = AVODAH_CONFIG.REQUIRED_SCRIPT_PROPERTIES
    .concat(AVODAH_CONFIG.OPTIONAL_SCRIPT_PROPERTIES);
  var status = {};
  names.forEach(function(name) {
    var value = properties[name] || '';
    status[name] = {
      present: Boolean(value),
      displayValue: /SECRET/i.test(name) ? redactSecret_(value) :
        (value ? redactSecret_(value) : '')
    };
  });
  return status;
}

function getActiveSettingsByGroupSafe_(groupName) {
  try {
    return getActiveSettingsByGroup_(groupName);
  } catch (error) {
    return [];
  }
}

function verifyCalendarAccess_() {
  var id = PropertiesService.getScriptProperties().getProperty('CHRISTINE_CALENDAR_ID');
  if (!id) throw avodahError_('CHRISTINE_CALENDAR_ID_MISSING',
    'Set CHRISTINE_CALENDAR_ID before testing calendar access.');
  if (typeof Calendar === 'undefined' || !Calendar.Calendars) {
    throw avodahError_('ADVANCED_CALENDAR_SERVICE_NOT_ENABLED',
      'Enable the Advanced Calendar service before testing access.');
  }
  var calendar = Calendar.Calendars.get(id);
  return {id: calendar.id, summary: calendar.summary, timeZone: calendar.timeZone};
}
