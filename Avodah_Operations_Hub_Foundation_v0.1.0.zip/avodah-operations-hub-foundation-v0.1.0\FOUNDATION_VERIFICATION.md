# Foundation Verification Record

## Completed outside Apps Script

- [x] Entire supplied README reviewed.
- [x] Connected Drive searched for existing Avodah sources.
- [x] Central Hub, recruitment source, and Project 1 source identified.
- [x] Sheet metadata, key headers, settings, and representative formulas read.
- [x] Original source Sheets left unchanged.
- [x] Isolated dated Drive folder created.
- [x] Central Hub test copy created and metadata verified.
- [x] Recruitment and Project 1 backup copies created and verified.
- [x] Latest local booking code candidate inventoried.
- [x] Modular Foundation package created.
- [x] No real IDs, secrets, calendar IDs, deployment IDs, or user emails embedded
  in Apps Script source.
- [x] All 24 README-required source/front-end/manifest files are present.
- [x] `appsscript.json` parses as valid JSON.
- [x] All 20 `.gs` files pass a local JavaScript syntax parse.
- [x] No duplicate global function names exist inside the Foundation package.
- [x] Nine local helper/configuration tests pass: email validation and
  normalization, phone normalization, normalized header equivalence, ID prefix,
  ID uniqueness, unique sheet names, Project 1 mapping count, and point total.
- [x] Fifteen mock-spreadsheet setup tests pass, including two consecutive
  `masterSetup()` runs: existing Calendar Log order remains intact, aliases do
  not create duplicate sources, legacy settings are preserved, the controlled
  table begins at `AF1`, the operational Activity Log remains untouched,
  required destination/log sheets are created, settings are not duplicated,
  sheet count stays stable, and triggers remain disabled.
- [x] Collision scan against the latest V3 candidate identified `doGet`, `doPost`,
  and `jsonResponse_`; these must be merged rather than duplicated.

## Required in the copied Apps Script project

- [ ] Export and inspect all existing Apps Script files.
- [ ] Record existing functions and resolve duplicate global names.
- [ ] Record current Script Properties without exposing secret values.
- [ ] Record current triggers, trigger owners, and deployments.
- [ ] Confirm the copied project has an Apps Script backup/rollback artifact.
- [ ] Merge `appsscript.json` and enable Advanced Calendar service.
- [ ] Set real TEST Script Properties.
- [ ] Run `verifyConfiguration_()`.
- [ ] Run `inspectFoundationGap_()`.
- [ ] Run `masterSetup()` in TEST.
- [ ] Confirm no existing header moved or disappeared.
- [ ] Confirm `Targets & Settings` original blocks/formulas still work.
- [ ] Confirm Dashboard, Daily Report, Weekly Report, and Calendar Log still work.
- [ ] Bootstrap real `USER_ROLE` assignments.
- [ ] Run `verifyCalendarAccess_()`.
- [ ] Run `runFoundationTests()` and record every result.
- [ ] Confirm automation triggers remain disabled.
- [ ] Confirm public portal remains disabled.

## Configuration values still required from the owner/admin

- Real administrator and staff email-to-role assignments.
- Confirmation that the calendar ID currently visible in live settings is the
  authoritative consultation calendar and is accessible to the executing owner.
- A real webhook secret stored only in Script Properties.
- Optional notification email and deployment metadata.
- Approval of Lead Status and Follow-up Status controlled lists.
- Approval of the Project 1 current-to-README point and field crosswalk.

## Phase gate

Status: **FOUNDATION BUILT LOCALLY; ACTIVATION AND VERIFICATION PENDING**.

Do not begin Phase 2 mutations or Phase 3 workflow activation until every
applicable item above is checked and evidence is recorded.
