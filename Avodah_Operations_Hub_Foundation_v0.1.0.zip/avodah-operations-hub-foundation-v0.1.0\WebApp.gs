/** Safe Foundation web shell. Public intake and booking actions are disabled. */

function doGet() {
  var email = getCurrentUserEmail_();
  var role = null;
  try { role = email ? getUserRoleRecord_(email) : null; } catch (ignored) {}
  var fileName = role ? 'Index' : 'PublicPortal';
  return HtmlService.createTemplateFromFile(fileName)
    .evaluate()
    .setTitle(role ? 'Avodah Operations Hub' : 'Avodah Consultation Portal')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function doPost() {
  return jsonResponse_({
    status: 'NOT_ACTIVE',
    code: 'FOUNDATION_GATE',
    message: 'Webhook intake is not active in the Foundation package.'
  });
}

function include_(fileName) {
  return HtmlService.createHtmlOutputFromFile(fileName).getContent();
}

function jsonResponse_(payload) {
  return ContentService.createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

function getInternalFoundationStatus() {
  var user = requireUserRole_(['ADMIN', 'MANAGER', 'STAFF', 'VIEWER']);
  var verification = verifyConfiguration_();
  return {
    version: AVODAH_CONFIG.VERSION,
    environment: verification.environment,
    user: {email: user.email, role: user.role},
    configurationGates: verification.configurationGates,
    readyForProduction: verification.readyForProduction
  };
}

function getPublicFoundationStatus() {
  return {
    version: AVODAH_CONFIG.VERSION,
    environment: getEnvironment_(),
    publicPortalEnabled: truthy_(PropertiesService.getScriptProperties()
      .getProperty('PUBLIC_PORTAL_ENABLED')),
    intakeActive: false,
    bookingActive: false
  };
}
