/** Spreadsheet access and non-destructive schema normalization. */

function getHubSpreadsheet_() {
  var propertyId = PropertiesService.getScriptProperties()
    .getProperty('AVODAH_SPREADSHEET_ID');
  if (propertyId) return SpreadsheetApp.openById(propertyId);
  var active = SpreadsheetApp.getActiveSpreadsheet();
  if (!active) {
    throw avodahError_('SPREADSHEET_NOT_CONFIGURED',
      'Set AVODAH_SPREADSHEET_ID or bind this project to the Hub spreadsheet.');
  }
  return active;
}

function withScriptLock_(label, callback, timeoutMs) {
  var lock = LockService.getScriptLock();
  var waitMs = Number(timeoutMs || 30000);
  if (!lock.tryLock(waitMs)) {
    throw avodahError_('LOCK_TIMEOUT', 'Could not acquire lock for ' + label + '.');
  }
  try {
    return callback();
  } finally {
    lock.releaseLock();
  }
}

function findSheetForDefinition_(spreadsheet, definition) {
  var candidates = [definition.name].concat(definition.aliases || []);
  for (var i = 0; i < candidates.length; i += 1) {
    var sheet = spreadsheet.getSheetByName(candidates[i]);
    if (sheet) return sheet;
  }
  return null;
}

function ensureSheetForDefinition_(spreadsheet, definition) {
  var existing = findSheetForDefinition_(spreadsheet, definition);
  if (existing) return {sheet: existing, created: false, logicalName: definition.name};
  var created = spreadsheet.insertSheet(definition.name);
  return {sheet: created, created: true, logicalName: definition.name};
}

function ensureColumnCapacity_(sheet, requiredColumns) {
  var missing = requiredColumns - sheet.getMaxColumns();
  if (missing > 0) sheet.insertColumnsAfter(sheet.getMaxColumns(), missing);
}

function getHeaderMap_(sheet, headerRow, lastColumn) {
  var row = Number(headerRow || 1);
  var width = Number(lastColumn || sheet.getLastColumn());
  if (width < 1) return {};
  var values = sheet.getRange(row, 1, 1, width).getDisplayValues()[0];
  var map = {};
  values.forEach(function(header, index) {
    var key = normalizeHeader_(header);
    if (key && map[key] == null) map[key] = index + 1;
  });
  return map;
}

function appendMissingHeaders_(sheet, requiredHeaders, headerRow) {
  var row = Number(headerRow || 1);
  var currentLastColumn = Math.max(sheet.getLastColumn(), 1);
  var map = getHeaderMap_(sheet, row, currentLastColumn);
  var missing = requiredHeaders.filter(function(header) {
    return map[normalizeHeader_(header)] == null;
  });
  if (!missing.length) return [];
  var startColumn = currentLastColumn + 1;
  if (sheet.getLastColumn() === 0) startColumn = 1;
  ensureColumnCapacity_(sheet, startColumn + missing.length - 1);
  sheet.getRange(row, startColumn, 1, missing.length).setValues([missing]);
  return missing;
}

function initializeTableSheet_(sheet, definition, created) {
  var headers = definition.headers || [];
  if (!headers.length) return [];
  if (created || sheet.getLastRow() === 0) {
    ensureColumnCapacity_(sheet, headers.length);
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.setFrozenRows(1);
    return headers.slice();
  }
  return appendMissingHeaders_(sheet, headers, 1);
}

function appendObjectRow_(logicalSheetName, record) {
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(logicalSheetName);
  if (!definition) {
    throw avodahError_('UNKNOWN_SHEET', 'Unknown logical sheet: ' + logicalSheetName);
  }
  var sheet = findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) throw avodahError_('MISSING_SHEET', logicalSheetName + ' is missing.');
  var lastColumn = sheet.getLastColumn();
  var headers = sheet.getRange(1, 1, 1, lastColumn).getDisplayValues()[0];
  var normalizedRecord = {};
  Object.keys(record || {}).forEach(function(key) {
    normalizedRecord[normalizeHeader_(key)] = record[key];
  });
  var row = headers.map(function(header) {
    var key = normalizeHeader_(header);
    return Object.prototype.hasOwnProperty.call(normalizedRecord, key)
      ? normalizedRecord[key] : '';
  });
  sheet.appendRow(row);
  return sheet.getLastRow();
}

function findRowsByHeaderValue_(logicalSheetName, headerName, value) {
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(spreadsheet, definition);
  if (!sheet || sheet.getLastRow() < 2) return [];
  var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
  var column = map[normalizeHeader_(headerName)];
  if (!column) return [];
  var needle = String(value == null ? '' : value);
  var values = sheet.getRange(2, column, sheet.getLastRow() - 1, 1)
    .getDisplayValues();
  var rows = [];
  values.forEach(function(item, index) {
    if (String(item[0]) === needle) rows.push(index + 2);
  });
  return rows;
}

function getSheetDefinition_(logicalName) {
  for (var i = 0; i < AVODAH_CONFIG.SHEET_DEFINITIONS.length; i += 1) {
    var definition = AVODAH_CONFIG.SHEET_DEFINITIONS[i];
    if (definition.name === logicalName) return definition;
  }
  return null;
}

function locateSettingsTable_(sheet) {
  var headers = AVODAH_CONFIG.SETTINGS_HEADERS;
  var scanWidth = sheet.getLastColumn();
  if (scanWidth < headers.length) return null;
  var firstRow = sheet.getRange(1, 1, 1, scanWidth).getDisplayValues()[0];
  for (var column = 1; column <= scanWidth - headers.length + 1; column += 1) {
    if (normalizeHeader_(firstRow[column - 1]) === 'group' &&
        normalizeHeader_(firstRow[column]) === 'key' &&
        normalizeHeader_(firstRow[column + 1]) === 'value') {
      return {sheet: sheet, startColumn: column, headerRow: 1, created: false};
    }
  }
  return null;
}

function ensureSettingsTable_(sheet) {
  var existing = locateSettingsTable_(sheet);
  if (existing) return existing;
  var headers = AVODAH_CONFIG.SETTINGS_HEADERS;
  var lastColumn = Math.max(sheet.getLastColumn(), 1);
  var firstRow = sheet.getRange(1, 1, 1, lastColumn).getDisplayValues()[0];
  var hasLegacyLayout = firstRow.some(function(value) { return String(value || '').trim(); });
  var startColumn = hasLegacyLayout ? Math.max(lastColumn + 2, 32) : 1;
  ensureColumnCapacity_(sheet, startColumn + headers.length - 1);
  sheet.getRange(1, startColumn, 1, headers.length).setValues([headers]);
  return {sheet: sheet, startColumn: startColumn, headerRow: 1, created: true};
}

function getSettingsTable_(createIfMissing) {
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(AVODAH_CONFIG.SETTINGS_LOGICAL_NAME);
  var sheet = findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) throw avodahError_('MISSING_SETTINGS', 'Targets and Settings is missing.');
  var table = locateSettingsTable_(sheet);
  if (table) return table;
  if (createIfMissing === true) return ensureSettingsTable_(sheet);
  throw avodahError_('SETTINGS_TABLE_NOT_INITIALIZED',
    'Run masterSetup() in TEST before reading controlled settings.');
}

function readSettingsRows_() {
  var table = getSettingsTable_(false);
  var sheet = table.sheet;
  var lastRow = sheet.getLastRow();
  if (lastRow <= table.headerRow) return [];
  var values = sheet.getRange(table.headerRow + 1, table.startColumn,
    lastRow - table.headerRow, AVODAH_CONFIG.SETTINGS_HEADERS.length).getValues();
  return values.map(function(row, index) {
    return {
      rowNumber: table.headerRow + 1 + index,
      group: String(row[0] || '').trim(),
      key: String(row[1] || '').trim(),
      value: row[2],
      valueType: String(row[3] || 'text').trim(),
      active: row[4] === '' ? true : truthy_(row[4]),
      sortOrder: Number(row[5] || 0),
      description: String(row[6] || '')
    };
  }).filter(function(row) {
    return row.group && row.key;
  });
}

function getActiveSettingsByGroup_(groupName) {
  var wanted = String(groupName || '').trim().toUpperCase();
  return readSettingsRows_().filter(function(row) {
    return row.active && row.group.toUpperCase() === wanted;
  }).sort(function(a, b) { return a.sortOrder - b.sortOrder; });
}

function upsertSettingRow_(group, key, value, valueType, active, sortOrder, description) {
  var table = getSettingsTable_(true);
  var rows = readSettingsRows_();
  var groupKey = String(group).trim().toUpperCase();
  var itemKey = String(key).trim().toUpperCase();
  var existing = rows.filter(function(row) {
    return row.group.toUpperCase() === groupKey && row.key.toUpperCase() === itemKey;
  })[0];
  var values = [[group, key, value, valueType || 'text', active !== false,
    Number(sortOrder || 0), description || '']];
  if (existing) {
    table.sheet.getRange(existing.rowNumber, table.startColumn, 1, values[0].length)
      .setValues(values);
    return {created: false, row: existing.rowNumber};
  }
  var destinationRow = Math.max(table.sheet.getLastRow() + 1, table.headerRow + 1);
  table.sheet.getRange(destinationRow, table.startColumn, 1, values[0].length)
    .setValues(values);
  return {created: true, row: destinationRow};
}
