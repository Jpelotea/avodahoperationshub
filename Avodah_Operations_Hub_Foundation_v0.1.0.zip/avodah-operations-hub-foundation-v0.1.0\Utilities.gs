/** Shared, side-effect-free helpers. */

function normalizeHeader_(value) {
  return String(value == null ? '' : value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
}

function normalizeEmail_(value) {
  return String(value == null ? '' : value).trim().toLowerCase();
}

function isValidEmail_(value) {
  var email = normalizeEmail_(value);
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function normalizePhone_(value) {
  var raw = String(value == null ? '' : value).trim();
  if (!raw) return '';
  var digits = raw.replace(/\D/g, '');
  if (digits.indexOf('0063') === 0) digits = digits.substring(2);
  if (digits.indexOf('63') === 0 && digits.length === 12) return '+' + digits;
  if (digits.indexOf('0') === 0 && digits.length === 11) return '+63' + digits.substring(1);
  if (digits.length === 10 && digits.indexOf('9') === 0) return '+63' + digits;
  return digits ? '+' + digits : '';
}

function generateUniqueId_(type) {
  var prefix = AVODAH_CONFIG.ID_PREFIXES[type];
  if (!prefix) throw avodahError_('UNKNOWN_ID_TYPE', 'Unknown ID type: ' + type);
  var stamp = Utilities.formatDate(new Date(), AVODAH_CONFIG.TIME_ZONE,
    'yyyyMMdd-HHmmss');
  var uuidPart = Utilities.getUuid().replace(/-/g, '').substring(0, 10);
  return prefix + '-' + stamp + '-' + uuidPart;
}

function reportingWeekStart_(value) {
  var date = value instanceof Date ? new Date(value.getTime()) : new Date(value);
  if (isNaN(date.getTime())) throw avodahError_('INVALID_DATE', 'Invalid reporting date.');
  var day = Number(Utilities.formatDate(date, AVODAH_CONFIG.TIME_ZONE, 'u'));
  date.setDate(date.getDate() - (day - 1));
  date.setHours(0, 0, 0, 0);
  return date;
}

function safeJsonStringify_(value) {
  try {
    return JSON.stringify(value == null ? {} : value);
  } catch (error) {
    return JSON.stringify({serializationError: String(error)});
  }
}

function safeJsonParse_(value, fallback) {
  if (value == null || value === '') return fallback;
  try {
    return JSON.parse(String(value));
  } catch (error) {
    return fallback;
  }
}

function redactSecret_(value) {
  var text = String(value == null ? '' : value);
  if (!text) return '';
  if (text.length <= 8) return '********';
  return text.substring(0, 3) + '…' + text.substring(text.length - 3);
}

function avodahError_(code, message, details) {
  var error = new Error(message);
  error.name = 'AvodahError';
  error.code = code;
  error.details = details || {};
  return error;
}

function nowIso_() {
  return Utilities.formatDate(new Date(), AVODAH_CONFIG.TIME_ZONE,
    "yyyy-MM-dd'T'HH:mm:ssXXX");
}

function truthy_(value) {
  return value === true || String(value == null ? '' : value)
    .trim().toUpperCase() === 'TRUE';
}

function getEnvironment_() {
  var value = PropertiesService.getScriptProperties().getProperty('ENVIRONMENT');
  return String(value || 'UNCONFIGURED').trim().toUpperCase();
}

