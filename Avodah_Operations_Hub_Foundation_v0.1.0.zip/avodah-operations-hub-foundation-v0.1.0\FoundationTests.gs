/** Read-only helper tests and schema gap inspection. */

function runFoundationTests() {
  var tests = [];
  testAssert_(tests, 'email normalization',
    normalizeEmail_(' Test.User@Example.COM ') === 'test.user@example.com');
  testAssert_(tests, 'valid email', isValidEmail_('test.user@example.com'));
  testAssert_(tests, 'Philippines phone normalization',
    normalizePhone_('0917 123 4567') === '+639171234567');
  testAssert_(tests, 'header normalization',
    normalizeHeader_('Booking_ID') === normalizeHeader_('Booking ID'));
  var intakeId = generateUniqueId_('INTAKE');
  var secondIntakeId = generateUniqueId_('INTAKE');
  testAssert_(tests, 'INT id prefix', intakeId.indexOf('INT-') === 0);
  testAssert_(tests, 'unique IDs', intakeId !== secondIntakeId);
  var names = AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(item) { return item.name; });
  testAssert_(tests, 'unique logical sheet names',
    names.length === names.filter(function(name, index) {
      return names.indexOf(name) === index;
    }).length);
  testAssert_(tests, 'README Project 1 mapping count',
    AVODAH_PROJECT1_ACTIVITY_SEEDS.length === 18);
  var pointSum = AVODAH_PROJECT1_ACTIVITY_SEEDS.reduce(function(sum, row) {
    return sum + Number(row[2]);
  }, 0);
  testAssert_(tests, 'README Project 1 point total', pointSum === 41);
  var failures = tests.filter(function(test) { return !test.passed; });
  return {passed: failures.length === 0, tests: tests, failures: failures};
}

function testAssert_(tests, name, condition) {
  tests.push({name: name, passed: Boolean(condition)});
}

function inspectFoundationGap_() {
  var spreadsheet = getHubSpreadsheet_();
  return AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(definition) {
    var sheet = findSheetForDefinition_(spreadsheet, definition);
    var missingHeaders = [];
    if (sheet && (definition.mode === 'TABLE' || definition.mode === 'DERIVED')) {
      var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
      missingHeaders = (definition.headers || []).filter(function(header) {
        return map[normalizeHeader_(header)] == null;
      });
    }
    return {
      logicalName: definition.name,
      physicalName: sheet ? sheet.getName() : '',
      exists: Boolean(sheet),
      missingHeaders: missingHeaders
    };
  });
}

