/** Validation installation that preserves any existing validation rules. */

function applyFoundationValidations_() {
  var results = [];
  results.push(ensureListValidationForColumn_('Calendar Log', 'Status',
    settingValues_('CALENDAR_STATUS')));
  results.push(ensureListValidationForColumn_('Lead Database', 'Lead Status',
    settingValues_('LEAD_STATUS')));
  results.push(ensureListValidationForColumn_('Lead Database', 'Follow-up Status',
    settingValues_('FOLLOW_UP_STATUS')));
  results.push(ensureListValidationForColumn_('Applicant Tracking', 'Current Stage',
    settingValues_('RECRUITMENT_STAGE')));
  results.push(ensureListValidationForColumn_('Applicant Tracking', 'Current Status',
    settingValues_('RECRUITMENT_STATUS')));
  results.push(ensureListValidationForColumn_('Project 1 Activity Database',
    'Activity Type', ['Recruitment', 'Sales', 'Joint Field Coaching']));
  return results.filter(function(result) { return result != null; });
}

function settingValues_(groupName) {
  return getActiveSettingsByGroupSafe_(groupName).map(function(row) {
    return String(row.value == null ? row.key : row.value);
  }).filter(function(value, index, all) {
    return value && all.indexOf(value) === index;
  });
}

function ensureListValidationForColumn_(logicalSheetName, headerName, values) {
  if (!values || !values.length) {
    return {sheet: logicalSheetName, header: headerName, status: 'SKIPPED_NO_VALUES'};
  }
  var spreadsheet = getHubSpreadsheet_();
  var definition = getSheetDefinition_(logicalSheetName);
  var sheet = definition && findSheetForDefinition_(spreadsheet, definition);
  if (!sheet) return {sheet: logicalSheetName, header: headerName, status: 'SKIPPED_MISSING'};
  var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
  var column = map[normalizeHeader_(headerName)];
  if (!column) return {sheet: sheet.getName(), header: headerName, status: 'SKIPPED_HEADER'};
  var rowCount = Math.max(sheet.getMaxRows() - 1, 1);
  var range = sheet.getRange(2, column, rowCount, 1);
  var existing = range.getDataValidations();
  var hasExisting = existing.some(function(row) { return Boolean(row[0]); });
  if (hasExisting) {
    return {sheet: sheet.getName(), header: headerName, status: 'PRESERVED_EXISTING'};
  }
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(values, true)
    .setAllowInvalid(false)
    .build();
  range.setDataValidation(rule);
  return {sheet: sheet.getName(), header: headerName, status: 'APPLIED'};
}

