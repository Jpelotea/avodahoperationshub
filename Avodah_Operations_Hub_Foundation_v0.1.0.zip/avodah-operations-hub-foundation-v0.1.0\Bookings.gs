/**
 * Booking workflow status: the verified V3 Booking Registry flow remains in
 * place. Migration to the logical Booking Database occurs only after test-copy
 * reconciliation and lifecycle tests pass.
 */

