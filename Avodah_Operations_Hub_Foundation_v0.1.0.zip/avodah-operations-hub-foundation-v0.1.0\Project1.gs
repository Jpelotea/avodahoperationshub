/**
 * Project 1 status: the existing Daily Entry_Avodah implementation remains an
 * external source during Foundation. README point mappings are seeded only into
 * the test settings table and require comparison before activation.
 */

function getProject1PointMapping_() {
  return getActiveSettingsByGroupSafe_('PROJECT1_ACTIVITY').map(function(row) {
    return safeJsonParse_(row.value, null);
  }).filter(function(item) { return item != null; });
}

