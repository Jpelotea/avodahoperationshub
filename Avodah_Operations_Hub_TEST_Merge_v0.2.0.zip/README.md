# Avodah Operations Hub — TEST Merge 0.2.0

This package merges the supplied V3 Apps Script source with the verified
Foundation 0.1.1 modules. It is intentionally TEST-only and fail-closed.

## Safety status

- The production spreadsheet ID, calendar email, management URL, and alert
  email are not embedded in source.
- Every invocation requires `ENVIRONMENT=TEST` and a configured spreadsheet
  whose name starts with `TEST`.
- Calendar create, update, and delete operations remain blocked unless
  `ENABLE_CALENDAR_WRITES=TRUE`.
- Trigger installation remains blocked unless
  `ENABLE_AUTOMATION_TRIGGERS=TRUE`.
- No deployment is created by this package.
- No `USER_ROLE` assignment is invented.

## What is included

- `LegacyV3.gs`: the supplied operational V3 source with TEST safety changes.
- Foundation modules: configuration, preservation-first setup, validation,
  logging, role authorization, trigger controls, and module seams.
- Four HTML files and the combined `appsscript.json` manifest.
- Historical Foundation verification and sheet reports for traceability.
- `SCRIPT_INVENTORY_AND_GAPS.md`: current implementation/gap comparison.
- `SCRIPT_PROPERTIES.md`: required activation values and safe initial states.

## Important merge rule

The copied Apps Script project must contain only one copy of the supplied V3
monolith. Replace its current `Code.gs` contents with `LegacyV3.gs`, or rename
the existing file and replace its contents. Do not add `LegacyV3.gs` while
leaving the old V3 functions in another file; Apps Script globals would then be
duplicated.

## Safe installation order

1. Confirm you are in the copied TEST Apps Script project, not the live project.
2. Record the current TEST project ID, files, triggers, and deployments.
3. Open Project Settings and add Script Properties manually before running code.
   Use `SCRIPT_PROPERTIES.md`; leave calendar and automation write flags false.
4. Replace the current monolith with `LegacyV3.gs` and add the remaining `.gs`
   and `.html` files from this folder.
5. Show `appsscript.json` in Project Settings and replace it with this manifest.
6. Save all files. Do not deploy.
7. Run `authorizeConfiguredTestScopes()` and approve only the displayed scopes.
8. Run `testBasicRuntime()`.
9. Run `masterSetup()` once. It preserves existing columns and appends only
   missing structures.
10. Run `productionHealthCheck()` (the legacy name is preserved; the menu label
    is `TEST Health Check`).
11. Confirm the real initial administrator, then run
    `bootstrapInitialUserRoles([{email:'REAL_EMAIL',role:'ADMIN',displayName:'NAME'}])`.
12. Verify read-only calendar access with `testCalendarAccess()`.
13. Only after confirming a dedicated safe TEST calendar, set
    `ENABLE_CALENDAR_WRITES=TRUE` and run `testCalendarWriteAccess()`.
14. Keep `ENABLE_AUTOMATION_TRIGGERS=FALSE` until manual workflow tests pass.

## Manifest decision

The supplied anonymous web-app setting is retained because the existing public
booking endpoint uses `doPost`. That endpoint still requires `WEBHOOK_SECRET`.
The internal Foundation UI is not routed through `doGet` in this merge, so role-
protected internal access must be introduced later through a separately reviewed
authenticated deployment. Do not treat the anonymous deployment as an internal
management application.

## Current phase gate

This package is ready to install in the copied TEST project. Phase 1 is not
verified until Script Properties, scope authorization, `masterSetup()`, health
checks, and a real `USER_ROLE` have been completed in Google Apps Script.
Production activation is explicitly out of scope for this package.
