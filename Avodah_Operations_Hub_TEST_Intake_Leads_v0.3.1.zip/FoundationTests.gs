/** Read-only helper tests and schema gap inspection. */

function runFoundationTests() {
  var tests = [];
  testAssert_(tests, 'email normalization',
    normalizeEmail_(' Test.User@Example.COM ') === 'test.user@example.com');
  testAssert_(tests, 'valid email', isValidEmail_('test.user@example.com'));
  testAssert_(tests, 'invalid email rejected', !isValidEmail_('not-an-email'));
  testAssert_(tests, 'Philippines phone normalization',
    normalizePhone_('0917 123 4567') === '+639171234567');
  testAssert_(tests, 'normalized phone validation',
    isValidPhone_('+639171234567'));
  testAssert_(tests, 'explicit consent accepted', isConsentGranted_('Yes'));
  testAssert_(tests, 'missing consent rejected', !isConsentGranted_('No'));
  testAssert_(tests, 'header normalization',
    normalizeHeader_('Booking_ID') === normalizeHeader_('Booking ID'));
  var intakeId = generateUniqueId_('INTAKE');
  var secondIntakeId = generateUniqueId_('INTAKE');
  testAssert_(tests, 'INT id prefix', intakeId.indexOf('INT-') === 0);
  testAssert_(tests, 'unique IDs', intakeId !== secondIntakeId);
  var names = AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(item) { return item.name; });
  testAssert_(tests, 'unique logical sheet names',
    names.length === names.filter(function(name, index) {
      return names.indexOf(name) === index;
    }).length);
  testAssert_(tests, 'README Project 1 mapping count',
    AVODAH_PROJECT1_ACTIVITY_SEEDS.length === 18);
  var pointSum = AVODAH_PROJECT1_ACTIVITY_SEEDS.reduce(function(sum, row) {
    return sum + Number(row[2]);
  }, 0);
  testAssert_(tests, 'README Project 1 point total', pointSum === 41);
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  try { console.log(JSON.stringify(result)); } catch (ignored) {}
  return result;
}

function testAssert_(tests, name, condition) {
  tests.push({name: name, passed: Boolean(condition)});
}

function runIntakeLeadValidationTests() {
  var tests = [];
  var valid = {
    'Submission ID': 'test-submission',
    'Submitted At': '2026-07-22T09:00:00.000Z',
    'Full Name': 'Test Client',
    'Email Address': 'test.client@example.com',
    'Mobile Number': '0917 123 4567',
    'Consent': 'Yes'
  };
  testAssert_(tests, 'valid intake record',
    validateIntakeRecord_(valid, normalizeEmail_(valid['Email Address']),
      normalizePhone_(valid['Mobile Number'])) === true);
  var noConsent = Object.assign({}, valid, {'Consent': 'No'});
  testAssert_(tests, 'consent validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(noConsent, normalizeEmail_(noConsent['Email Address']),
        normalizePhone_(noConsent['Mobile Number']));
    }) === 'CONSENT_REQUIRED');
  var badEmail = Object.assign({}, valid, {'Email Address': 'not-an-email'});
  testAssert_(tests, 'email validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(badEmail, normalizeEmail_(badEmail['Email Address']),
        normalizePhone_(badEmail['Mobile Number']));
    }) === 'INVALID_EMAIL');
  var badPhone = Object.assign({}, valid, {'Mobile Number': '123'});
  testAssert_(tests, 'phone validation error',
    testErrorCode_(function() {
      validateIntakeRecord_(badPhone, normalizeEmail_(badPhone['Email Address']),
        normalizePhone_(badPhone['Mobile Number']));
    }) === 'INVALID_PHONE');
  var leadRows = [{rowNumber: 2, record: {
    'Lead ID': 'LEAD-TEST',
    'Normalized Email': 'existing@example.com',
    'Normalized Phone': '+639171234567'
  }}];
  var exact = resolveLeadIdentity_(leadRows, 'existing@example.com', '+639171234567');
  testAssert_(tests, 'exact email resolves existing lead',
    exact.match && exact.match.record['Lead ID'] === 'LEAD-TEST');
  var sharedPhone = resolveLeadIdentity_(leadRows, 'different@example.com',
    '+639171234567');
  testAssert_(tests, 'shared phone does not merge different email',
    !sharedPhone.match && sharedPhone.possiblePhoneDuplicate === true);
  testAssert_(tests, 'formula-like input is escaped',
    safeCellValue_('=1+1', 'Full Name').indexOf("'=") === 0);
  testAssert_(tests, 'international phone retains plus prefix',
    safeCellValue_('+639171234567', 'Normalized Phone') === '+639171234567');
  var failures = tests.filter(function(test) { return !test.passed; });
  var result = {passed: failures.length === 0, tests: tests, failures: failures};
  try { console.log(JSON.stringify(result)); } catch (ignored) {}
  return result;
}

function testErrorCode_(callback) {
  try {
    callback();
    return '';
  } catch (error) {
    return error.code || error.name || 'ERROR';
  }
}

function inspectFoundationGap_() {
  var spreadsheet = getHubSpreadsheet_();
  return AVODAH_CONFIG.SHEET_DEFINITIONS.map(function(definition) {
    var sheet = findSheetForDefinition_(spreadsheet, definition);
    var missingHeaders = [];
    if (sheet && (definition.mode === 'TABLE' || definition.mode === 'DERIVED')) {
      var map = getHeaderMap_(sheet, 1, sheet.getLastColumn());
      missingHeaders = (definition.headers || []).filter(function(header) {
        return map[normalizeHeader_(header)] == null;
      });
    }
    return {
      logicalName: definition.name,
      physicalName: sheet ? sheet.getName() : '',
      exists: Boolean(sheet),
      missingHeaders: missingHeaders
    };
  });
}
