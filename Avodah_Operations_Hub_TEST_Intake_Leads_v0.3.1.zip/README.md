# Avodah Operations Hub - TEST Intake and Leads 0.3.1

This is the verified TEST package for the compatibility-first Avodah Operations
Hub foundation and the first stabilized workflow: Intake to Lead.

## Current status

- Phase 1 foundation: verified in the copied TEST Apps Script project.
- Phase 2 structure comparison: complete without renaming or deleting existing
  source sheets.
- Phase 3.1 Intake to Lead: implemented and verified in TEST.
- Production spreadsheet: untouched.
- Calendar writes: disabled.
- Automation triggers: disabled.
- Public deployment: not created.

## Compatibility decisions

The package preserves the copied system's working physical sheet names while
using the README's logical source-of-truth names in code:

- `Booking Registry` is the physical source for logical `Booking Database`.
- `Dashboard` is the physical derived view for logical `Management Dashboard`.
- `Targets & Settings` is retained instead of creating a competing settings tab.
- `Activity Log` remains operational; system audits use `Activity Audit Log`.

These aliases avoid duplicate databases and keep existing formulas, links, and
automations intact.

## Intake to Lead behavior

- Each intake receives a stable `INT-` ID and processing state.
- Leads receive stable `LEAD-` IDs.
- Email and phone values are normalized and validated.
- Consent is required.
- Exact normalized email repeats reuse the canonical lead.
- A shared phone with a different email is flagged as a possible duplicate and
  is not silently merged.
- Inquiry counts are recalculated from intake records, so retries are
  idempotent.
- Formula-like cell input is escaped while valid international phone numbers
  beginning with `+` are preserved.
- A script lock prevents concurrent processors from creating duplicate leads.
- Successful creates and updates are recorded in `Activity Audit Log`.

## Files changed for 0.3.1

- `Config.gs`
- `Utilities.gs`
- `Database.gs`
- `Intake.gs`
- `Leads.gs`
- `Logging.gs`
- `Setup.gs`
- `FoundationTests.gs`
- `LegacyV3.gs` (installed in Apps Script as the existing `Code.gs` file)

All other package files remain available for the later blueprint phases.

## Verified live TEST sequence

1. `testBasicRuntime()` passed.
2. `runFoundationTests()` passed.
3. `masterSetup()` completed without creating duplicate sheets, settings, or
   triggers.
4. `processPendingIntakes()` processed three pending TEST rows into two
   canonical leads with the expected unique/repeat classifications.
5. A second `processPendingIntakes()` run processed zero rows, confirming live
   retry idempotency.
6. `runIntakeLeadValidationTests()` passed all eight read-only validation and
   identity-policy checks.
7. `productionHealthCheck()` passed in safe TEST state.
8. Intake, lead, and audit ranges were read back and visually verified in the
   copied Google Sheet.

## Safety state

- `ENVIRONMENT=TEST` is required.
- The configured spreadsheet must have a title beginning with `TEST`.
- `ENABLE_CALENDAR_WRITES=FALSE`.
- `ENABLE_AUTOMATION_TRIGGERS=FALSE`.
- No webhook secret is stored in source or included in this package.
- No production spreadsheet ID is present in the package.
- No deployment or trigger is installed by this package.

## Phase gate

Phase 3.1 is complete in TEST. The next blueprint priority is the consultation
workflow:

Availability -> Booking -> TEST Google Calendar -> Booking Registry -> Calendar
Log -> reconciliation.

Before that workflow can be activated, its current booking code, Calendar Log
schema, Booking Registry schema, TEST calendar behavior, and reconciliation
rules must be inspected and tested. Calendar writes and automation triggers
must remain disabled until the module-specific tests pass.

See `INTAKE_LEAD_VERIFICATION.md` and the dated Phase 3.1 report for detailed
evidence and remaining controls.
