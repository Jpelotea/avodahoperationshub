# Avodah Operations Hub - TEST Bookings 0.4.0

This is the verified TEST package for the compatibility-first Avodah Operations
Hub foundation and the stabilized intake, lead, availability, booking, TEST
Calendar, Calendar Log, and reconciliation workflows.

## Current status

- Phase 1 foundation: verified in the copied TEST Apps Script project.
- Phase 2 structure comparison: complete without replacing source sheets.
- Phase 3.1 Intake to Lead: complete and verified.
- Phase 3.2 Availability to Booking and Calendar: complete and verified.
- Booking reconciliation: implemented and verified in the same isolated stage.
- Production spreadsheet: untouched.
- Calendar and booking write gates: disabled after testing.
- Automation triggers: disabled; none installed.
- Public deployment: not created.

## Preserved source-of-truth model

- `Intake Submissions` remains the intake source.
- `Lead Database` remains the lead source.
- `Booking Registry` remains the physical source for logical `Booking Database`.
- `Calendar Log` remains the calendar-hub operational view.
- The configured isolated TEST Google Calendar is the availability source.
- `Targets & Settings` remains the controlled settings source.
- `Activity Audit Log` and `Booking Audit` record workflow activity.
- `Dashboard` remains a derived view and is not an editable duplicate database.

No existing column was deleted or reordered. The setup appends only missing
headers and settings.

## Booking behavior

- Enforces notice, booking horizon, working day, working hour, and slot interval
  rules before writes.
- Applies calendar-busy, blackout, and before/after buffer checks.
- Uses `LockService` and stable idempotency keys to prevent concurrent or repeat
  booking duplicates.
- Resolves the canonical intake and lead before creating a booking.
- Creates the Calendar event first, then writes the Booking Registry and Calendar
  Log, with compensation if a later required write fails.
- Creates a unique Google Meet conference request when enabled.
- Stores the Calendar Event ID in all linked records.
- Supports rescheduling, cancellation, and reconciliation.
- Reconciliation processes only records bound to the current TEST environment
  and TEST calendar; copied unbound legacy rows are preserved as history.
- Keeps guest invitations disabled in TEST.

## Files changed for 0.4.0

- `Config.gs`
- `Database.gs`
- `Calendar.gs`
- `Bookings.gs`
- `FoundationTests.gs`
- `LegacyV3.gs` (installed in Apps Script as the existing `Code.gs` file)
- `README.md`
- `BOOKING_VERIFICATION.md`

The 0.3.1 intake and lead modules remain included and verified.

## TEST structures appended

`Booking Registry` received these missing columns at the end of its existing
schema:

- `Calendar Binding`
- `Environment`
- `Record Status`
- `Source Version`

`Targets & Settings` received these controlled `BOOKING` settings without
duplicating existing rows:

- `DAYS_AVAILABLE`
- `SLOT_INTERVAL_MINUTES`
- `BUFFER_BEFORE_MINUTES`
- `BUFFER_AFTER_MINUTES`
- `EMAIL_REMINDER_MINUTES`
- `POPUP_REMINDER_MINUTES`
- `CREATE_GOOGLE_MEET`
- `SEND_GUEST_INVITES`

## Verification summary

- 21 Apps Script files parsed successfully with the V8 parser.
- 247 declared global functions; 0 duplicate names.
- 0 production spreadsheet ID occurrences in the package.
- 12 deterministic booking-rule tests passed.
- 6 transaction-boundary scenarios passed.
- 13 live foundation tests passed.
- 12 live booking validation tests passed.
- 16 live booking lifecycle and reconciliation checks passed.
- `masterSetup()` was idempotent on its second run.
- Advanced Calendar free/busy availability passed.
- Live health check passed in safe TEST state.
- Spreadsheet read-back and visual QA passed.

Two reversible lifecycle runs created and then cancelled isolated TEST events.
Their Booking Registry, Calendar Log, intake, lead, and audit rows are retained
as TEST evidence. The Calendar resources are deleted/cancelled.

## Safety state

- `ENVIRONMENT=TEST` is required.
- The configured spreadsheet must have a title beginning with `TEST`.
- `ENABLE_CALENDAR_WRITES=FALSE`.
- `ENABLE_BOOKING_WORKFLOW=FALSE`.
- `ENABLE_AUTOMATION_TRIGGERS=FALSE`.
- `PUBLIC_PORTAL_ENABLED=FALSE`.
- Sensitive Script Property values are not stored in source or this package.
- No deployment or trigger is installed by this package.

## Remaining configuration gate

`BOOKING_MANAGEMENT_BASE_URL`/`DEPLOYMENT_ID` remains intentionally unset until a
reviewed TEST web-app deployment is created. Core bookings can operate without
it, but self-service cancellation and rescheduling links remain unavailable.

## Next blueprint stage

The next priority is Project 1 activity submission and points validation. Do
not proceed to production or install scheduled automation before that module is
implemented, tested, and reviewed.

See `BOOKING_VERIFICATION.md` and the dated Phase 3.2 report for detailed
evidence and activation controls.
